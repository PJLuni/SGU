﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class Stammdaten : Form
    {
        private Form neededForm;
       
        public Stammdaten()
        {
            InitializeComponent();
        }

        private void Stammdaten_Load(object sender, EventArgs e)
        {
           
            OpenForm(new KundeSuchen(tabControl1));
        }
        public void OpenForm(Form FormToOpen)
        {
            neededForm = FormToOpen;
            FormToOpen.TopLevel = false;
            FormToOpen.FormBorderStyle = FormBorderStyle.None;
            FormToOpen.Dock = DockStyle.Fill;
            tabPage1.Controls.Add(FormToOpen);
            tabPage1.Tag = FormToOpen;
            FormToOpen.BringToFront();
            FormToOpen.Show();
        }

       
    }
}
