﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class Stammdaten : Form
    {
        private Form neededForm;

        Panel panel;
        public Stammdaten(Panel panel)
        {
            this.panel = panel;
            InitializeComponent();
        }

        private void Stammdaten_Load(object sender, EventArgs e)
        { 
            OpenForm(new KundeSuchen(tabControl1));
            zurueckButton.Text = "Schließen";
            zurueckButton.Visible = true;
        }
        public void OpenForm(Form FormToOpen)
        {
            neededForm = FormToOpen;
            FormToOpen.TopLevel = false;
            FormToOpen.FormBorderStyle = FormBorderStyle.None;
            FormToOpen.Dock = DockStyle.Fill;
            tabPage1.Controls.Add(FormToOpen);
            tabPage1.Tag = FormToOpen;
            FormToOpen.BringToFront();
            FormToOpen.Show();
        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            TabPage selected = tabControl1.SelectedTab;
            if (tabControl1.SelectedTab==tabPage1)
            {
                zurueckButton.Text = "Schließen";
                zurueckButton.Visible = true;
                tabControl1.Height = 727;
                tabControl1.Width = 1262;
                
            }
            if (selected.Text == "Ansprechpartner hinzufuegen" || selected.Text == "Ansprechpartner")
            {
                zurueckButton.Text = "Zurück";
                zurueckButton.Visible = true;
                tabControl1.Width = 992;
            }
            else if (selected.Text == "Kunden hinzufügen" || selected.Text == "Kunden Bearbeiten")
            {
                tabControl1.Height = 808;
                zurueckButton.Text = "Zurück";
                zurueckButton.Visible = true;
            }
            else
            {
                zurueckButton.Visible = true;
                tabControl1.Width = 1064;
            }
        }

        private void zurueckButton_Click(object sender, EventArgs e)
        {
            TabPage selected = tabControl1.SelectedTab;
            if (tabControl1.SelectedTab==tabPage1)
            {
                this.Close();
                MainMenuPlaceholder mainMenuPlaceholder = new MainMenuPlaceholder();
                LoadForm.OpenPanel(mainMenuPlaceholder, panel);

            }
            else
            {
               tabControl1.TabPages.Remove(selected);
            }
        }
    }
}
