﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.ComponentModel;

namespace Spritzgussunternehmen
{
    class edit
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        
       
        public static void ClearTextBoxes(Control parent)
        {
            foreach (Control child in parent.Controls)
            {
                TextBox textBox = child as TextBox;
                if (textBox == null)
                    ClearTextBoxes(child);
                else
                    textBox.Text = "";
            }
        }
        public static void DataGridFuellen(OleDbDataAdapter adap,DataGridView dataGridView)
        {
            
            DataSet ds = new DataSet();
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
            if (adap == null)
            {
                adap = new OleDbDataAdapter();
            }
            else
            {

            }

            ds.Clear();

            adap.Fill(ds, "filter");

            dataGridView.DataSource = ds;
            dataGridView.DataMember = "filter";

            dataGridView.Sort(dataGridView.Columns["Nr"], ListSortDirection.Ascending);
        }

        public static void IstAktiv(OleDbDataAdapter adapter, DataGridView dataGridView, int zeile)
        {
            
            foreach (DataGridViewRow r in dataGridView.Rows)
            {
                bool test = Convert.ToBoolean(r.Cells[zeile].Value);

                if (test == false)
                {

                    dataGridView.Rows[r.Index].Selected = true;

                    DataGridViewRow row;
                    int length;

                    length = dataGridView.SelectedRows.Count;
                    
                    for (int i = length - 1; i >= 0; i--)
                    {
                        row = dataGridView.SelectedRows[i];
                        dataGridView.Rows.Remove(row);
                    }
                }
                else
                {
                    
                }
            }
        }
    }
}
