﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class KundeSuchen : Form
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
     
        Form neededForm;
        TabPage KP;
        TabControl TC;
      
        public KundeSuchen(TabControl TC)
        {
            
            InitializeComponent();
            this.TC = TC;
        }
     
        private void Kunde_Load(object sender, EventArgs e)
        {
            TC.Height = 727;
            adap = new OleDbDataAdapter("SELECT * FROM Kunde ", con);
            edit.DataGridFuellen(adap, Kunden);
            button1.Visible = false;
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            try
            {
                if (Kunden.SelectedRows != null)
                {
                    DialogResult result = MessageBox.Show("Sind Sie sicher das Sie den ausgewählten Kunden und, wenn angegeben, die zusätzlichen Lieferadressen + Ansprechpartner löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                       

                        string Ausgewähltezelle = Kunden.CurrentRow.Cells["Nr"].Value.ToString();
                        con.Open();
                       cmd = new OleDbCommand("delete KundeLieferort.* from KundeLieferort where KundeLieferort.Kunde = " + Ausgewähltezelle + "", con);
                        dr = cmd.ExecuteReader();
                        dr.Read();
                        con.Close();

                        con.Open();
                        cmd = new OleDbCommand("delete Ansprechpartner.* from Ansprechpartner where Ansprechpartner.Kunde = " + Ausgewähltezelle + "", con);
                        dr = cmd.ExecuteReader();
                        dr.Read();
                        con.Close();

                        con.Open();
                         cmd = new OleDbCommand("delete * from Kunde where Nr = " + Ausgewähltezelle + "", con);
                        dr = cmd.ExecuteReader();
                        dr.Read();
                        con.Close();
                        
                        MessageBox.Show("Gelöscht.");
                        edit.DataGridFuellen(adap, Kunden);
                    }
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim löschen des Kunden" + a);
            }
        }

        public void pageswitch(TabPage page)
        {
            if (TC.TabPages.Contains(page))
            {
                MessageBox.Show("Fehler");
            }
        }
        TabPage kundehinzufuegen = new TabPage(); 
        private void iconButton1_Click(object sender, EventArgs e)
        {
            if (TC.Contains(kundehinzufuegen))
            {
                MessageBox.Show("Tap kann nicht zwei mal geöfnet werden");
            }
            else
            {
                pageswitch(kundehinzufuegen);

                kundehinzufuegen.Controls.Clear();
                long Kunde = 0;
                kundehinzufuegen.Text = "Kunden hinzufügen";
                TC.TabPages.Add(kundehinzufuegen);
                OpenForm(new KundeAdd(Kunde, TC, kundehinzufuegen), kundehinzufuegen);
                TC.SelectedTab = kundehinzufuegen;
            }
        }
        public void OpenForm(Form FormToOpen,TabPage KundenAdd)
        {
            
            neededForm = FormToOpen;
            FormToOpen.TopLevel = false;
            FormToOpen.FormBorderStyle = FormBorderStyle.None;
            FormToOpen.Dock = DockStyle.Fill;
            KundenAdd.Controls.Add(FormToOpen);
            KundenAdd.Tag = FormToOpen;
            FormToOpen.BringToFront();
            FormToOpen.Show();
        }
       
        DataTable table;
        private void iconButton3_Click(object sender, EventArgs e)
        {
            istAktiv_checkBox.Visible = false;
            if (textBox1.TextLength > 0)
            {
                table = new DataTable();
                Kunden.DataSource = table;
                string text = textBox1.Text;

                if (istAktiv_checkBox.Checked == true)
                {
                    adap = new OleDbDataAdapter("SELECT * FROM Kunde where IsActive = true", con);

                }
                else
                {
                    adap = new OleDbDataAdapter("SELECT * FROM Kunde", con);

                }
                istAktiv_checkBox_CheckedChanged(sender, e);
                ds.Clear();
                adap.Fill(table);
                DataView dv = table.DefaultView;
                dv.RowFilter = "Bez LIKE '" + textBox1.Text + "%'";
                Kunden.DataSource = dv;
            }
            else
            {
                MessageBox.Show("Fehler");
            }
        }
        
        private void iconButton2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            button1.Visible = true;
            textBox1.Visible = false;
            iconButton3.Visible = false;
            istAktiv_checkBox.Visible = true;
            if (filter_panel.Visible == false)
            {
                kundeWohnort_listBox.Items.Clear();
                land_listBox.Items.Clear();
                filter_panel.Visible = true;
                con.Open();
                cmd = new OleDbCommand("Select Distinct Ort From Kunde", con);

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    kundeWohnort_listBox.Items.Add(dr.GetString(0));
                }

                con.Close();

                con.Open();
                cmd = new OleDbCommand("Select Distinct Land From Kunde", con);

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    land_listBox.Items.Add(dr.GetString(0));
                }

                con.Close();
            }
            else
            {
                textBox1.Text="";
                kundeWohnort_listBox.Visible = false;
                label1.Visible = false;
                istAktiv_checkBox.Checked = false;
                kundeWohnort_listBox.SelectedItem=null;
                land_listBox.SelectedItem = null;
                adap = new OleDbDataAdapter("SELECT * FROM Kunde", con);
                istAktiv_checkBox_CheckedChanged(sender, e);
            }
        }

        public void istActive(OleDbDataAdapter adapter)
        {
                foreach (DataGridViewRow r in Kunden.Rows)
                {
                    bool test = Convert.ToBoolean(r.Cells[9].Value);

                    if (test == false)
                    {

                        Kunden.Rows[r.Index].Selected = true;

                        DataGridViewRow row;
                        int length;

                        length = Kunden.SelectedRows.Count;
                        for (int i = length - 1; i >= 0; i--)
                        {
                            row = Kunden.SelectedRows[i];
                            Kunden.Rows.Remove(row);
                        }
                    }
                    else
                    {
                    edit.DataGridFuellen(adap, Kunden);
                    }
                }
        }

        private void kundeWohnort_listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (kundeWohnort_listBox.SelectedIndex >= 0)
            {
                string Oselected = kundeWohnort_listBox.SelectedItem.ToString();
                string Lselected = land_listBox.SelectedItem.ToString();

                adap = new OleDbDataAdapter("SELECT * FROM Kunde WHERE Ort ='" + Oselected + "'and Land ='" + Lselected + "'", con);

                ds.Clear();

                adap.Fill(ds, "KundenOaL");

                Kunden.DataSource = ds;
                Kunden.DataMember = "KundenOaL";
                istAktiv_checkBox_CheckedChanged(sender, e);
            }
            else
            {
                istAktiv_checkBox_CheckedChanged(sender, e);
            }
            
        }

        private void land_listBox_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (land_listBox.SelectedIndex >= 0)
            {

                label1.Visible = true;
                kundeWohnort_listBox.Visible = true;
                string Lselected = land_listBox.SelectedItem.ToString();

                adap = new OleDbDataAdapter("SELECT * FROM Kunde WHERE Land ='" + Lselected + "'", con);

                ds.Clear();

                adap.Fill(ds, "KundenLand");

                Kunden.DataSource = ds;
                Kunden.DataMember = "KundenLand";

                kundeWohnort_listBox.Items.Clear();

                con.Open();
                cmd = new OleDbCommand("Select Distinct Ort From Kunde where Land ='" + Lselected + "'", con);

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    kundeWohnort_listBox.Items.Add(dr.GetString(0));
                }

                con.Close();
                istAktiv_checkBox_CheckedChanged(sender, e);
            }
        }

        private void istAktiv_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (istAktiv_checkBox.Checked==true)
            {
                edit.IstAktiv(adap, Kunden,9);
            }
            else
            {
            edit.DataGridFuellen(adap, Kunden);
            }
            
            
        }
        TabPage kundebearbeiten = new TabPage();
        private void iconButton4_Click(object sender, EventArgs e)
        {
            

          string Ausgewähltezelle = Kunden.CurrentRow.Cells["Nr"].Value.ToString();

          cmd = new OleDbCommand("select * from Kunde where Nr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);


            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            long Kunde = dr.GetInt32(0);
            con.Close();
            
            pageswitch(kundebearbeiten);
            kundebearbeiten.Controls.Clear();
            kundebearbeiten.Text = "Kunden Bearbeiten";
            TC.TabPages.Add(kundebearbeiten);
            OpenForm(new KundeAdd(Kunde,TC,kundebearbeiten),kundebearbeiten);
            TC.SelectedTab = kundebearbeiten;

           
        }
        
        private void Ansprechpartner_Click(object sender, EventArgs e)
        {
           
            string Kunde = null;
            TabPage ansprechpartnerPage = new TabPage();
            Ansprechpartner ansprechpartner = new Ansprechpartner(Kunde,TC,ansprechpartnerPage);
           
            
            ansprechpartnerPage.Controls.Clear();

            ansprechpartnerPage.Text = "Ansprechpartner";
            TC.TabPages.Add(ansprechpartnerPage);
            LoadForm.OpenTab(ansprechpartner, ansprechpartnerPage);
            TC.SelectedTab = ansprechpartnerPage;

            TC.Height = 726;
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.TextLength == 0)
            {
               adap = new OleDbDataAdapter("SELECT * From Kunde", con);
            edit.DataGridFuellen(adap, Kunden);
                istAktiv_checkBox_CheckedChanged(sender, e);
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            textBox1.Visible = true;
            iconButton3.Visible = true;
            filter_panel.Visible = false;
            button1.Visible = false;
            istAktiv_checkBox.Visible = true;
            adap = new OleDbDataAdapter("SELECT * From Kunde", con);
            edit.DataGridFuellen(adap, Kunden);
        }
    }
}
