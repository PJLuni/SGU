﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    public partial class RechnungAdd : Form
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        long rechNr;
        public RechnungAdd(long rechNr)
        {
            this.rechNr = rechNr;
            InitializeComponent();
        }
        public void lagerBestand()
        {
            con.Close();
            con.Open();
            cmd = new OleDbCommand("SELECT Produkt.Nr from Produkt where Produkt.Bez  = '" + comboBox3.SelectedItem + "'", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            int produktNummer = dr.GetInt32(0);
            con.Close();

            con.Open();
            cmd = new OleDbCommand("SELECT Produkt.Lagerbestand from Produkt where Produkt.Nr  = " + produktNummer +"", con);
            dr = cmd.ExecuteReader();
            dr.Read();
          

        }
        public void produkte()
        {
            con.Open();
            cmd = new OleDbCommand("SELECT distinct Produkt.Bez from Produkt", con);
            dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                comboBox3.Items.Add(dr.GetString(0));
            }
            con.Close();
        }
        public void produkDatenLoad()
        {
            con.Open();
            cmd = new OleDbCommand("SELECT distinct RechnungPosition.Nr from RechnungPosition", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox7.Items.Add(dr.GetInt32(0));
            }
            con.Close();
        }
        public void produktDaten()
        {
            lieferdaten.Visible = true;
            con.Open();
            cmd = new OleDbCommand("SELECT RechnungPosition.* from RechnungPosition where RechnungPosition.Nr = " + listBox1.SelectedItem + "", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            int nummer = dr.GetInt32(1);
            int mEinheitNr = dr.GetInt32(3);
            textBox14.Text =Convert.ToString(dr.GetInt32(4));
            textBox13.Text = Convert.ToString(dr.GetValue(5))+" €";
            con.Close();

            con.Open();
            cmd = new OleDbCommand("SELECT Produkt.Bez from Produkt where Produkt.Nr  = " + nummer + "", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            string produkt = dr.GetString(0);
            comboBox3.Items.Add(produkt);
            comboBox3.SelectedItem = produkt;
            con.Close();

            con.Open();
            cmd = new OleDbCommand("SELECT Mengeneinheit.Bez from Mengeneinheit where Mengeneinheit.Nr  = " + mEinheitNr + "", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            string mengenEinheit = dr.GetString(0);
            comboBox4.Items.Add(mengenEinheit);
            comboBox4.SelectedItem = mengenEinheit;
            con.Close();
        }
        public void mwSt()
        {
            con.Open();
            cmd = new OleDbCommand("SELECT distinct MwSt.Prozentsatz from MwSt", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr.GetInt32(0));
            }
            con.Close();
        }
        public void auftrag()
        {
            con.Open();
            cmd = new OleDbCommand("SELECT distinct Auftrag.Nr from Auftrag", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox2.Items.Add(dr.GetInt32(0));
            }
            con.Close();
        }
        private void textBox14_TextChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex>=0)
            {
                if (textBox14.TextLength>0)
                {
                lagerBestand();
                int getlagermenge = dr.GetInt32(0);
                con.Close();
                long i;

                i = long.Parse(textBox14.Text);

                    if (i > getlagermenge)
                    {
                        DialogResult result = MessageBox.Show("Die gewünchte Menge ist für dieses Produkt im Lagernicht vorhanden nicht vorhanden. Trotzdem vortfahren?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (result == DialogResult.Yes)
                        {

                        }
                        else
                        {
                            textBox14.Text = "";
                            comboBox3.Text = "";
                            comboBox4.Text = "";
                            textBox13.Text = "";
                            textBox14.Focus();
                        }
                    }
                }
            }
            else
            {

            }
        }
        private void RechnungAdd_Load(object sender, EventArgs e)
        {
            if (rechNr==0)
            {
                produkDatenLoad();
                mwSt();
                auftrag();
            }
            
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                comboBox1.SelectedIndex = 0;
            }
            else 
            {
                comboBox1.SelectedIndex = 1;
            }
                
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox7.SelectedIndex >= 0)
            {
                if (listBox1.Items.Contains(comboBox7.SelectedItem))
                {

                }
                else
                {
                    panel2.Visible = true;
                    listBox1.Items.Add(comboBox7.SelectedItem);
                }
            }
            else
            {
                produkte();
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex>=0)
            {
                produktDaten();
            }
        }
    }
}
