﻿namespace Spritzgussunternehmen
{
    partial class ProdSchritt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rohstoffmenge = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.rohstoffeinheit = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.checkprodschritt = new System.Windows.Forms.CheckBox();
            this.prodschrittcombo = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dgvlabel = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.label17 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.produktcombo = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.prodschrittbez = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rohstoffcombo = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // rohstoffmenge
            // 
            this.rohstoffmenge.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rohstoffmenge.Location = new System.Drawing.Point(694, 236);
            this.rohstoffmenge.Name = "rohstoffmenge";
            this.rohstoffmenge.Size = new System.Drawing.Size(140, 26);
            this.rohstoffmenge.TabIndex = 192;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Chocolate;
            this.label5.Location = new System.Drawing.Point(858, 216);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 18);
            this.label5.TabIndex = 195;
            this.label5.Text = "Einheit";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Chocolate;
            this.label8.Location = new System.Drawing.Point(690, 216);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 18);
            this.label8.TabIndex = 194;
            this.label8.Text = "Menge";
            // 
            // rohstoffeinheit
            // 
            this.rohstoffeinheit.BackColor = System.Drawing.Color.White;
            this.rohstoffeinheit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rohstoffeinheit.FormattingEnabled = true;
            this.rohstoffeinheit.Location = new System.Drawing.Point(861, 236);
            this.rohstoffeinheit.Name = "rohstoffeinheit";
            this.rohstoffeinheit.Size = new System.Drawing.Size(140, 26);
            this.rohstoffeinheit.TabIndex = 193;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Chocolate;
            this.label4.Location = new System.Drawing.Point(687, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(314, 32);
            this.label4.TabIndex = 191;
            this.label4.Text = "Verbrauchte Rohstoffe";
            // 
            // checkprodschritt
            // 
            this.checkprodschritt.AutoSize = true;
            this.checkprodschritt.ForeColor = System.Drawing.Color.White;
            this.checkprodschritt.Location = new System.Drawing.Point(692, 100);
            this.checkprodschritt.Name = "checkprodschritt";
            this.checkprodschritt.Size = new System.Drawing.Size(236, 16);
            this.checkprodschritt.TabIndex = 190;
            this.checkprodschritt.Text = "Produktionsschritt manuell auswählen";
            this.checkprodschritt.UseVisualStyleBackColor = true;
            this.checkprodschritt.CheckedChanged += new System.EventHandler(this.checkprodschritt_CheckedChanged);
            // 
            // prodschrittcombo
            // 
            this.prodschrittcombo.BackColor = System.Drawing.Color.White;
            this.prodschrittcombo.Enabled = false;
            this.prodschrittcombo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prodschrittcombo.FormattingEnabled = true;
            this.prodschrittcombo.Location = new System.Drawing.Point(692, 70);
            this.prodschrittcombo.Name = "prodschrittcombo";
            this.prodschrittcombo.Size = new System.Drawing.Size(309, 26);
            this.prodschrittcombo.TabIndex = 189;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Chocolate;
            this.label3.Location = new System.Drawing.Point(686, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 40);
            this.label3.TabIndex = 188;
            this.label3.Text = "Details";
            // 
            // dgvlabel
            // 
            this.dgvlabel.AutoSize = true;
            this.dgvlabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvlabel.ForeColor = System.Drawing.Color.Chocolate;
            this.dgvlabel.Location = new System.Drawing.Point(8, 352);
            this.dgvlabel.Name = "dgvlabel";
            this.dgvlabel.Size = new System.Drawing.Size(451, 24);
            this.dgvlabel.TabIndex = 187;
            this.dgvlabel.Text = "Bereits existierende Produktionsschritte für";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 379);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(989, 203);
            this.dataGridView1.TabIndex = 186;
            // 
            // iconButton1
            // 
            this.iconButton1.BackColor = System.Drawing.Color.White;
            this.iconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.FolderPlus;
            this.iconButton1.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 26;
            this.iconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton1.Location = new System.Drawing.Point(867, 588);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(134, 35);
            this.iconButton1.TabIndex = 185;
            this.iconButton1.Text = "Hinzufügen";
            this.iconButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton1.UseVisualStyleBackColor = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Chocolate;
            this.label17.Location = new System.Drawing.Point(5, 9);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(330, 40);
            this.label17.TabIndex = 178;
            this.label17.Text = "Produktionsschritt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Chocolate;
            this.label1.Location = new System.Drawing.Point(9, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 18);
            this.label1.TabIndex = 177;
            this.label1.Text = "Bezeichnung";
            // 
            // produktcombo
            // 
            this.produktcombo.BackColor = System.Drawing.Color.White;
            this.produktcombo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.produktcombo.FormattingEnabled = true;
            this.produktcombo.Location = new System.Drawing.Point(13, 69);
            this.produktcombo.Name = "produktcombo";
            this.produktcombo.Size = new System.Drawing.Size(311, 26);
            this.produktcombo.TabIndex = 179;
            this.produktcombo.SelectedIndexChanged += new System.EventHandler(this.produktcombo_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Chocolate;
            this.label7.Location = new System.Drawing.Point(690, 167);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 18);
            this.label7.TabIndex = 184;
            this.label7.Text = "Rohstoff";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Chocolate;
            this.label6.Location = new System.Drawing.Point(689, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 18);
            this.label6.TabIndex = 183;
            this.label6.Text = "Produktionsschritt";
            // 
            // prodschrittbez
            // 
            this.prodschrittbez.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prodschrittbez.Location = new System.Drawing.Point(13, 118);
            this.prodschrittbez.Name = "prodschrittbez";
            this.prodschrittbez.Size = new System.Drawing.Size(311, 26);
            this.prodschrittbez.TabIndex = 180;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Chocolate;
            this.label2.Location = new System.Drawing.Point(9, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 18);
            this.label2.TabIndex = 182;
            this.label2.Text = "Produkt";
            // 
            // rohstoffcombo
            // 
            this.rohstoffcombo.BackColor = System.Drawing.Color.White;
            this.rohstoffcombo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rohstoffcombo.FormattingEnabled = true;
            this.rohstoffcombo.Location = new System.Drawing.Point(693, 187);
            this.rohstoffcombo.Name = "rohstoffcombo";
            this.rohstoffcombo.Size = new System.Drawing.Size(308, 26);
            this.rohstoffcombo.TabIndex = 181;
            // 
            // ProdSchritt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1000, 635);
            this.Controls.Add(this.rohstoffmenge);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.rohstoffeinheit);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.checkprodschritt);
            this.Controls.Add(this.prodschrittcombo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgvlabel);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.iconButton1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.produktcombo);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.prodschrittbez);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rohstoffcombo);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ProdSchritt";
            this.Text = "ProdSchritt";
            this.Load += new System.EventHandler(this.ProdSchritt_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox rohstoffmenge;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox rohstoffeinheit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkprodschritt;
        private System.Windows.Forms.ComboBox prodschrittcombo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label dgvlabel;
        private System.Windows.Forms.DataGridView dataGridView1;
        private FontAwesome.Sharp.IconButton iconButton1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox produktcombo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox prodschrittbez;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox rohstoffcombo;
    }
}