﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Rohstoff
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        OleDbDataAdapter adap = null;

        public void RohstoffLaden(ComboBox comboBox)
        {
            cmd = new OleDbCommand("SELECT Nr FROM Rohstoff WHERE IsActive = true", con);
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetInt32(0));
            }
            con.Close();
        }
    }
}
