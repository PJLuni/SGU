﻿namespace Spritzgussunternehmen
{
    partial class ProduktAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label17 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtbreite = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtart = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtmenge = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtbeschreibung = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtpreis = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtaktbestand = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txthoehe = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbez = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtlaenge = new System.Windows.Forms.TextBox();
            this.txteinheit = new System.Windows.Forms.ComboBox();
            this.txthpreis = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Einheiten = new System.Windows.Forms.DataGridView();
            this.Menge = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.iconButton4 = new FontAwesome.Sharp.IconButton();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Einheiten)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Chocolate;
            this.label17.Location = new System.Drawing.Point(12, 9);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(248, 40);
            this.label17.TabIndex = 122;
            this.label17.Text = "Produktdaten";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Chocolate;
            this.label22.Location = new System.Drawing.Point(312, 45);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(120, 18);
            this.label22.TabIndex = 142;
            this.label22.Text = "Beschreibung";
            // 
            // txtbreite
            // 
            this.txtbreite.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbreite.Location = new System.Drawing.Point(168, 165);
            this.txtbreite.Name = "txtbreite";
            this.txtbreite.Size = new System.Drawing.Size(140, 26);
            this.txtbreite.TabIndex = 120;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Chocolate;
            this.label21.Location = new System.Drawing.Point(16, 337);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(151, 18);
            this.label21.TabIndex = 141;
            this.label21.Text = "Aktueller Bestand";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Chocolate;
            this.label1.Location = new System.Drawing.Point(16, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 18);
            this.label1.TabIndex = 121;
            this.label1.Text = "Bezeichnung";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Chocolate;
            this.label20.Location = new System.Drawing.Point(16, 291);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(154, 18);
            this.label20.TabIndex = 140;
            this.label20.Text = "Herstellungs Preis";
            // 
            // txtart
            // 
            this.txtart.BackColor = System.Drawing.Color.White;
            this.txtart.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtart.FormattingEnabled = true;
            this.txtart.Location = new System.Drawing.Point(20, 117);
            this.txtart.Name = "txtart";
            this.txtart.Size = new System.Drawing.Size(289, 26);
            this.txtart.TabIndex = 123;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Chocolate;
            this.label8.Location = new System.Drawing.Point(203, 291);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 18);
            this.label8.TabIndex = 139;
            this.label8.Text = "Preis";
            // 
            // txtmenge
            // 
            this.txtmenge.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmenge.Location = new System.Drawing.Point(20, 261);
            this.txtmenge.Name = "txtmenge";
            this.txtmenge.Size = new System.Drawing.Size(140, 26);
            this.txtmenge.TabIndex = 124;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Chocolate;
            this.label7.Location = new System.Drawing.Point(165, 241);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 18);
            this.label7.TabIndex = 138;
            this.label7.Text = "Einheit";
            // 
            // txtbeschreibung
            // 
            this.txtbeschreibung.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbeschreibung.Location = new System.Drawing.Point(315, 66);
            this.txtbeschreibung.Multiline = true;
            this.txtbeschreibung.Name = "txtbeschreibung";
            this.txtbeschreibung.Size = new System.Drawing.Size(274, 317);
            this.txtbeschreibung.TabIndex = 125;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Chocolate;
            this.label6.Location = new System.Drawing.Point(16, 241);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 18);
            this.label6.TabIndex = 137;
            this.label6.Text = "Menge";
            // 
            // txtpreis
            // 
            this.txtpreis.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpreis.Location = new System.Drawing.Point(203, 310);
            this.txtpreis.Name = "txtpreis";
            this.txtpreis.Size = new System.Drawing.Size(105, 26);
            this.txtpreis.TabIndex = 126;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Chocolate;
            this.label5.Location = new System.Drawing.Point(16, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 18);
            this.label5.TabIndex = 136;
            this.label5.Text = "Länge";
            // 
            // txtaktbestand
            // 
            this.txtaktbestand.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaktbestand.Location = new System.Drawing.Point(20, 357);
            this.txtaktbestand.Name = "txtaktbestand";
            this.txtaktbestand.Size = new System.Drawing.Size(289, 26);
            this.txtaktbestand.TabIndex = 127;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Chocolate;
            this.label4.Location = new System.Drawing.Point(165, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 18);
            this.label4.TabIndex = 135;
            this.label4.Text = "Breite";
            // 
            // txthoehe
            // 
            this.txthoehe.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txthoehe.Location = new System.Drawing.Point(20, 165);
            this.txthoehe.Name = "txthoehe";
            this.txthoehe.Size = new System.Drawing.Size(140, 26);
            this.txthoehe.TabIndex = 128;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Chocolate;
            this.label3.Location = new System.Drawing.Point(16, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 18);
            this.label3.TabIndex = 134;
            this.label3.Text = "Höhe";
            // 
            // txtbez
            // 
            this.txtbez.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbez.Location = new System.Drawing.Point(20, 69);
            this.txtbez.Name = "txtbez";
            this.txtbez.Size = new System.Drawing.Size(289, 26);
            this.txtbez.TabIndex = 129;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Chocolate;
            this.label2.Location = new System.Drawing.Point(16, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 18);
            this.label2.TabIndex = 133;
            this.label2.Text = "Art";
            // 
            // txtlaenge
            // 
            this.txtlaenge.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlaenge.Location = new System.Drawing.Point(20, 213);
            this.txtlaenge.Name = "txtlaenge";
            this.txtlaenge.Size = new System.Drawing.Size(140, 26);
            this.txtlaenge.TabIndex = 130;
            // 
            // txteinheit
            // 
            this.txteinheit.BackColor = System.Drawing.Color.White;
            this.txteinheit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txteinheit.FormattingEnabled = true;
            this.txteinheit.Location = new System.Drawing.Point(168, 261);
            this.txteinheit.Name = "txteinheit";
            this.txteinheit.Size = new System.Drawing.Size(140, 26);
            this.txteinheit.TabIndex = 132;
            // 
            // txthpreis
            // 
            this.txthpreis.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txthpreis.Location = new System.Drawing.Point(20, 310);
            this.txthpreis.Name = "txthpreis";
            this.txthpreis.Size = new System.Drawing.Size(175, 26);
            this.txthpreis.TabIndex = 131;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Einheiten);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(607, 66);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(393, 317);
            this.panel2.TabIndex = 152;
            // 
            // Einheiten
            // 
            this.Einheiten.AllowUserToAddRows = false;
            this.Einheiten.AllowUserToDeleteRows = false;
            this.Einheiten.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Einheiten.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Einheiten.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Menge});
            this.Einheiten.Dock = System.Windows.Forms.DockStyle.Top;
            this.Einheiten.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Einheiten.Location = new System.Drawing.Point(0, 0);
            this.Einheiten.Name = "Einheiten";
            this.Einheiten.Size = new System.Drawing.Size(393, 280);
            this.Einheiten.TabIndex = 11;
            // 
            // Menge
            // 
            this.Menge.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Menge.DataPropertyName = "DGVMenge";
            this.Menge.HeaderText = "Menge";
            this.Menge.Name = "Menge";
            this.Menge.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Menge.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.iconPictureBox1);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 282);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(393, 35);
            this.panel1.TabIndex = 147;
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.iconPictureBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.InfoCircle;
            this.iconPictureBox1.IconColor = System.Drawing.SystemColors.HotTrack;
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.Location = new System.Drawing.Point(3, 3);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(32, 32);
            this.iconPictureBox1.TabIndex = 2;
            this.iconPictureBox1.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Silver;
            this.label10.Location = new System.Drawing.Point(41, 4);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(275, 24);
            this.label10.TabIndex = 1;
            this.label10.Text = "Legen Sie hier bitte fest wie oft dieses Produkt \r\nin die entsprechende Verpackun" +
    "gseinheit passt!";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Chocolate;
            this.label9.Location = new System.Drawing.Point(600, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(400, 40);
            this.label9.TabIndex = 151;
            this.label9.Text = "Verpackungseinheiten";
            // 
            // iconButton2
            // 
            this.iconButton2.BackColor = System.Drawing.Color.White;
            this.iconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.FolderPlus;
            this.iconButton2.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.IconSize = 26;
            this.iconButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton2.Location = new System.Drawing.Point(866, 580);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Size = new System.Drawing.Size(134, 35);
            this.iconButton2.TabIndex = 150;
            this.iconButton2.Text = "Hinzufügen";
            this.iconButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton2.UseVisualStyleBackColor = false;
            this.iconButton2.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // iconButton4
            // 
            this.iconButton4.BackColor = System.Drawing.Color.White;
            this.iconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton4.IconChar = FontAwesome.Sharp.IconChar.HandPaper;
            this.iconButton4.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton4.IconSize = 26;
            this.iconButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton4.Location = new System.Drawing.Point(719, 580);
            this.iconButton4.Name = "iconButton4";
            this.iconButton4.Size = new System.Drawing.Size(141, 35);
            this.iconButton4.TabIndex = 149;
            this.iconButton4.Text = "Abbrechen";
            this.iconButton4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconButton4.UseVisualStyleBackColor = false;
            // 
            // ProduktAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1011, 626);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.iconButton2);
            this.Controls.Add(this.iconButton4);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txtbreite);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtart);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtmenge);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtbeschreibung);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtpreis);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtaktbestand);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txthoehe);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtbez);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtlaenge);
            this.Controls.Add(this.txteinheit);
            this.Controls.Add(this.txthpreis);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ProduktAdd";
            this.Text = "ProduktAdd";
            this.Load += new System.EventHandler(this.ProduktAdd_Load);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Einheiten)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtbreite;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox txtart;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtmenge;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtbeschreibung;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtpreis;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtaktbestand;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txthoehe;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtbez;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtlaenge;
        private System.Windows.Forms.ComboBox txteinheit;
        private System.Windows.Forms.TextBox txthpreis;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView Einheiten;
        private System.Windows.Forms.DataGridViewTextBoxColumn Menge;
        private System.Windows.Forms.Panel panel1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private FontAwesome.Sharp.IconButton iconButton2;
        private FontAwesome.Sharp.IconButton iconButton4;
    }
}