﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class ProduktAdd : Form
    {
        Produkt NeuesProdukt = new Produkt();
        TabControl NeededTabControl;
        public ProduktAdd(TabControl NeededTabControl)
        {
            InitializeComponent();
            this.NeededTabControl = NeededTabControl;
        }

        private void ProduktAdd_Load(object sender, EventArgs e)
        {
            NeuesProdukt.LoadArten(txtart);
            NeuesProdukt.LoadEinheiten(txteinheit);
            NeuesProdukt.VerpackungsDataGridFuellen(Einheiten);
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            List<string> DataToFill = new List<string>();
           /*0*/ DataToFill.Add(txtbez.Text);
           /*1*/ DataToFill.Add(txtart.Text);
           /*2*/ DataToFill.Add(txthoehe.Text);
           /*3*/ DataToFill.Add(txtlaenge.Text);
           /*4*/ DataToFill.Add(txtbreite.Text);
           /*5*/ DataToFill.Add(txtmenge.Text);
           /*6*/ DataToFill.Add(txtbeschreibung.Text);
           /*7*/ DataToFill.Add(txteinheit.Text);
           /*8*/ DataToFill.Add(txthpreis.Text);
           /*9*/ DataToFill.Add(txtpreis.Text);
          /*10*/ DataToFill.Add(txtaktbestand.Text);

            if (Helfer.TBFilled(DataToFill))
            {
                NeuesProdukt.ErstelleProdukt(Einheiten, DataToFill);
                DialogResult result = MessageBox.Show("Möchten Sie die Produktionsschritte direkt im Anschluss erstellen?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    NeuesProdukt.OpenProdSchritte(NeededTabControl);
                }
            }
            else
            {
                MessageBox.Show("Sehr geehrte Brüderinnen und Brüder\nIhnen ist entgangen das Sie alle Texxfelder mit Text beschmücken müssen\nMit adlichen Grüßen,\nIhr Programmierer");
            }
        }
    }
}
