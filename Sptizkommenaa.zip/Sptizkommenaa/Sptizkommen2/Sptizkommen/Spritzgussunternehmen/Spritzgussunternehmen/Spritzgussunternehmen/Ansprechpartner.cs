﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    
    public partial class Ansprechpartner : Form
    {
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;

        string kundeNr;
        string aNr;
        TabControl TC;
        TabPage KP;
        public Ansprechpartner(string kundeNr,TabControl TC,TabPage KP)
        {
           aNr = kundeNr;
            this.KP = KP;
            this.TC = TC;
            this.kundeNr = kundeNr;
            InitializeComponent();
        }
        public void ansprechpartnersuchen()
        {
            
            adap = new OleDbDataAdapter("SELECT * From Ansprechpartner", con);
            con.Open();
            ds.Clear();

            adap.Fill(ds, "ansprechpartner");

            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "ansprechpartner";
            con.Close();
            
        }
        public void ansprechpartnerhinzufuegen()
        {
            if (KP.Text== "Ansprechpartner hinzufügen")
            {               
                filter.Visible = false;
                panel2.Visible = false;
                if (kundeNr!=null)
                {
                  adap = new OleDbDataAdapter("SELECT * From Ansprechpartner where Ansprechpartner.Kunde = "+ kundeNr +"", con);
                con.Open();
                ds.Clear();
                adap.Fill(ds, "ansprechpartner");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "ansprechpartner";
                con.Close();

                }
                else
                {
                    ansprechpartnersuchen();
                }  
               
            
            }
            
        }
        public void ansprechpartnerbearbeiten()
        {
            if (KP.Text == "Ansprechpartner bearbeiten")
            {
                filter.Visible = false;
                panel2.Visible = false;

                con.Open();
                cmd = new OleDbCommand("Select * From Ansprechpartner where Nr = " + textBox17.Text + "", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox1.Text = Convert.ToString(dr.GetInt32(1));
                textBox2.Text = dr.GetString(2);
                textBox3.Text = dr.GetString(3);
                textBox9.Text = dr.GetString(4); ;
                textBox4.Text = dr.GetString(5);
                textBox5.Text = dr.GetString(6);
                textBox6.Text = dr.GetString(7);
                checkBox2.Checked = dr.GetBoolean(8);
                con.Close();
            }
        }
        private void Ansprechpartner_Load(object sender, EventArgs e)
        {
           
            TC.Width = 975;

            if (KP.Text == "Ansprechpartner bearbeiten")
            {
                textBox17.Text = kundeNr;
                ansprechpartnerbearbeiten();
            }
            else
            {
                textBox1.Text = kundeNr;
            }
            if (textBox1.TextLength==0||textBox17.TextLength==0)
            {
                ansprechpartnersuchen();
            }
            if (KP.Text == "Ansprechpartner hinzufügen")
            {
                checkBox3.Visible = true;
              ansprechpartnerhinzufuegen();   
            }
            
               
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox17.TextLength>0)
            {
                if (textBox1.TextLength>0)
                {
                    if (KP.Text== "Ansprechpartner bearbeiten")
                    {
                        con.Close();
                        con.Open();
                        cmd = new OleDbCommand("update Ansprechpartner set Nr = '" + textBox17.Text.ToString() + "', Kunde = '" + textBox1.Text.ToString() + "', Anrede = '" + textBox2.Text.ToString() + "', Name = '" + textBox3.Text.ToString() + "', Vorname = '" + textBox9.Text.ToString() + "', Email = '" + textBox4.Text.ToString() + "', Telefon = '" + textBox5.Text.ToString() + "', Fax = '" + textBox6.Text.ToString() + "',  IsActive = " + checkBox2.Checked + " where Nr = " + Convert.ToInt64(textBox17.Text) + "", con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                        if (kundeNr==null)
                        {
                            KP.Text = "Ansprechpartner";
                            panel1.Visible = false;
                            ansprechpartnersuchen();
                        }
                        else
                        {
                         TabPage selectedpage = TC.SelectedTab;

                        TC.TabPages.Remove(selectedpage);
                        }
                        
                    }
                    else
                    {
                        con.Close();
                      con.Open();
                     cmd = new OleDbCommand("Insert into Ansprechpartner (Nr, Kunde, Anrede, Name, Vorname, Email, Telefon, Fax, IsActive) values ('" + textBox17.Text + "', '" + textBox1.Text + "', '" + textBox2.Text + "', '" + textBox3.Text + "','" + textBox9.Text + "','" + textBox4.Text + "', '" + textBox5.Text + "', '" + textBox6.Text + "'," + checkBox2.Checked + ")", con);

                     cmd.ExecuteNonQuery();
                     con.Close();


                        TC.Height = 426;
                        panel1.Visible = false;
                        panel4.Location = new Point(37, 50);
                        textBox1.Text = "";
                        KP.Text = "Ansprechpartner";
                    }

                    if (KP.Text== "Ansprechpartner")
                    {
                        filter.Visible = true;
                        panel2.Visible = true;
                    }
                }
                else
                {
                    MessageBox.Show("Geben sie bitte einen Kunden ein");
                    textBox1.Focus();
                }
            }
            else
            {
                MessageBox.Show("Geben sie bitte eine Nummer ein");
                textBox17.Focus();
            }
            
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
        }
        public void position()
        {
            panel4.Location= new Point(40, 374);
            TC.Height = 727;
            panel1.Visible = true;
        }
        
        private void iconButton2_Click(object sender, EventArgs e)
        {
            position();
            KP.Text = "Ansprechpartner hinzufügen";
            ansprechpartnerhinzufuegen();
           edit.ClearTextBoxes(TC.SelectedTab);
            panel2.Visible = true;
            
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows != null)
            {
                DialogResult result = MessageBox.Show("Sind Sie sicher das Sie den ausgewählten Ansprechpartner löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    con.Close();
                    string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();
                    con.Open();
                    cmd = new OleDbCommand("delete * from Ansprechpartner where Ansprechpartner.Nr = " + Ausgewähltezelle + "", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    con.Close();

                    ansprechpartnersuchen();
                    MessageBox.Show("Gelöscht.");
                }
            }
        }

        private void iconButton7_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            KP.Text = "Ansprechpartner bearbeiten";
            filter.Visible = false;
            con.Close();
            position();
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();
            con.Open();
            cmd = new OleDbCommand("Select * From Ansprechpartner where Nr = " + Ausgewähltezelle + "", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            textBox17.Text = Convert.ToString(dr.GetInt32(0));
            textBox1.Text = Convert.ToString(dr.GetInt32(1));
            textBox2.Text = dr.GetString(2);
            textBox3.Text = dr.GetString(3);
            textBox9.Text = dr.GetString(4); ;
            textBox4.Text = dr.GetString(5);
            textBox5.Text = dr.GetString(6);
            textBox6.Text = dr.GetString(7);
            checkBox2.Checked = dr.GetBoolean(8);
            con.Close();

            ansprechpartnersuchen();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.TextLength>0)
            {
                if (checkBox3.Checked)
                {
                     adap = new OleDbDataAdapter("SELECT * FROM Ansprechpartner Where Kunde = "+ textBox1.Text + "", con);

                    ds.Clear();

                    adap.Fill(ds, "ansprechpartner");

                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "ansprechpartner";
                }
                else
                {
                    ansprechpartnersuchen();  
                }
           
            }
            else if (textBox1.TextLength==0)
            {
                ansprechpartnersuchen();
            }
           
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text=="Nummer")
            {
                adap = new OleDbDataAdapter("Select Ansprechpartner.* from Ansprechpartner,Kunde where Ansprechpartner.Kunde = Kunde.Nr and Kunde.Nr LIKE '"+textBox10.Text+"%'", con);
                            DataTable dt = new DataTable();
                            adap.Fill(dt);
                            dataGridView1.DataSource = dt;
            }
          else  if (comboBox1.Text == "Bezeichnung")
            {
                adap = new OleDbDataAdapter("Select Ansprechpartner.* from Ansprechpartner,Kunde where Ansprechpartner.Kunde = Kunde.Nr and Kunde.Bez LIKE '" + textBox10.Text + "%'", con);
                DataTable dt = new DataTable();
                adap.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked==false)
            {
                ansprechpartnersuchen();
            }
            else
            {
                textBox1_TextChanged(sender, e);
            }
        }
    }
}
