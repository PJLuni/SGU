﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class ProduktAdd : Form
    {
        Produkt NeuesProdukt = new Produkt();
        TabControl NeededTabControl;
        public ProduktAdd(TabControl NeededTabControl)
        {
            InitializeComponent();
            this.NeededTabControl = NeededTabControl;
        }

        private void ProduktAdd_Load(object sender, EventArgs e)
        {
            NeuesProdukt.LoadArten(txtart);
            NeuesProdukt.LoadEinheiten(txteinheit);
            NeuesProdukt.VerpackungsDataGridFuellen(Einheiten);
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            bool EinheitenFilled = true;

            List<string> DataToFill = new List<string>();
           /*0*/ DataToFill.Add(txtbez.Text);
           /*1*/ DataToFill.Add(txtart.Text);
           /*2*/ DataToFill.Add(txthoehe.Text);
           /*3*/ DataToFill.Add(txtlaenge.Text);
           /*4*/ DataToFill.Add(txtbreite.Text);
           /*5*/ DataToFill.Add(txtmenge.Text);
           /*6*/ DataToFill.Add(txtbeschreibung.Text);
           /*7*/ DataToFill.Add(txteinheit.Text);
           /*8*/ DataToFill.Add(txthpreis.Text);
           /*9*/ DataToFill.Add(txtpreis.Text);
          /*10*/ DataToFill.Add(txtaktbestand.Text);

            for (int rowcounter = 0; rowcounter < (Einheiten.RowCount); rowcounter++)
            {
                if (Convert.ToInt32(Einheiten.Rows[rowcounter].Cells[0].Value) <= 0 || Einheiten.Rows[rowcounter].Cells[0].Value == null)
                {
                    EinheitenFilled = false;
                }
            }

            if (Helfer.TBFilled(DataToFill) && EinheitenFilled)
            {
                NeuesProdukt.ErstelleProdukt(Einheiten, DataToFill);
                DialogResult result = MessageBox.Show("Möchten Sie die Produktionsschritte direkt im Anschluss erstellen?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    NeuesProdukt.OpenProdSchritte(NeededTabControl);
                }
            }
            else
            {
                MessageBox.Show("Bitte füllen Sie alle Felder aus!\nDenken Sie auch an die Mengen-Angaben!");
            }
        }
    }
}
