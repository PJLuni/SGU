﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class RohstoffSuchen : Form
    {
        TabPage TPage = new TabPage();
        TabControl PC;
        public RohstoffSuchen(TabControl PC)
        {
            InitializeComponent();
            this.PC = PC;
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            TPage.Text = "Produkt hinzufügen";
            PC.TabPages.Add(TPage);
            LoadForm.OpenTab(new RohstoffAdd(), TPage);
            PC.SelectedTab = TPage;
        }
    }
}
