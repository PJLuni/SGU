﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FontAwesome.Sharp;
using System.Security.Cryptography;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class LogIn : Form
    {
        IconButton sidebarAuftrag;
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;

        string username = null;
        string usernr = null;
        public LogIn(IconButton sidebarAuftrag)
        {
            InitializeComponent();
            this.sidebarAuftrag = sidebarAuftrag;
        }
        private void benutzername_Enter(object sender, EventArgs e)
        {
            if (benutzername.Text == "Benutzername")
            {
                benutzername.Clear();
                benutzername.ForeColor = Color.Black;
            }
        }
        private void benutzername_Leave(object sender, EventArgs e)
        {
            if (benutzername.Text == "")
            {
                benutzername.Text = "Benutzername";
                benutzername.ForeColor = Color.Gray;
            }
        }
        private void passwort_Enter(object sender, EventArgs e)
        {
            if (passwort.Text == "Passwort")
            {
                passwort.Clear();
                passwort.PasswordChar = '*';
                passwort.ForeColor = Color.Black;
            }
        }
        private void passwort_Leave(object sender, EventArgs e)
        {
            if (passwort.Text == "")
            {
                passwort.Text = "Passwort";
                passwort.ForeColor = Color.Gray;
                passwort.PasswordChar = '\0';
            }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true || passwort.Text == "Passwort")
            {
                passwort.PasswordChar = '\0';
            }
            else if (checkBox1.Checked == false)
            {
                passwort.PasswordChar = '*';
            }
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            CheckingData();
        }
        private string HashPassword(string input, HashAlgorithm algorithm)
        {
            Byte[] inputBytes = Encoding.UTF8.GetBytes(input);
            Byte[] hashedBytes = algorithm.ComputeHash(inputBytes);

            return BitConverter.ToString(hashedBytes);
        }
        private void GetData(string benutzername, string hashedpasswort)
        {
            try
            {
                con.Open();
                cmd = new OleDbCommand($"SELECT Nr FROM Benutzerkonto WHERE Benutzername = '{benutzername}' AND Passwort = '{hashedpasswort}'", con);
                usernr += cmd.ExecuteScalar().ToString();

                cmd = new OleDbCommand($"SELECT Vorname FROM Benutzerkonto WHERE Benutzername = '{benutzername}' AND Passwort = '{hashedpasswort}'", con);
                username += cmd.ExecuteScalar().ToString() + " ";

                cmd = new OleDbCommand($"SELECT Nachname FROM Benutzerkonto WHERE Benutzername = '{benutzername}' AND Passwort = '{hashedpasswort}'", con);
                username += cmd.ExecuteScalar().ToString();
                con.Close();
            }
            catch (Exception Fehler)
            {
                MessageBox.Show("Fehler!!!!!\n\n" + Fehler);
            }
        }
        private void LightsOn()
        {
            sidebarAuftrag.Enabled = true;
        }


        public string Username
        {
            get
            {
                return username;
            }
        }
        public string Usernr
        {
            get
            {
                return usernr;
            }
        }

        private void passwort_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Enter)
            {
                CheckingData();
            }
        }
        private void CheckingData()
        {
            string hashedpasswort = HashPassword(passwort.Text, new SHA256CryptoServiceProvider());

            con.Open();

            cmd = new OleDbCommand($"SELECT count(*) FROM Benutzerkonto WHERE Benutzername = '{benutzername.Text}' AND Passwort = '{hashedpasswort}'", con);
            int userexists = Convert.ToInt16(cmd.ExecuteScalar());

            con.Close();

            if (userexists > 0)
            {
                GetData(benutzername.Text, hashedpasswort);
                LightsOn();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            passwort.PasswordChar = '*';
            benutzername.Text = "admin";
            passwort.Text = "admin";
            CheckingData();
        }
    }
}
