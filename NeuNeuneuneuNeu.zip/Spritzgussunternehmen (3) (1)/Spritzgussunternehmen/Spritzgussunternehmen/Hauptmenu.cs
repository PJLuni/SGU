﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FontAwesome.Sharp;

namespace Spritzgussunternehmen
{
    public partial class Hauptmenu : Form
    {
        private IconButton clickedButton;
        private Panel leftOnClickedButton;
        private Form neededForm;

        private LogIn Login = null;
        private Size NeuePanelSize;
        private Size StandardPanelSize = new Size(173, 60);
        public Hauptmenu()
        {
            InitializeComponent();
            leftOnClickedButton = new Panel();
            leftOnClickedButton.Size = new Size(7, 60);
            sidebar.Controls.Add(leftOnClickedButton);
        }
        //
        // EVENTS
        //
        private void Form1_Load(object sender, EventArgs e)
        {
            LoadForm.OpenPanel(Login = new LogIn(sidebarAuftrag), main);
            ButtonHighlightOn(sidebarLogin);
        }
        private void iconButton1_Click(object sender, EventArgs e)
        {
            ButtonHighlightOn(sender);
            LoadForm.OpenPanel(new LogIn(sidebarAuftrag), main);
        }
        private void iconButton2_Click(object sender, EventArgs e)
        {
            ButtonHighlightOn(sender);
        }
        private void iconButton3_Click(object sender, EventArgs e)
        {
            ButtonHighlightOn(sender);
        }
        private void iconButton4_Click(object sender, EventArgs e)
        {
            ButtonHighlightOn(sender);
        }
        private void iconButton6_Click(object sender, EventArgs e)
        {
            ButtonHighlightOn(sender);
        }
        private void topbarLogout_Click(object sender, EventArgs e)
        {
            LightsOff();
        }
        private void topbarClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void topbarSettings_Click(object sender, EventArgs e)
        {
            LoadForm.OpenPanel(new ChangePW(sachname.Text), main);
            ButtonHighlightOff();
        }
        private void sachname_SizeChanged(object sender, EventArgs e)
        {
            Size username = sachname.Size;
            NeuePanelSize += username;
            panel5.Size += NeuePanelSize;
        }
        private void sidebarAuftrag_EnabledChanged(object sender, EventArgs e)
        {
            if (sidebarAuftrag.Enabled == true)
            {
                sidebarLieferung.Enabled = true;
                sidebarRechnung.Enabled = true;
                sidebarStammdaten.Enabled = true;
                sidebarStatus.Enabled = true;
                sideKunde.Enabled = true;
                sideMitarbeiter.Enabled = true;
                sideMwSt.Enabled = true;
                sidePalette.Enabled = true;
                sideProdukt.Enabled = true;
                sideRohstoff.Enabled = true;
                sideVerpackung.Enabled = true;
                topbarLogout.Enabled = true;
                topbarSettings.Enabled = true;

                main.Controls.Clear();
                LoadForm.OpenPanel(new MainMenuPlaceholder(), main);

                sachname.Text = Login.Usernr;
                sachnr.Text = Login.Username;

                sachname.Visible = true;
                sachnr.Visible = true;
            }
            else
            {
                sidebarLieferung.Enabled = false;
                sidebarRechnung.Enabled = false;
                sidebarStammdaten.Enabled = false;
                sidebarStatus.Enabled = false;
                sideKunde.Enabled = false;
                sideMitarbeiter.Enabled = false;
                sideMwSt.Enabled = false;
                sidePalette.Enabled = false;
                sideProdukt.Enabled = false;
                sideRohstoff.Enabled = false;
                sideVerpackung.Enabled = false;
                topbarLogout.Enabled = false;
                topbarSettings.Enabled = false;

                sachname.Visible = false;
                sachnr.Visible = false;
            }
        }
        //
        // GESCHRIEBENE METHODEN
        //
        private void ButtonHighlightOn(object sender)
        {
            if (sender != null)
            {
                ButtonHighlightOff();

                clickedButton = (IconButton)sender;
                clickedButton.BackColor = Color.FromArgb(55, 55, 55);
                clickedButton.ForeColor = Color.Coral;
                clickedButton.TextAlign = ContentAlignment.MiddleCenter;
                clickedButton.TextImageRelation = TextImageRelation.TextBeforeImage;
                clickedButton.ImageAlign = ContentAlignment.MiddleRight;

                leftOnClickedButton.BackColor = Color.Coral;
                leftOnClickedButton.Location = new Point(0, clickedButton.Location.Y);
                leftOnClickedButton.Visible = true;
                leftOnClickedButton.BringToFront();
            }
        }
        private void ButtonHighlightOff()
        {
            if (clickedButton != null)
            {
                clickedButton.BackColor = Color.FromArgb(46, 46, 46);
                clickedButton.ForeColor = Color.White;
                clickedButton.TextAlign = ContentAlignment.MiddleLeft;
                clickedButton.TextImageRelation = TextImageRelation.ImageBeforeText;
                clickedButton.ImageAlign = ContentAlignment.MiddleLeft;
                leftOnClickedButton.Visible = false;
            }
        }
        private void LightsOff()
        {
            sidebarAuftrag.Enabled = false;
        }

        private bool P1_isaktivirt = false;
        private void sidebarStammdaten_Click(object sender, EventArgs e)
        {
            if (P1_isaktivirt == false)
            {
                for (int i = 57; i <= 400; i++)
                {
                    panel1.Size = new Size(247, i);
                }
                P1_isaktivirt = true;

            }
            else
            {
                for (int i = 400; i >= 57; i--)
                {
                    panel1.Size = new Size(247, i);
                }
                P1_isaktivirt = false;
            }
        }

        int firstwindow = 0;
        private void sideProdukt_Click(object sender, EventArgs e)
        {
            firstwindow++;
            if(firstwindow == 1)
            {
                LoadForm.OpenPanel(new Stammdaten(sideProdukt), main);
            }
            else if (Error.ShowWarning() == true)
            {
                LoadForm.OpenPanel(new Stammdaten(sideProdukt), main);
            }
        }

        private void sideKunde_Click(object sender, EventArgs e)
        {
            firstwindow++;
            if (firstwindow == 1)
            {
                LoadForm.OpenPanel(new Stammdaten(sideKunde), main);
            }
            else if (Error.ShowWarning() == true)
            {
                LoadForm.OpenPanel(new Stammdaten(sideKunde), main);
            }
        }

        private void sideMitarbeiter_Click(object sender, EventArgs e)
        {
            firstwindow++;
            if (firstwindow == 1)
            {
                LoadForm.OpenPanel(new Stammdaten(sideMitarbeiter), main);
            }
            else if (Error.ShowWarning() == true)
            {
                LoadForm.OpenPanel(new Stammdaten(sideMitarbeiter), main);
            }
        }

        private void sidePalette_Click(object sender, EventArgs e)
        {
            firstwindow++;
            if (firstwindow == 1)
            {
                LoadForm.OpenPanel(new Stammdaten(sidePalette), main);
            }
            else if (Error.ShowWarning() == true)
            {
                LoadForm.OpenPanel(new Stammdaten(sidePalette), main);
            }
        }

        private void sideVerpackung_Click(object sender, EventArgs e)
        {
            firstwindow++;
            if (firstwindow == 1)
            {
                LoadForm.OpenPanel(new Stammdaten(sideRohstoff), main);
            }
            else if (Error.ShowWarning() == true)
            {
                LoadForm.OpenPanel(new Stammdaten(sideRohstoff), main);
            }
        }

        private void sideMwSt_Click(object sender, EventArgs e)
        {
            firstwindow++;
            if (firstwindow == 1)
            {
                LoadForm.OpenPanel(new Stammdaten(sideMwSt), main);
            }
            else if (Error.ShowWarning() == true)
            {
                LoadForm.OpenPanel(new Stammdaten(sideMwSt), main);
            }
        }

        private void sideRohstoff_Click(object sender, EventArgs e)
        {
            firstwindow++;
            if (firstwindow == 1)
            {
                LoadForm.OpenPanel(new Stammdaten(sideRohstoff), main);
            }
            else if (Error.ShowWarning() == true)
            {
                LoadForm.OpenPanel(new Stammdaten(sideRohstoff), main);
            }
        }

        private void panel4_Click(object sender, EventArgs e)
        {
            main.Controls.Clear();
            WebBrowser WB = new WebBrowser();
            WB.Url = new Uri("https://hackthebox.eu");
            WB.Dock = DockStyle.Fill;
            main.Controls.Add(WB);
        }
    }
}
