﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Rohstoff
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        OleDbDataAdapter adap = null;

        DataSet ds = new DataSet();
        public void LoadRohstoffe(ComboBox comboBox)
        {
            cmd = new OleDbCommand("SELECT Nr FROM Rohstoff WHERE IsActive = true", con);
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetInt32(0));
            }
            con.Close();
        }

        public void SuchenDataGridFuellen(DataGridView DataGrid)
        {
            adap = new OleDbDataAdapter("SELECT * FROM Rohstoff WHERE IsActive = true", con);

            ds.Clear();

            adap.Fill(ds, "Rohstoffe");

            DataGrid.DataSource = ds;
            DataGrid.DataMember = "Rohstoffe";
        }

        public void LoadEinheiten(ComboBox comboBox)
        {
            cmd = new OleDbCommand("SELECT Bez FROM Mengeneinheit", con);
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetString(0));
            }
            con.Close();
        }
        public void ErstelleRohstoff(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Bez = Data[1];
                    int Menge = Int32.Parse(Data[2]);
                    string Preis = Data[4].Replace(",", ".");

                    cmd = new OleDbCommand($"SELECT count(*) FROM Rohstoff WHERE Nr = {Nr}", con);
                    con.Open();
                    int rohexist = Convert.ToInt32(cmd.ExecuteScalar());
                    con.Close();

                    if (rohexist <= 0)
                    {
                        cmd = new OleDbCommand($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{Data[3]}'", con);
                        con.Open();
                        int Einheit = Convert.ToInt32(cmd.ExecuteScalar());
                        con.Close();

                        cmd = new OleDbCommand($"INSERT INTO Rohstoff (Nr, Bez, Lagerbestand, Mengeneinheit, Kosten, IsActive) " +
                                               $"VALUES ({Nr}, '{Bez}', {Menge}, {Einheit}, {Preis}, true)", con);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        Info.Success("Rohstoff wurde erfolgreich hinzugefügt!");
                    }
                    else
                    {
                        Info.Error("Rohstoff existiert bereits!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }

        public void BearbeiteRohstoff(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Bez = Data[1];
                    int Menge = Int32.Parse(Data[2]);
                    string Preis = Data[4].Replace(",", ".");

                    cmd = new OleDbCommand($"SELECT count(*) FROM Rohstoff WHERE Nr = {Nr}", con);
                    con.Open();
                    int rohexist = Convert.ToInt32(cmd.ExecuteScalar());
                    con.Close();

                    if (rohexist > 0)
                    {
                        cmd = new OleDbCommand($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{Data[3]}'", con);
                        con.Open();
                        int Einheit = Convert.ToInt32(cmd.ExecuteScalar());
                        con.Close();

                        cmd = new OleDbCommand($"UPDATE Rohstoff SET Bez = '{Bez}', Lagerbestand = {Menge}, Mengeneinheit = {Einheit}, Kosten = {Preis}, IsActive = true WHERE Nr = {Nr}", con);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        Info.Success("Rohstoff wurde erfolgreich bearbeitet!");
                    }
                    else
                    {
                        Info.Error("Rohstoff existiert nicht!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }

        public void LoescheRohstoff(DataGridView DataGrid)
        {
            DialogResult result = MessageBox.Show("Sind Sie sicher das Sie den ausgewählten Rohstoff löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                if (DataGrid.SelectedRows.Count != 0)
                {
                    DataGridViewRow row = DataGrid.SelectedRows[0];
                    string ZuLoeschen = row.Cells[0].Value.ToString();

                    cmd = new OleDbCommand($"SELECT count(*) FROM Rohstoff WHERE Nr = {ZuLoeschen}", con);
                    con.Open();
                    int rohexist = Convert.ToInt32(cmd.ExecuteScalar());
                    con.Close();

                    if (rohexist > 0)
                    { 
                        cmd = new OleDbCommand($"UPDATE Rohstoff SET IsActive = false WHERE Nr = {ZuLoeschen}", con);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        DataGrid.Rows.Remove(row);

                        Info.Success("Rohstoff wurde erfolgreich gelöscht!");
                    }
                    else
                    {
                        Info.Error("Rohstoff existiert nicht!");
                    }
                }
                else
                {
                    Info.Error("Bitte wählen Sie einen Rohstoff aus!");
                }
            }
        }
    }
}
