﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class RohstoffSuchen : Form
    {
        Rohstoff Rohstoff = new Rohstoff();
        Helfer Manni = new Helfer();
        public RohstoffSuchen()
        {
            InitializeComponent();
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            List<string> DataToFill = new List<string>();
            DataToFill.Add(txtnr.Text);
            DataToFill.Add(txtbez.Text);
            DataToFill.Add(txtmenge.Text);
            DataToFill.Add(txteinheit.Text);
            DataToFill.Add(txtpreis.Text);

            switch (btnrohadd.Text)
            {
                case "Rohstoff hinzufügen":
                    Rohstoff.ErstelleRohstoff(DataToFill);
                    break;
                case "Rohstoff bearbeiten":
                    Rohstoff.BearbeiteRohstoff(DataToFill);
                    break;
            }

            Rohstoffe.DataSource = null;
            Rohstoff.SuchenDataGridFuellen(Rohstoffe);
        }

        private void RohstoffSuchen_Load(object sender, EventArgs e)
        {
            Rohstoff.LoadEinheiten(txteinheit);
            Rohstoff.SuchenDataGridFuellen(Rohstoffe);
            txtnr.Text = Manni.LetzteNummer("Rohstoff").ToString();
            Rohstoffe.ClearSelection();
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            Rohstoff.LoescheRohstoff(Rohstoffe);
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if(txtnr.Enabled == false)
            {
                txtnr.Enabled = true;
                txtnr.Clear();
            }
            else
            {
                txtnr.Enabled = false;
                txtnr.Text = Manni.LetzteNummer("Rohstoff").ToString();
            }
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            if(btnrohadd.Text == "Rohstoff hinzufügen")
            {
                txtnr.Text = Manni.LetzteNummer("Rohstoff").ToString();
                txtbez.Clear();
                txtpreis.Clear();
                txtmenge.Clear();
                txteinheit.SelectedItem = null;
                checknr.Checked = false;
                txtnr.Enabled = false;
            }
            else
            {
                txtnr.Text = Manni.LetzteNummer("Rohstoff").ToString();
                txtbez.Clear();
                txtpreis.Clear();
                txtmenge.Clear();
                txteinheit.SelectedItem = null;
                Rohstoffe.ClearSelection();
                btnrohadd.Text = "Rohstoff hinzufügen";
                checknr.Enabled = true;
                checknr.Checked = false;
                txtnr.Enabled = false;
            }
        }

        private void Rohstoffe_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (Rohstoffe.SelectedRows.Count > 0)
                {
                    int RNr = Convert.ToInt32(Rohstoffe.SelectedRows[0].Cells[0].Value);
                    double Preis = Convert.ToDouble(Rohstoffe.SelectedRows[0].Cells[4].Value);
                    string Bez = Rohstoffe.SelectedRows[0].Cells[1].Value.ToString();
                    int Bestand = Convert.ToInt32(Rohstoffe.SelectedRows[0].Cells[2].Value);

                    int MengeNr = Convert.ToInt32(Rohstoffe.SelectedRows[0].Cells[3].Value);
                    string MengeBez = Manni.getMengenBez(MengeNr);

                    txtnr.Text = RNr.ToString();
                    txtpreis.Text = Preis.ToString();
                    txtbez.Text = Bez;
                    txtmenge.Text = Bestand.ToString();
                    txteinheit.Text = MengeBez;

                    btnrohadd.Text = "Rohstoff bearbeiten";
                    checknr.Enabled = false;
                    checknr.Checked = false;
                    txtnr.Enabled = false;
                }
            }
            catch (Exception err)
            {
                throw err;
            }
        }

        private void txtmenge_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtpreis_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsPunctuation(e.KeyChar);
        }

        private void txtnr_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
