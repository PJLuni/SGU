﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Produkt
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        OleDbDataAdapter adap = null;

        DataSet ds = new DataSet();
        public void LoadProdukte(ComboBox comboBox)
        {
            cmd = new OleDbCommand("SELECT Nr FROM Produkt WHERE IsActive = true", con);
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetInt32(0));
            }
            con.Close();
        }

        public void LoadProdSchritt(ComboBox comboBox, int ProdNr)
        {
            cmd = new OleDbCommand($"SELECT count(*) FROM Produktionsschritt WHERE Produkt = {ProdNr}", con);
            con.Open();
            int ProdCount = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            if (ProdCount > 0)
            {
                cmd = new OleDbCommand($"SELECT Nr FROM Produktionsschritt WHERE Produkt = {ProdNr}", con);
                con.Open();
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    comboBox.Items.Add(dr.GetInt32(0));
                }
                con.Close();
            }
        }

        public string GetSelectedProdSchritt(int ProdNr)
        {
            cmd = new OleDbCommand($"SELECT Bez FROM Produkt WHERE Nr = {ProdNr}", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            string Bez = dr.GetString(0);
            con.Close();
            return Bez;
        }

        public void LoadEinheiten(ComboBox comboBox)
        {
            cmd = new OleDbCommand("SELECT Bez FROM Mengeneinheit", con);
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetString(0));
            }
            con.Close();
        }

        public void LoadArten(ComboBox comboBox)
        {
            cmd = new OleDbCommand("SELECT Bez FROM Produktart", con);
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetString(0));
            }
            con.Close();
        }

        public void SuchenDataGridFuellen(DataGridView DataGrid)
        {
            adap = new OleDbDataAdapter("SELECT * FROM Produkt WHERE IsActive = true", con);

            ds.Clear();

            adap.Fill(ds, "Produkte");

            DataGrid.DataSource = ds;
            DataGrid.DataMember = "Produkte";
        }

        public void VerpackungsDataGridFuellen(DataGridView DataGrid)
        {
            adap = new OleDbDataAdapter($"SELECT Bez as Verpackung FROM Verpackungseinheit WHERE IsActive = true", con);
            ds.Clear();

            adap.Fill(ds, "Einheiten");

            DataGrid.DataSource = ds;
            DataGrid.DataMember = "Einheiten";
            DataGrid.Columns[1].ReadOnly = true;
            DataGrid.Columns[1].DisplayIndex = 0;

            foreach (DataGridViewRow Row in DataGrid.Rows)
            {
                if (Row.Cells[1].Value.ToString() == "Stück")
                {
                    DataGrid.Rows.Remove(Row);
                }
            }
        }

        public void ErstelleProdukt(DataGridView DGV, List<string> Data)
        {
            try
            {
                string Bez = Data[0];
                int Hoehe = Convert.ToInt32(Data[2]);
                int Laenge = Convert.ToInt32(Data[3]);
                int Breite = Convert.ToInt32(Data[4]);
                int Gewicht = Convert.ToInt32(Data[5]);
                string Beschreibung = Data[6];
                string HPreis = Data[8].Replace(",", ".");
                string Preis = Data[9].Replace(",", ".");
                int AktBestand = Convert.ToInt32(Data[10]);

                cmd = new OleDbCommand($"SELECT Nr FROM Produktart WHERE Bez = '{Data[1]}'", con);
                con.Open();
                int Produktart = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();

                cmd = new OleDbCommand($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{Data[7]}'", con);
                con.Open();
                int Produkteinheit = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();

                int PNr = LetzteNummer("Produkt");
                cmd = new OleDbCommand($"INSERT INTO Produkt (Nr, Art, Bez, Hoehe, Breite, Laenge, Gewicht, Produktbeschreibung, Preis, Lagerbestand, Herstellungskosten, Gewichtseinheit, IsActive) " +
                                       $"VALUES ({PNr}, {Produktart}, '{Bez}', {Hoehe}, {Breite}, {Laenge}, {Gewicht}, '{Beschreibung}' ,{Preis}, {AktBestand}, {HPreis}, {Produkteinheit}, true)", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                for (int rowcounter = 0; rowcounter < (DGV.RowCount); rowcounter++)
                {
                    cmd = new OleDbCommand($"SELECT Nr FROM Verpackungseinheit WHERE Bez = '{DGV.Rows[rowcounter].Cells[1].Value}'", con);
                    con.Open();
                    int Verpackung = Convert.ToInt32(cmd.ExecuteScalar());
                    con.Close();

                    int Menge = Convert.ToInt32(DGV.Rows[rowcounter].Cells[0].Value);
                    int VENr = Convert.ToInt32(LetzteNummer("Produktverpackungseinheit"));


                    cmd = new OleDbCommand($"INSERT INTO ProduktVerpackungseinheit (Nr, Produkt, Verpackungseinheit, Menge, IsActive) values ({VENr}, {PNr}, {Verpackung}, {Menge}, true)", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
            
        }

        public void BearbeiteProdukt()
        {

        }

        public void LoescheProdukt(DataGridView DataGrid)
        {
            DialogResult result = MessageBox.Show("Sind Sie sicher das Sie das ausgewählte Produkt löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                DataGridViewRow row = DataGrid.SelectedRows[0];
                string ZuLoeschen = row.Cells[0].Value.ToString();

                cmd = new OleDbCommand($"UPDATE Produkt SET IsActive = false WHERE Nr = {ZuLoeschen}", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                DataGrid.Rows.Remove(row);
            }
        }

        public void ErstelleProdSchritt()
        {

        }
    
        private int LetzteNummer(string Tabelle)
        {
            cmd = new OleDbCommand($"SELECT max(Nr) FROM {Tabelle}", con);
            con.Open();
            int Nr = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            return Nr + 1;
        }

        public void OpenProdSchritte(TabControl TabControlToLoadIn)
        {
            TabPage TPPS = new TabPage();
            TPPS.Text = "Produktionsschritt";
            TabControlToLoadIn.TabPages.Add(TPPS);
            LoadForm.OpenTab(new ProdSchritt(), TPPS);
        }
    }
}
