﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.rot = new System.Windows.Forms.Timer(this.components);
            this.gelbGruen = new System.Windows.Forms.Timer(this.components);
            this.gruen = new System.Windows.Forms.Timer(this.components);
            this.gelbRot = new System.Windows.Forms.Timer(this.components);
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.picGruen2 = new FontAwesome.Sharp.IconPictureBox();
            this.picGelb2 = new FontAwesome.Sharp.IconPictureBox();
            this.picRot2 = new FontAwesome.Sharp.IconPictureBox();
            this.Laufzeit = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.picGruen = new FontAwesome.Sharp.IconPictureBox();
            this.picGelb = new FontAwesome.Sharp.IconPictureBox();
            this.picRot = new FontAwesome.Sharp.IconPictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.picGruenLeft = new FontAwesome.Sharp.IconPictureBox();
            this.picGelbLeft = new FontAwesome.Sharp.IconPictureBox();
            this.picRotLeft = new FontAwesome.Sharp.IconPictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGruen2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGelb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRot2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGruen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGelb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRot)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGruenLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGelbLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRotLeft)).BeginInit();
            this.SuspendLayout();
            // 
            // rot
            // 
            this.rot.Enabled = true;
            this.rot.Interval = 20000;
            this.rot.Tick += new System.EventHandler(this.rot_Tick);
            // 
            // gelbGruen
            // 
            this.gelbGruen.Interval = 3000;
            this.gelbGruen.Tick += new System.EventHandler(this.gelbGruen_Tick);
            // 
            // gruen
            // 
            this.gruen.Interval = 30000;
            this.gruen.Tick += new System.EventHandler(this.gruen_Tick);
            // 
            // gelbRot
            // 
            this.gelbRot.Interval = 3000;
            this.gelbRot.Tick += new System.EventHandler(this.gelbRot_Tick);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pictureBox7.Location = new System.Drawing.Point(12, 49);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(517, 14);
            this.pictureBox7.TabIndex = 12;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pictureBox8.Location = new System.Drawing.Point(515, 49);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(14, 381);
            this.pictureBox8.TabIndex = 13;
            this.pictureBox8.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.picGruen2);
            this.panel2.Controls.Add(this.picGelb2);
            this.panel2.Controls.Add(this.picRot2);
            this.panel2.Location = new System.Drawing.Point(342, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(35, 100);
            this.panel2.TabIndex = 17;
            // 
            // picGruen2
            // 
            this.picGruen2.ForeColor = System.Drawing.Color.Black;
            this.picGruen2.IconChar = FontAwesome.Sharp.IconChar.Circle;
            this.picGruen2.IconColor = System.Drawing.Color.Black;
            this.picGruen2.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.picGruen2.IconSize = 35;
            this.picGruen2.Location = new System.Drawing.Point(1, 67);
            this.picGruen2.Name = "picGruen2";
            this.picGruen2.Size = new System.Drawing.Size(35, 35);
            this.picGruen2.TabIndex = 16;
            this.picGruen2.TabStop = false;
            // 
            // picGelb2
            // 
            this.picGelb2.ForeColor = System.Drawing.Color.Black;
            this.picGelb2.IconChar = FontAwesome.Sharp.IconChar.Circle;
            this.picGelb2.IconColor = System.Drawing.Color.Black;
            this.picGelb2.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.picGelb2.IconSize = 35;
            this.picGelb2.Location = new System.Drawing.Point(1, 35);
            this.picGelb2.Name = "picGelb2";
            this.picGelb2.Size = new System.Drawing.Size(35, 35);
            this.picGelb2.TabIndex = 15;
            this.picGelb2.TabStop = false;
            // 
            // picRot2
            // 
            this.picRot2.ForeColor = System.Drawing.Color.Black;
            this.picRot2.IconChar = FontAwesome.Sharp.IconChar.Circle;
            this.picRot2.IconColor = System.Drawing.Color.Black;
            this.picRot2.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.picRot2.IconSize = 35;
            this.picRot2.Location = new System.Drawing.Point(1, 3);
            this.picRot2.Name = "picRot2";
            this.picRot2.Size = new System.Drawing.Size(35, 35);
            this.picRot2.TabIndex = 14;
            this.picRot2.TabStop = false;
            // 
            // Laufzeit
            // 
            this.Laufzeit.Interval = 1000;
            this.Laufzeit.Tick += new System.EventHandler(this.Laufzeit_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 412);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 18);
            this.label1.TabIndex = 18;
            this.label1.Text = "Laufzeit: 0000s";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Controls.Add(this.picGruen);
            this.panel3.Controls.Add(this.picGelb);
            this.panel3.Controls.Add(this.picRot);
            this.panel3.Location = new System.Drawing.Point(503, 224);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(35, 100);
            this.panel3.TabIndex = 19;
            // 
            // picGruen
            // 
            this.picGruen.ForeColor = System.Drawing.Color.Black;
            this.picGruen.IconChar = FontAwesome.Sharp.IconChar.Circle;
            this.picGruen.IconColor = System.Drawing.Color.Black;
            this.picGruen.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.picGruen.IconSize = 35;
            this.picGruen.Location = new System.Drawing.Point(1, 67);
            this.picGruen.Name = "picGruen";
            this.picGruen.Size = new System.Drawing.Size(35, 35);
            this.picGruen.TabIndex = 16;
            this.picGruen.TabStop = false;
            // 
            // picGelb
            // 
            this.picGelb.ForeColor = System.Drawing.Color.Black;
            this.picGelb.IconChar = FontAwesome.Sharp.IconChar.Circle;
            this.picGelb.IconColor = System.Drawing.Color.Black;
            this.picGelb.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.picGelb.IconSize = 35;
            this.picGelb.Location = new System.Drawing.Point(1, 35);
            this.picGelb.Name = "picGelb";
            this.picGelb.Size = new System.Drawing.Size(35, 35);
            this.picGelb.TabIndex = 15;
            this.picGelb.TabStop = false;
            // 
            // picRot
            // 
            this.picRot.ForeColor = System.Drawing.Color.Black;
            this.picRot.IconChar = FontAwesome.Sharp.IconChar.Circle;
            this.picRot.IconColor = System.Drawing.Color.Black;
            this.picRot.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.picRot.IconSize = 35;
            this.picRot.Location = new System.Drawing.Point(1, 3);
            this.picRot.Name = "picRot";
            this.picRot.Size = new System.Drawing.Size(35, 35);
            this.picRot.TabIndex = 14;
            this.picRot.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.picGruenLeft);
            this.panel1.Controls.Add(this.picGelbLeft);
            this.panel1.Controls.Add(this.picRotLeft);
            this.panel1.Location = new System.Drawing.Point(89, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(35, 100);
            this.panel1.TabIndex = 20;
            // 
            // picGruenLeft
            // 
            this.picGruenLeft.ForeColor = System.Drawing.Color.Black;
            this.picGruenLeft.IconChar = FontAwesome.Sharp.IconChar.ArrowAltCircleLeft;
            this.picGruenLeft.IconColor = System.Drawing.Color.Black;
            this.picGruenLeft.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.picGruenLeft.IconSize = 35;
            this.picGruenLeft.Location = new System.Drawing.Point(1, 67);
            this.picGruenLeft.Name = "picGruenLeft";
            this.picGruenLeft.Size = new System.Drawing.Size(35, 35);
            this.picGruenLeft.TabIndex = 16;
            this.picGruenLeft.TabStop = false;
            // 
            // picGelbLeft
            // 
            this.picGelbLeft.ForeColor = System.Drawing.Color.Black;
            this.picGelbLeft.IconChar = FontAwesome.Sharp.IconChar.ArrowCircleLeft;
            this.picGelbLeft.IconColor = System.Drawing.Color.Black;
            this.picGelbLeft.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.picGelbLeft.IconSize = 35;
            this.picGelbLeft.Location = new System.Drawing.Point(1, 35);
            this.picGelbLeft.Name = "picGelbLeft";
            this.picGelbLeft.Size = new System.Drawing.Size(35, 35);
            this.picGelbLeft.TabIndex = 15;
            this.picGelbLeft.TabStop = false;
            // 
            // picRotLeft
            // 
            this.picRotLeft.ForeColor = System.Drawing.Color.Black;
            this.picRotLeft.IconChar = FontAwesome.Sharp.IconChar.ArrowCircleLeft;
            this.picRotLeft.IconColor = System.Drawing.Color.Black;
            this.picRotLeft.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.picRotLeft.IconSize = 35;
            this.picRotLeft.Location = new System.Drawing.Point(1, 3);
            this.picRotLeft.Name = "picRotLeft";
            this.picRotLeft.Size = new System.Drawing.Size(35, 35);
            this.picRotLeft.TabIndex = 14;
            this.picRotLeft.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(560, 439);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox8);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picGruen2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGelb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRot2)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picGruen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGelb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRot)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picGruenLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGelbLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRotLeft)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer rot;
        private System.Windows.Forms.Timer gelbGruen;
        private System.Windows.Forms.Timer gruen;
        private System.Windows.Forms.Timer gelbRot;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Panel panel2;
        private FontAwesome.Sharp.IconPictureBox picGruen2;
        private FontAwesome.Sharp.IconPictureBox picGelb2;
        private FontAwesome.Sharp.IconPictureBox picRot2;
        private System.Windows.Forms.Timer Laufzeit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private FontAwesome.Sharp.IconPictureBox picGruen;
        private FontAwesome.Sharp.IconPictureBox picGelb;
        private FontAwesome.Sharp.IconPictureBox picRot;
        private System.Windows.Forms.Panel panel1;
        private FontAwesome.Sharp.IconPictureBox picGruenLeft;
        private FontAwesome.Sharp.IconPictureBox picGelbLeft;
        private FontAwesome.Sharp.IconPictureBox picRotLeft;
    }
}

