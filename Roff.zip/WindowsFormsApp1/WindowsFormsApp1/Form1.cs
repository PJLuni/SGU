﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.AliceBlue;
            this.TransparencyKey = Color.AliceBlue;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rot.Start();
            Laufzeit.Start();
            picRot.IconColor = Color.Red;
            picRot2.IconColor = Color.Red;
            picGruenLeft.IconColor = Color.Green;
        }

        private void rot_Tick(object sender, EventArgs e)
        {
            gelbGruen.Enabled = true;
            gelbGruen.Start();
            picGelb.IconColor = Color.Yellow;
            picGelb2.IconColor = Color.Yellow;

            picGruenLeft.IconColor = Color.Black;
            picGelbLeft.IconColor = Color.Yellow;

            rot.Stop();
            rot.Enabled = false;
        }

        private void gelbGruen_Tick(object sender, EventArgs e)
        {
            gruen.Enabled = true;
            gruen.Start();
            picGelb.IconColor = Color.Black;
            picGelb2.IconColor = Color.Black;

            picRot.IconColor = Color.Black;
            picRot2.IconColor = Color.Black;

            picGruen.IconColor = Color.Green;
            picGruen2.IconColor = Color.Green;

            picGelbLeft.IconColor = Color.Black;
            picRotLeft.IconColor = Color.Red;

            gelbGruen.Stop();
            gelbGruen.Enabled = false;
        }

        private void gruen_Tick(object sender, EventArgs e)
        {
            gelbRot.Enabled = true;
            gelbRot.Start();
            picGruen.IconColor = Color.Black;
            picGruen2.IconColor = Color.Black;

            picGelb.IconColor = Color.Yellow;
            picGelb2.IconColor = Color.Yellow;

            picGelbLeft.IconColor = Color.Yellow;

            gruen.Stop();
            gruen.Enabled = false;
        }

        private void gelbRot_Tick(object sender, EventArgs e)
        {
            rot.Enabled = true;
            rot.Start();
            picGelb.IconColor = Color.Black;
            picGelb2.IconColor = Color.Black;

            picRot.IconColor = Color.Red;
            picRot2.IconColor = Color.Red;

            picRotLeft.IconColor = Color.Black;
            picGelbLeft.IconColor = Color.Black;
            picGruenLeft.IconColor = Color.Green;

            gelbRot.Stop();
            gelbRot.Enabled = false;
        }

        private void Ausfall_Tick(object sender, EventArgs e)
        {
            if(picGelbLeft.IconColor == Color.Black)
            {
                picGelbLeft.IconColor = Color.Yellow;
            }
            else
            {
                picGelbLeft.IconColor = Color.Black;
            }
        }

        int LaufzeitTime = 0;
        private void Laufzeit_Tick(object sender, EventArgs e)
        {
            LaufzeitTime += 1;
            label1.Text = "Laufzeit: " + LaufzeitTime + "s";
        }
    }
}
