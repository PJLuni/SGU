﻿
namespace Spritzgussunternehmen
{
    partial class LieferscheinSuchen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.iconButton3 = new FontAwesome.Sharp.IconButton();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.Lieferscheine = new System.Windows.Forms.DataGridView();
            this.iconButton5 = new FontAwesome.Sharp.IconButton();
            this.iconButton6 = new FontAwesome.Sharp.IconButton();
            this.checknr = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtnr = new System.Windows.Forms.TextBox();
            this.txteinheit = new System.Windows.Forms.ComboBox();
            this.btnrohadd = new FontAwesome.Sharp.IconButton();
            this.comboLieferung = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.date = new System.Windows.Forms.DateTimePicker();
            this.comboKunde = new System.Windows.Forms.ComboBox();
            this.txtgewicht = new System.Windows.Forms.NumericUpDown();
            this.panel1 = new System.Windows.Forms.Panel();
            this.paleingang = new System.Windows.Forms.NumericUpDown();
            this.comboPalette = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtsellieferschein = new System.Windows.Forms.TextBox();
            this.palausgang = new System.Windows.Forms.NumericUpDown();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.iconButton8 = new FontAwesome.Sharp.IconButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Paletten = new System.Windows.Forms.DataGridView();
            this.iconButton4 = new FontAwesome.Sharp.IconButton();
            ((System.ComponentModel.ISupportInitialize)(this.Lieferscheine)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtgewicht)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paleingang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.palausgang)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Paletten)).BeginInit();
            this.SuspendLayout();
            // 
            // iconButton3
            // 
            this.iconButton3.BackColor = System.Drawing.Color.White;
            this.iconButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton3.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.iconButton3.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton3.IconSize = 26;
            this.iconButton3.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.iconButton3.Location = new System.Drawing.Point(881, 280);
            this.iconButton3.Name = "iconButton3";
            this.iconButton3.Size = new System.Drawing.Size(107, 27);
            this.iconButton3.TabIndex = 275;
            this.iconButton3.Text = "Suchen";
            this.iconButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton3.UseVisualStyleBackColor = false;
            this.iconButton3.Click += new System.EventHandler(this.iconButton3_Click);
            // 
            // txtsearch
            // 
            this.txtsearch.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearch.Location = new System.Drawing.Point(695, 281);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(180, 26);
            this.txtsearch.TabIndex = 273;
            // 
            // Lieferscheine
            // 
            this.Lieferscheine.AllowUserToAddRows = false;
            this.Lieferscheine.AllowUserToDeleteRows = false;
            this.Lieferscheine.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Lieferscheine.BackgroundColor = System.Drawing.Color.White;
            this.Lieferscheine.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.Lieferscheine.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.NullValue = "--";
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.Chocolate;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Lieferscheine.DefaultCellStyle = dataGridViewCellStyle9;
            this.Lieferscheine.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Lieferscheine.Location = new System.Drawing.Point(10, 313);
            this.Lieferscheine.Name = "Lieferscheine";
            this.Lieferscheine.ReadOnly = true;
            this.Lieferscheine.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.Chocolate;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Lieferscheine.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.Lieferscheine.Size = new System.Drawing.Size(978, 275);
            this.Lieferscheine.TabIndex = 272;
            this.Lieferscheine.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.Lieferscheine_CellEnter);
            this.Lieferscheine.SelectionChanged += new System.EventHandler(this.Lieferscheine_SelectionChanged);
            // 
            // iconButton5
            // 
            this.iconButton5.BackColor = System.Drawing.Color.White;
            this.iconButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton5.IconChar = FontAwesome.Sharp.IconChar.Trash;
            this.iconButton5.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton5.IconSize = 26;
            this.iconButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton5.Location = new System.Drawing.Point(10, 594);
            this.iconButton5.Name = "iconButton5";
            this.iconButton5.Size = new System.Drawing.Size(115, 29);
            this.iconButton5.TabIndex = 278;
            this.iconButton5.Text = "Löschen";
            this.iconButton5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton5.UseVisualStyleBackColor = false;
            this.iconButton5.Click += new System.EventHandler(this.iconButton5_Click);
            // 
            // iconButton6
            // 
            this.iconButton6.BackColor = System.Drawing.Color.White;
            this.iconButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton6.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.iconButton6.IconColor = System.Drawing.Color.DarkRed;
            this.iconButton6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton6.IconSize = 26;
            this.iconButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton6.Location = new System.Drawing.Point(264, 273);
            this.iconButton6.Name = "iconButton6";
            this.iconButton6.Size = new System.Drawing.Size(36, 34);
            this.iconButton6.TabIndex = 292;
            this.iconButton6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton6.UseVisualStyleBackColor = false;
            this.iconButton6.Click += new System.EventHandler(this.iconButton6_Click);
            // 
            // checknr
            // 
            this.checknr.AutoSize = true;
            this.checknr.ForeColor = System.Drawing.Color.White;
            this.checknr.Location = new System.Drawing.Point(10, 102);
            this.checknr.Name = "checknr";
            this.checknr.Size = new System.Drawing.Size(150, 16);
            this.checknr.TabIndex = 291;
            this.checknr.Text = "Nummer selbst wählen";
            this.checknr.UseVisualStyleBackColor = true;
            this.checknr.CheckedChanged += new System.EventHandler(this.checknr_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Chocolate;
            this.label11.Location = new System.Drawing.Point(7, 170);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(106, 18);
            this.label11.TabIndex = 290;
            this.label11.Text = "Teillieferung";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Chocolate;
            this.label17.Location = new System.Drawing.Point(3, 9);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(228, 40);
            this.label17.TabIndex = 281;
            this.label17.Text = "Lieferschein";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Chocolate;
            this.label1.Location = new System.Drawing.Point(7, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 18);
            this.label1.TabIndex = 280;
            this.label1.Text = "Nr";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Chocolate;
            this.label8.Location = new System.Drawing.Point(156, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 18);
            this.label8.TabIndex = 288;
            this.label8.Text = "Kunde";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Chocolate;
            this.label7.Location = new System.Drawing.Point(156, 121);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 18);
            this.label7.TabIndex = 287;
            this.label7.Text = "Einheit";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Chocolate;
            this.label6.Location = new System.Drawing.Point(7, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 18);
            this.label6.TabIndex = 286;
            this.label6.Text = "Gewicht";
            // 
            // txtnr
            // 
            this.txtnr.Enabled = false;
            this.txtnr.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnr.Location = new System.Drawing.Point(10, 70);
            this.txtnr.Name = "txtnr";
            this.txtnr.Size = new System.Drawing.Size(141, 26);
            this.txtnr.TabIndex = 284;
            // 
            // txteinheit
            // 
            this.txteinheit.BackColor = System.Drawing.Color.White;
            this.txteinheit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txteinheit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txteinheit.FormattingEnabled = true;
            this.txteinheit.Location = new System.Drawing.Point(157, 141);
            this.txteinheit.Name = "txteinheit";
            this.txteinheit.Size = new System.Drawing.Size(142, 26);
            this.txteinheit.TabIndex = 285;
            // 
            // btnrohadd
            // 
            this.btnrohadd.BackColor = System.Drawing.Color.White;
            this.btnrohadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrohadd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrohadd.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.btnrohadd.IconColor = System.Drawing.Color.Chocolate;
            this.btnrohadd.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnrohadd.IconSize = 26;
            this.btnrohadd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrohadd.Location = new System.Drawing.Point(9, 273);
            this.btnrohadd.Name = "btnrohadd";
            this.btnrohadd.Size = new System.Drawing.Size(249, 34);
            this.btnrohadd.TabIndex = 279;
            this.btnrohadd.Text = "Lieferschein hinzufügen";
            this.btnrohadd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnrohadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnrohadd.UseVisualStyleBackColor = false;
            this.btnrohadd.Click += new System.EventHandler(this.btnrohadd_Click);
            // 
            // comboLieferung
            // 
            this.comboLieferung.BackColor = System.Drawing.Color.White;
            this.comboLieferung.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboLieferung.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboLieferung.FormattingEnabled = true;
            this.comboLieferung.Location = new System.Drawing.Point(10, 191);
            this.comboLieferung.Name = "comboLieferung";
            this.comboLieferung.Size = new System.Drawing.Size(290, 26);
            this.comboLieferung.TabIndex = 293;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Chocolate;
            this.label2.Location = new System.Drawing.Point(7, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 18);
            this.label2.TabIndex = 294;
            this.label2.Text = "Zustellungsdatum";
            // 
            // date
            // 
            this.date.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.date.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.date.Location = new System.Drawing.Point(9, 241);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(291, 26);
            this.date.TabIndex = 295;
            // 
            // comboKunde
            // 
            this.comboKunde.BackColor = System.Drawing.Color.White;
            this.comboKunde.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboKunde.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboKunde.FormattingEnabled = true;
            this.comboKunde.Location = new System.Drawing.Point(157, 70);
            this.comboKunde.Name = "comboKunde";
            this.comboKunde.Size = new System.Drawing.Size(143, 26);
            this.comboKunde.TabIndex = 296;
            // 
            // txtgewicht
            // 
            this.txtgewicht.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgewicht.Location = new System.Drawing.Point(10, 141);
            this.txtgewicht.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.txtgewicht.Name = "txtgewicht";
            this.txtgewicht.Size = new System.Drawing.Size(141, 26);
            this.txtgewicht.TabIndex = 297;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.iconButton1);
            this.panel1.Controls.Add(this.palausgang);
            this.panel1.Controls.Add(this.paleingang);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.comboPalette);
            this.panel1.Controls.Add(this.txtsellieferschein);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(338, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(295, 298);
            this.panel1.TabIndex = 298;
            this.panel1.Visible = false;
            // 
            // paleingang
            // 
            this.paleingang.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paleingang.Location = new System.Drawing.Point(0, 132);
            this.paleingang.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.paleingang.Name = "paleingang";
            this.paleingang.Size = new System.Drawing.Size(141, 26);
            this.paleingang.TabIndex = 308;
            // 
            // comboPalette
            // 
            this.comboPalette.BackColor = System.Drawing.Color.White;
            this.comboPalette.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboPalette.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboPalette.FormattingEnabled = true;
            this.comboPalette.Location = new System.Drawing.Point(149, 61);
            this.comboPalette.Name = "comboPalette";
            this.comboPalette.Size = new System.Drawing.Size(141, 26);
            this.comboPalette.TabIndex = 307;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Chocolate;
            this.label3.Location = new System.Drawing.Point(-7, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 40);
            this.label3.TabIndex = 300;
            this.label3.Text = "Paletten";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Chocolate;
            this.label4.Location = new System.Drawing.Point(-3, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 18);
            this.label4.TabIndex = 299;
            this.label4.Text = "Lieferschein";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Chocolate;
            this.label5.Location = new System.Drawing.Point(146, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 18);
            this.label5.TabIndex = 305;
            this.label5.Text = "Palette";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Chocolate;
            this.label9.Location = new System.Drawing.Point(146, 111);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 18);
            this.label9.TabIndex = 304;
            this.label9.Text = "Ausgang";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Chocolate;
            this.label10.Location = new System.Drawing.Point(-3, 111);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 18);
            this.label10.TabIndex = 303;
            this.label10.Text = "Eingang";
            // 
            // txtsellieferschein
            // 
            this.txtsellieferschein.Enabled = false;
            this.txtsellieferschein.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsellieferschein.Location = new System.Drawing.Point(0, 61);
            this.txtsellieferschein.Name = "txtsellieferschein";
            this.txtsellieferschein.Size = new System.Drawing.Size(141, 26);
            this.txtsellieferschein.TabIndex = 301;
            // 
            // palausgang
            // 
            this.palausgang.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.palausgang.Location = new System.Drawing.Point(147, 132);
            this.palausgang.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.palausgang.Name = "palausgang";
            this.palausgang.Size = new System.Drawing.Size(141, 26);
            this.palausgang.TabIndex = 309;
            // 
            // iconButton1
            // 
            this.iconButton1.BackColor = System.Drawing.Color.White;
            this.iconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.iconButton1.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 26;
            this.iconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton1.Location = new System.Drawing.Point(0, 264);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(194, 34);
            this.iconButton1.TabIndex = 299;
            this.iconButton1.Text = "Palette hinzufügen";
            this.iconButton1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton1.UseVisualStyleBackColor = false;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // iconButton8
            // 
            this.iconButton8.BackColor = System.Drawing.Color.White;
            this.iconButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton8.IconChar = FontAwesome.Sharp.IconChar.RedoAlt;
            this.iconButton8.IconColor = System.Drawing.Color.DarkRed;
            this.iconButton8.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton8.IconSize = 22;
            this.iconButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton8.Location = new System.Drawing.Point(653, 281);
            this.iconButton8.Name = "iconButton8";
            this.iconButton8.Size = new System.Drawing.Size(36, 26);
            this.iconButton8.TabIndex = 299;
            this.iconButton8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton8.UseVisualStyleBackColor = false;
            this.iconButton8.Click += new System.EventHandler(this.iconButton8_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.iconButton4);
            this.panel2.Controls.Add(this.Paletten);
            this.panel2.Location = new System.Drawing.Point(653, 9);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(335, 266);
            this.panel2.TabIndex = 300;
            // 
            // Paletten
            // 
            this.Paletten.AllowUserToAddRows = false;
            this.Paletten.AllowUserToDeleteRows = false;
            this.Paletten.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Paletten.BackgroundColor = System.Drawing.Color.White;
            this.Paletten.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.Paletten.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.NullValue = "--";
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.Chocolate;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Paletten.DefaultCellStyle = dataGridViewCellStyle11;
            this.Paletten.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Paletten.Location = new System.Drawing.Point(3, 61);
            this.Paletten.Name = "Paletten";
            this.Paletten.ReadOnly = true;
            this.Paletten.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.Chocolate;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Paletten.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.Paletten.Size = new System.Drawing.Size(329, 202);
            this.Paletten.TabIndex = 301;
            // 
            // iconButton4
            // 
            this.iconButton4.BackColor = System.Drawing.Color.White;
            this.iconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton4.IconChar = FontAwesome.Sharp.IconChar.Trash;
            this.iconButton4.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton4.IconSize = 26;
            this.iconButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton4.Location = new System.Drawing.Point(217, 29);
            this.iconButton4.Name = "iconButton4";
            this.iconButton4.Size = new System.Drawing.Size(115, 29);
            this.iconButton4.TabIndex = 301;
            this.iconButton4.Text = "Löschen";
            this.iconButton4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton4.UseVisualStyleBackColor = false;
            this.iconButton4.Click += new System.EventHandler(this.iconButton4_Click);
            // 
            // LieferscheinSuchen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1000, 635);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.iconButton8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtgewicht);
            this.Controls.Add(this.comboKunde);
            this.Controls.Add(this.date);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboLieferung);
            this.Controls.Add(this.iconButton6);
            this.Controls.Add(this.checknr);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtnr);
            this.Controls.Add(this.txteinheit);
            this.Controls.Add(this.btnrohadd);
            this.Controls.Add(this.iconButton5);
            this.Controls.Add(this.iconButton3);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.Lieferscheine);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "LieferscheinSuchen";
            this.Text = "LieferscheinSuchen";
            this.Load += new System.EventHandler(this.LieferscheinSuchen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Lieferscheine)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtgewicht)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paleingang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.palausgang)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Paletten)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private FontAwesome.Sharp.IconButton iconButton3;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.DataGridView Lieferscheine;
        private FontAwesome.Sharp.IconButton iconButton5;
        private FontAwesome.Sharp.IconButton iconButton6;
        private System.Windows.Forms.CheckBox checknr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtnr;
        private System.Windows.Forms.ComboBox txteinheit;
        private FontAwesome.Sharp.IconButton btnrohadd;
        private System.Windows.Forms.ComboBox comboLieferung;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker date;
        private System.Windows.Forms.ComboBox comboKunde;
        private System.Windows.Forms.NumericUpDown txtgewicht;
        private System.Windows.Forms.Panel panel1;
        private FontAwesome.Sharp.IconButton iconButton1;
        private System.Windows.Forms.NumericUpDown palausgang;
        private System.Windows.Forms.NumericUpDown paleingang;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboPalette;
        private System.Windows.Forms.TextBox txtsellieferschein;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private FontAwesome.Sharp.IconButton iconButton8;
        private System.Windows.Forms.Panel panel2;
        private FontAwesome.Sharp.IconButton iconButton4;
        private System.Windows.Forms.DataGridView Paletten;
    }
}