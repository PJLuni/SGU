﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class KundeSuchen : Form
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;

        Form neededForm;
        TabPage KP;
        TabControl TC;
        Panel panel;
        public KundeSuchen(TabControl TC,Panel panel)
        {
            this.panel = panel;
            InitializeComponent();
            this.TC = TC;
        }
     
        private void Kunde_Load(object sender, EventArgs e)
        {
            try
            {
                if (AuftragAdd.kundeAnzeigen == 1)
                {
                    iconButton1.Visible = false;
                    iconButton4.Visible = false;
                    iconButton5.Visible = false;

                    Ansprechpartner.Visible = false;

                    adap = new OleDbDataAdapter("SELECT *,Kunde.Nr as Kd_Nr FROM Kunde Where Kunde.IsActive ", con);
                    edit.DataGridFuellen("Kd_Nr", adap, Kunden);
                    button1.Visible = false;
                    istAktiv_checkBox.Enabled = false;

                }
                else
                {
                    TC.Height = 727;
                    adap = new OleDbDataAdapter("SELECT *,Kunde.Nr as Kd_Nr FROM Kunde ", con);
                    edit.DataGridFuellen("Kd_Nr", adap, Kunden);
                    button1.Visible = false;
                    istAktiv_checkBox.Checked = true;
                    istAktiv_checkBox_CheckedChanged(sender, e);
                }
            }
            catch { }
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            try
            {
                if (Kunden.SelectedRows != null)
                {
                    string Ausgewähltezelle = Kunden.CurrentRow.Cells["Kd_Nr"].Value.ToString();
                    adap = new OleDbDataAdapter("SELECT distinct Auftrag.Kunde from Auftrag, Kunde,Auftragsstatus where Kunde.Nr = Auftrag.Kunde and Auftrag.Kunde = "+ Ausgewähltezelle +" and Auftrag.Status = Auftragsstatus.Nr and Auftrag.Status = 2" +
                        " and Kunde.IsActive = true;", con);
                    con.Open();
                    DataTable dt = new DataTable();
                    DataRow d = dt.NewRow();
                    adap.Fill(dt);
                    con.Close();

                    if (dt.Rows.Count >= 1)
                    {
                        MessageBox.Show("Sie Können den Kunden nicht löschen, da er in einem Auftrag vorkommt der noch in Bearbeitung ist.");
                    }
                    else
                    {
                         DialogResult result = MessageBox.Show("Sind Sie sicher das Sie den ausgewählten Kunden und, wenn angegeben, die zusätzlichen Lieferadressen + Ansprechpartner löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (result == DialogResult.Yes)
                        {

                            con.Open();
                            cmd = new OleDbCommand("Update KundeLieferort set IsActive = false where KundeLieferort.Kunde  =" + Ausgewähltezelle + "", con);
                            dr = cmd.ExecuteReader();
                            dr.Read();
                            con.Close();

                            con.Open();
                            cmd = new OleDbCommand("Update Ansprechpartner set IsActive = false where Ansprechpartner.Kunde = " + Ausgewähltezelle + "", con);
                            dr = cmd.ExecuteReader();
                            dr.Read();
                            con.Close();

                            con.Open();
                            cmd = new OleDbCommand("Update Kunde set IsActive = false where Nr = " + Ausgewähltezelle + "", con);
                            dr = cmd.ExecuteReader();
                            dr.Read();
                            con.Close();

                            MessageBox.Show("Gelöscht.");
                            edit.DataGridFuellen("Kd_Nr", adap, Kunden);
                            istAktiv_checkBox_CheckedChanged(sender, e);
                        }
                    }
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim löschen des Kunden" + a);
            }
        }
        
        TabPage kundehinzufuegen = new TabPage();
        private void iconButton1_Click(object sender, EventArgs e)
        {
            try{
                if (TC.TabPages.Contains(kundehinzufuegen))
                {
                    edit.pageswitch(kundehinzufuegen, TC);
                }
                else
                {
                    kundehinzufuegen.Controls.Clear();
                    long Kunde = 0;
                    kundehinzufuegen.Text = "Kunden hinzufügen";
                    TC.TabPages.Add(kundehinzufuegen);
                    OpenForm(new KundeAdd(Kunde, TC, kundehinzufuegen), kundehinzufuegen);
                    TC.SelectedTab = kundehinzufuegen;
                }
            }
            catch { }
        }
        public void OpenForm(Form FormToOpen,TabPage KundenAdd)
        {
            neededForm = FormToOpen;
            FormToOpen.TopLevel = false;
            FormToOpen.FormBorderStyle = FormBorderStyle.None;
            FormToOpen.Dock = DockStyle.Fill;
            KundenAdd.Controls.Add(FormToOpen);
            KundenAdd.Tag = FormToOpen;
            FormToOpen.BringToFront();
            FormToOpen.Show();
        }
       
        DataTable table;
        private void iconButton3_Click(object sender, EventArgs e)
        {
            try {
                istAktiv_checkBox.Visible = false;
                if (textBox1.TextLength > 0)
                {
                    table = new DataTable();
                    Kunden.DataSource = table;
                    string text = textBox1.Text;

                    if (istAktiv_checkBox.Checked == true)
                    {
                        adap = new OleDbDataAdapter("SELECT *,Kunde.Nr as Kd_Nr FROM Kunde where IsActive = true", con);
                    }
                    else
                    {
                        adap = new OleDbDataAdapter("SELECT  *,Kunde.Nr as Kd_Nr FROM Kunde", con);

                    }
                    istAktiv_checkBox_CheckedChanged(sender, e);
                    ds.Clear();
                    adap.Fill(table);
                    DataView dv = table.DefaultView;
                    dv.RowFilter = "Bez LIKE '" + textBox1.Text + "%'";
                    Kunden.DataSource = dv;
                }
                else
                {
                    MessageBox.Show("Fehler");
                }
            }
            catch { }
            }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Text = "";
                button1.Visible = true;
                textBox1.Visible = false;
                iconButton3.Visible = false;

                if (filter_panel.Visible == false)
                {
                    kundeWohnort_listBox.Items.Clear();
                    land_listBox.Items.Clear();
                    filter_panel.Visible = true;
                    con.Open();
                    cmd = new OleDbCommand("Select Distinct Ort From Kunde Where IsActive = true", con);

                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        kundeWohnort_listBox.Items.Add(dr.GetString(0));
                    }

                    con.Close();

                    con.Open();
                    cmd = new OleDbCommand("Select Distinct Land From Kunde Where IsActive = true", con);

                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        land_listBox.Items.Add(dr.GetString(0));
                    }

                    con.Close();
                }
                else
                {
                    textBox1.Text = "";
                    kundeWohnort_listBox.Visible = false;
                    label1.Visible = false;
                    kundeWohnort_listBox.SelectedItem = null;
                    land_listBox.SelectedItem = null;
                    adap = new OleDbDataAdapter("SELECT  *,Kunde.Nr as Kd_Nr FROM Kunde", con);
                    edit.DataGridFuellen("Kd_Nr", adap, Kunden);
                    istAktiv_checkBox_CheckedChanged(sender, e);
                }
            }
            catch { }
        }
        public void istActive(OleDbDataAdapter adapter)
        {
                foreach (DataGridViewRow r in Kunden.Rows)
                {
                    bool test = Convert.ToBoolean(r.Cells[9].Value);

                    if (test == false)
                    {

                        Kunden.Rows[r.Index].Selected = true;

                        DataGridViewRow row;
                        int length;

                        length = Kunden.SelectedRows.Count;
                        for (int i = length - 1; i >= 0; i--)
                        {
                            row = Kunden.SelectedRows[i];
                            Kunden.Rows.Remove(row);
                        }
                    }
                    else
                    {
                    edit.DataGridFuellen("Nr",adap, Kunden);
                    }
                }
        }

        private void kundeWohnort_listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (kundeWohnort_listBox.SelectedIndex >= 0)
            {
                string Oselected = kundeWohnort_listBox.SelectedItem.ToString();
                string Lselected = land_listBox.SelectedItem.ToString();

                adap = new OleDbDataAdapter("SELECT  *,Kunde.Nr as Kd_Nr FROM Kunde WHERE Ort ='" + Oselected + "'and Land ='" + Lselected + "'", con);
                edit.DataGridFuellen("Kd_Nr", adap, Kunden);
                istAktiv_checkBox_CheckedChanged(sender, e);
            }
            else
            {
                istAktiv_checkBox_CheckedChanged(sender, e);
            }
            
        }
        public void filter(string Lselected)
        {
            try
            {
                adap = new OleDbDataAdapter("SELECT  *,Kunde.Nr as Kd_Nr FROM Kunde WHERE Land ='" + Lselected + "'", con);
                edit.DataGridFuellen("Kd_Nr", adap, Kunden);
                if (istAktiv_checkBox.Checked == false)
                {
                    con.Open();
                    cmd = new OleDbCommand("Select Distinct Ort From Kunde where Land ='" + Lselected + "'", con);

                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        kundeWohnort_listBox.Items.Add(dr.GetString(0));
                    }

                    con.Close();
                }
                else
                {
                    con.Open();
                    cmd = new OleDbCommand("Select Distinct Ort From Kunde where Land ='" + Lselected + "'and IsActive = True ", con);

                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        kundeWohnort_listBox.Items.Add(dr.GetString(0));
                    }

                    con.Close();

                }
            }
            catch { }
        }
        
        private void land_listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            if (land_listBox.SelectedIndex >= 0)
            {

                label1.Visible = true;
                kundeWohnort_listBox.Visible = true;
                string Lselected = land_listBox.SelectedItem.ToString();
               
                kundeWohnort_listBox.Items.Clear();
                istAktiv_checkBox_CheckedChanged(sender, e);
                Kunden.Sort(Kunden.Columns["Kd_Nr"], ListSortDirection.Ascending);
            }
        }

        private void istAktiv_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (land_listBox.SelectedIndex >= 0)
                {

                    if (kundeWohnort_listBox.SelectedIndex >= 0)
                    {
                        if (istAktiv_checkBox.Checked == true)
                        {
                            edit.IstAktiv(adap, Kunden, 9);
                        }
                        else
                        {
                            edit.DataGridFuellen("Kd_Nr", adap, Kunden);
                        }
                    }
                    else
                    {
                        string Lselected = land_listBox.SelectedItem.ToString();
                        kundeWohnort_listBox.Items.Clear();
                        filter(Lselected);
                        if (istAktiv_checkBox.Checked == true)
                        {
                            edit.IstAktiv(adap, Kunden, 9);
                        }
                        else
                        {
                            edit.DataGridFuellen("Kd_Nr", adap, Kunden);
                        }
                    }

                }
                else
                {
                    if (istAktiv_checkBox.Checked == true)
                    {
                        edit.IstAktiv(adap, Kunden, 9);
                    }
                    else
                    {
                        edit.DataGridFuellen("Kd_Nr", adap, Kunden);
                    }

                }
            }
            catch { }
        }
        TabPage kundebearbeiten = new TabPage();
        private void iconButton4_Click(object sender, EventArgs e)
        {
            try
            {
                if (TC.TabPages.Contains(kundebearbeiten))
                {
                    edit.pageswitch(kundebearbeiten, TC);
                }
                else
                {
                    string Ausgewähltezelle = Kunden.CurrentRow.Cells["Kd_Nr"].Value.ToString();

                    cmd = new OleDbCommand("select * from Kunde where Nr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);
                    con.Open();
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    long Kunde = dr.GetInt32(0);
                    con.Close();

                    edit.pageswitch(kundebearbeiten, TC);
                    kundebearbeiten.Controls.Clear();
                    kundebearbeiten.Text = "Kunden Bearbeiten";
                    TC.TabPages.Add(kundebearbeiten);
                    OpenForm(new KundeAdd(Kunde, TC, kundebearbeiten), kundebearbeiten);
                    TC.SelectedTab = kundebearbeiten;
                    KundeAdd.hinzuOderBearbeiten++;
                }
            }
            catch { }
        }
        TabPage ansprechpartnerPage = new TabPage();
        private void Ansprechpartner_Click(object sender, EventArgs e)
        {
            KundeAdd.ansprechpartnerrr=3;
            if (TC.TabPages.Contains(ansprechpartnerPage))
            {
                edit.pageswitch(ansprechpartnerPage, TC);
            }
            else
            {
                string Kunde = null;

                Ansprechpartner ansprechpartner = new Ansprechpartner(Kunde, TC, ansprechpartnerPage);

              
                ansprechpartnerPage.Controls.Clear();

                ansprechpartnerPage.Text = "Ansprechpartner";
                TC.TabPages.Add(ansprechpartnerPage);
                LoadForm.OpenTab(ansprechpartner, ansprechpartnerPage);
                TC.SelectedTab = ansprechpartnerPage;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.TextLength == 0)
            {
                istAktiv_checkBox.Visible = true;
               adap = new OleDbDataAdapter("SELECT  *,Kunde.Nr as Kd_Nr From Kunde", con);
               edit.DataGridFuellen("Kd_Nr",adap, Kunden);
               istAktiv_checkBox_CheckedChanged(sender, e);
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Visible = true;
            iconButton3.Visible = true;
            filter_panel.Visible = false;
            button1.Visible = false;
            istAktiv_checkBox.Visible = true;
            adap = new OleDbDataAdapter("SELECT  *,Kunde.Nr as Kd_Nr From Kunde", con);
            edit.DataGridFuellen("Kd_Nr",adap, Kunden);
            istAktiv_checkBox_CheckedChanged(sender, e);
        }

        private void KundeSuchen_Enter(object sender, EventArgs e)
        {
            Kunde_Load(sender, e);
            land_listBox_SelectedIndexChanged(sender, e);
            kundeWohnort_listBox_SelectedIndexChanged(sender, e);
            edit.IstAktiv(adap, Kunden, 9);
          
        }
        private void Kunden_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Kunde_Load(sender, e);
        }

        private void Kunden_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try {
                if (AuftragAdd.kundeAnzeigen == 1)
                {
                    string Ausgewähltezelle = Kunden.CurrentRow.Cells["Kd_Nr"].Value.ToString();

                    cmd = new OleDbCommand("select Kunde.Nr from Kunde where Nr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);
                    con.Open();
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    AuftragAdd.kunde = dr.GetInt32(0);
                    con.Close();
                    AuftragAdd.kundeAnzeigen = 0;
                    Close();
                }
            }
            catch { }
            }
        private void Kunden_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try {
            foreach (DataGridViewRow dataRow in Kunden.Rows)
            {
                if (dataRow.Cells[9].Selected == true)
                {

                    if ((bool)dataRow.Cells[9].Value == false)
                    {
                        DialogResult result = MessageBox.Show("Wollen sie den status von IstAktiv von dem Ausgewählten Kunden wirklich ändern?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (result == DialogResult.Yes)
                            {

                                string Ausgewähltezelle = Kunden.CurrentRow.Cells["Kd_Nr"].Value.ToString();
                                con.Open();
                                cmd = new OleDbCommand("update Kunde set IsActive = True where Nr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);
                                cmd.ExecuteNonQuery();
                                con.Close();
                            }

                        }

                    }


                }

            }
            catch { }

        }
    }
}
