﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Produkt
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        OleDbDataAdapter adap = null;

        DataSet ds = new DataSet();
        public void LoadEinheiten(ComboBox comboBox)
        {
            cmd = new OleDbCommand("SELECT Bez FROM Verpackungseinheit", con);
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetString(0));
            }
            con.Close();
        }
        public void LoadArten(ComboBox comboBox)
        {
            cmd = new OleDbCommand("SELECT Bez FROM Produktart", con);
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetString(0));
            }
            con.Close();
        }

        public void DataGridFuellen(DataGridView DataGrid)
        {
            adap = new OleDbDataAdapter("SELECT * FROM Produkt WHERE IsActive = true", con);

            ds.Clear();

            adap.Fill(ds, "Produkte");

            DataGrid.DataSource = ds;
            DataGrid.DataMember = "Produkte";
        }

        public void ErstelleProdukt(TabControl TabControlToLoadIn)
        {
            DialogResult result = MessageBox.Show("Möchten Sie die Produktionsschritte direkt im Anschluss anlegen?", "Produktionsschritte", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                OpenProdSchritte(TabControlToLoadIn);
            }
        }
        public void BearbeiteProdukt()
        {

        }
        public void LoescheProdukt(DataGridView DataGrid)
        {
            DialogResult result = MessageBox.Show("Sind Sie sicher das Sie das ausgewählte Produkt löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                DataGridViewRow row = DataGrid.SelectedRows[0];
                string ZuLoeschen = row.Cells[0].Value.ToString();

                cmd = new OleDbCommand($"UPDATE Produkt SET IsActive = false WHERE Nr = {ZuLoeschen}", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                DataGrid.Rows.Remove(row);
            }
        }

        public void OpenProdSchritte(TabControl TabControlToLoadIn)
        {
            TabPage TPPS = new TabPage();
            TPPS.Text = "Produktionsschritt";
            TabControlToLoadIn.TabPages.Add(TPPS);
            LoadForm.OpenTab(new Produktionsschritt(), TPPS);
        }
    }
}
