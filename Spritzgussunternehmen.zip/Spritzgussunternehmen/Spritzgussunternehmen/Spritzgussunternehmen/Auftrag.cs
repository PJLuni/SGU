﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    public partial class Auftrag : Form
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;

        Panel panel;
        public Auftrag(Panel panel)
        {
            this.panel = panel;
            InitializeComponent();
        }

        private void Auftrag_Load(object sender, EventArgs e)
        {
            try
            {
                adap = new OleDbDataAdapter("SELECT Auftrag.Nr as Auftrag_Nr, Kunde.Bez as Kunde, Benutzerkonto.Vorname as Sachmitarbeiter,Auftrag.Auslieferungsdatum,Auftragsstatus.Bez as Status " +
                "FROM Auftrag, Kunde, Benutzerkonto,Auftragsstatus " +
                "Where Auftrag.Status = Auftragsstatus.Nr and Auftrag.Kunde=Kunde.Nr and Auftrag.Sachbearbeiter = Benutzerkonto.Nr and Auftrag.Status = 2", con);

                ds.Clear();

                adap.Fill(ds, "Auftraege");

                Auftraege.DataSource = ds;
                Auftraege.DataMember = "Auftraege";
            }
            catch { }
           
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            String[] row = { };
            LoadForm.OpenPanel(new AuftragAdd(row,panel), panel);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (checkBox1.Checked)
                {
                    adap = new OleDbDataAdapter("SELECT Auftrag.Nr as Auftrag_Nr, Kunde.Bez as Kunde, Benutzerkonto.Vorname as Sachmitarbeiter,Auftrag.Auslieferungsdatum,Auftragsstatus.Bez as Status " +
                    "FROM Auftrag, Kunde, Benutzerkonto,Auftragsstatus " +
                    "Where Auftrag.Status = Auftragsstatus.Nr and Auftrag.Kunde=Kunde.Nr and Auftrag.Sachbearbeiter = Benutzerkonto.Nr ", con);

                    ds.Clear();

                    adap.Fill(ds, "Auftraege");

                    Auftraege.DataSource = ds;
                    Auftraege.DataMember = "Auftraege";
                }
                else
                {
                    Auftrag_Load(sender, e);
                }
            }
            catch { }
        }
    }
}
