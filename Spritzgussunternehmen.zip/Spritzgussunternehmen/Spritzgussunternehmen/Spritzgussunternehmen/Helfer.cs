﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace Spritzgussunternehmen
{
    class Helfer
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;

        DataSet ds = new DataSet();
        public static bool TBFilled(List<string> Data)
        {
            try
            {
                bool TextboxesFilled = true;
                foreach (string Text in Data)
                {
                    if (String.IsNullOrEmpty(Text))
                    {
                        TextboxesFilled = false;
                    }

                }
                return TextboxesFilled;
            }
            catch (Exception)
            {
                return false;
            }
            
        }

        public string getMengenBez(int Nr)
        {
            try
            {
                cmd = new OleDbCommand($"SELECT Bez FROM Mengeneinheit WHERE Nr = {Nr}", con);
                con.Open();
                string Bez = cmd.ExecuteScalar().ToString();
                con.Close();

                return Bez;
            }
            catch (Exception)
            {
                return "";
            }
            
        }

        public int LetzteNummer(string Tabelle)
        {
            try
            {
                cmd = new OleDbCommand($"SELECT max(Nr) FROM {Tabelle}", con);
                con.Open();
                int Nr = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();
                return Nr + 1;
            }
            catch (Exception)
            {
                return 0;
            }
        }
        public string HashPassword(string input, HashAlgorithm algorithm)
        {
            Byte[] inputBytes = Encoding.UTF8.GetBytes(input);
            Byte[] hashedBytes = algorithm.ComputeHash(inputBytes);

            return BitConverter.ToString(hashedBytes);
        }

        public static void ClearDGV(DataGridView DataGrid)
        {
            DataGrid.DataSource = null;
        }
    }
}
