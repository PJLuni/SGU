﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Kunde
    {
        public static void LoadKunden(ComboBox comboBox)
        {
            try
            {
                DB.cmd = DB.createCmd("SELECT Nr FROM Kunde WHERE IsActive = true");
                DB.getCon().Open();
                DB.dr = DB.cmd.ExecuteReader();

                while (DB.dr.Read())
                {
                    comboBox.Items.Add(DB.dr.GetInt32(0));
                }
                DB.getCon().Close();
            }
            catch (Exception)
            {
            }
        }
    }
}
