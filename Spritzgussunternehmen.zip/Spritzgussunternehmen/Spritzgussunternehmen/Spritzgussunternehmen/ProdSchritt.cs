﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class ProdSchritt
    {
        public static int ProdSchrittNr;
        public static int ProdNr;
        public static string Bez;

        private static int ProdSchrittPosPrimaerNr;
        public static int ProdSchrittPosNr;
        public static int RohstoffNr;
        public static int Rohstoffmenge;
        public static string MengeneinheitBez;
        public static int Mengeneinheit;

        private static Helfer Manni = new Helfer();
        private static DataSet dsProdSchritt = new DataSet();
        private static DataSet dsProdPos = new DataSet();
        public static void LoadProdSchritt(ComboBox comboBox, int ProdNr)
        {
            try
            {
                comboBox.Items.Clear();

                DB.cmd = DB.createCmd($"SELECT count(*) FROM Produktionsschritt WHERE Produkt = {ProdNr}");
                DB.getCon().Open();
                int ProdCount = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                if (ProdCount > 0)
                {
                    DB.cmd = DB.createCmd($"SELECT Nr FROM Produktionsschritt WHERE Produkt = {ProdNr}");
                    DB.getCon().Open();
                    DB.dr = DB.cmd.ExecuteReader();

                    while (DB.dr.Read())
                    {
                        comboBox.Items.Add(DB.dr.GetInt32(0));
                    }
                    DB.getCon().Close();
                }
            }
            catch (Exception)
            {
            }
        }
        public static void SuchenDataGridFuellen(DataGridView DataGrid, int SProdNr)
        {
            try
            {
                DB.adap = new OleDbDataAdapter($"SELECT * FROM Produktionsschritt WHERE Produkt = {SProdNr}", DB.getCon());

                dsProdSchritt.Clear();

                DB.adap.Fill(dsProdSchritt, "Produktionsschritte");

                DataGrid.DataSource = dsProdSchritt;
                DataGrid.DataMember = "Produktionsschritte";
            }
            catch (Exception)
            {

                throw;
            }
            
        }
        public static void ProdPositionenDGVFuellen(DataGridView DataGrid, int SProdPosNr)
        {
            try
            {
                DB.adap = new OleDbDataAdapter($"SELECT * FROM ProduktionsschrittPosition WHERE Produktionsschritt = {SProdPosNr}", DB.getCon());

                dsProdPos.Clear();

                DB.adap.Fill(dsProdPos, "ProduktionsschrittPosition");

                DataGrid.DataSource = dsProdPos;
                DataGrid.DataMember = "ProduktionsschrittPosition";
            }
            catch (Exception)
            {
            }
            
        }

        public static string GetProdSchrittBez(int ProdNr)
        {
            try
            {
                DB.cmd = DB.createCmd($"SELECT Bez FROM Produkt WHERE Nr = {ProdNr}");
                DB.getCon().Open();
                DB.dr = DB.cmd.ExecuteReader();
                DB.dr.Read();
                string Bez = DB.dr.GetString(0);
                DB.getCon().Close();
                return Bez;
            }
            catch (Exception)
            {
                return "";
            }
            
        }
        public static void ErstelleProdSchritt()
        {
            try
            {
                if (String.IsNullOrEmpty(ProdNr.ToString()))
                {
                    DB.cmd = DB.createCmd($"SELECT max(Nr) FROM Produktionsschritt");
                    DB.getCon().Open();
                    int ProdSchrittNr = Convert.ToInt32(DB.cmd.ExecuteScalar()) + 1;
                    DB.getCon().Close();
                }

                DB.cmd = new OleDbCommand($"SELECT count(*) FROM Produktionsschritt WHERE Nr = {ProdSchrittNr}", DB.getCon());
                DB.getCon().Open();
                int psexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                if (psexist <= 0)
                {
                    DB.cmd = DB.createCmd($"INSERT INTO Produktionsschritt (Nr, Produkt, Bez) " +
                                            $"VALUES ({ProdSchrittNr}, {ProdNr}, '{Bez}')");
                    DB.getCon().Open();
                    DB.cmd.ExecuteNonQuery();
                    DB.getCon().Close();

                    Info.Success("Produktionsschritt wurde erfolgreich hinzugefügt!");
                }
                else
                {
                    Info.Error("Produktionsschritt existiert bereits!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
        public static void ErstelleProdSchrittDetails()
        {
            try
            {
                DB.cmd = DB.createCmd($"SELECT max(Nr) FROM ProduktionsschrittPosition");
                DB.getCon().Open();
                ProdSchrittPosPrimaerNr = Convert.ToInt32(DB.cmd.ExecuteScalar()) + 1;
                DB.getCon().Close();

                DB.cmd = DB.createCmd($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{MengeneinheitBez}'");
                DB.getCon().Open();
                int MengeneinheitNr = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                DB.cmd = new OleDbCommand($"SELECT count(*) FROM ProduktionsschrittPosition WHERE Nr = {ProdSchrittPosPrimaerNr}", DB.getCon());
                DB.getCon().Open();
                int psexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                if (psexist <= 0)
                {
                    DB.cmd = DB.createCmd($"INSERT INTO ProduktionsschrittPosition (Nr, Produktionsschritt, Rohstoff, Rohstoffmenge, Mengeneinheit) " +
                                            $"VALUES ({ProdSchrittPosPrimaerNr}, {ProdSchrittPosNr}, {RohstoffNr}, {Rohstoffmenge}, {MengeneinheitNr})");
                    DB.getCon().Open();
                    DB.cmd.ExecuteNonQuery();
                    DB.getCon().Close();

                    Info.Success("Position wurde erfolgreich hinzugefügt!");
                }
                else
                {
                    Info.Error("Position existiert bereits!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
        public static void BearbeiteProdSchritt()
        {
            try
            {
                DB.cmd = new OleDbCommand($"SELECT count(*) FROM Produktionsschritt WHERE Nr = {ProdSchrittNr}", DB.getCon());
                DB.getCon().Open();
                int psexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                if (psexist > 0)
                {
                    DB.cmd = DB.createCmd($"UPDATE Produktionsschritt SET Produkt = {ProdNr}, Bez = '{Bez}' WHERE Nr = {ProdSchrittNr}");
                    DB.getCon().Open();
                    DB.cmd.ExecuteNonQuery();
                    DB.getCon().Close();

                    Info.Success("Produktionsschritt wurde erfolgreich bearbeitet!");
                }
                else
                {
                    Info.Error("Produktionsschritt nicht!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }

        public static void BearbeiteProdSchrittDetails(int oldrohstoff, int oldrohstoffmenge, int oldmengeneiheit)
        {
            try
            {
                DB.cmd = DB.createCmd($"SELECT Nr FROM ProduktionsschrittPosition WHERE Produktionsschritt = {ProdSchrittNr} AND Rohstoff = {oldrohstoff} AND Rohstoffmenge = {oldrohstoffmenge} AND Mengeneinheit = {oldmengeneiheit}");
                DB.getCon().Open();
                ProdSchrittPosPrimaerNr = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                DB.cmd = DB.createCmd($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{MengeneinheitBez}'");
                DB.getCon().Open();
                int MengeneinheitNr = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                DB.cmd = new OleDbCommand($"SELECT count(*) FROM ProduktionsschrittPosition WHERE Nr = {ProdSchrittPosPrimaerNr}", DB.getCon());
                DB.getCon().Open();
                int psexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                if (psexist > 0)
                {
                    DB.cmd = DB.createCmd($"UPDATE ProduktionsschrittPosition SET Rohstoff = {RohstoffNr}, Rohstoffmenge = {Rohstoffmenge}, Mengeneinheit = {MengeneinheitNr} WHERE Nr = {ProdSchrittPosPrimaerNr}");
                    DB.getCon().Open();
                    DB.cmd.ExecuteNonQuery();
                    DB.getCon().Close();

                    Info.Success("Position wurde erfolgreich bearbeitet!");
                }
                else
                {
                    Info.Error("Position existiert nicht!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
        public static void LoescheProdSchritt()
        {
            try
            {
                DB.cmd = DB.createCmd($"SELECT count(*) FROM Produktionsschritt WHERE Nr = {ProdSchrittNr}");
                DB.getCon().Open();
                int psexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                if (psexist > 0)
                {
                    DB.cmd = DB.createCmd($"DELETE FROM Produktionsschritt WHERE Nr = {ProdSchrittNr}");
                    DB.getCon().Open();
                    DB.cmd.ExecuteNonQuery();
                    DB.getCon().Close();

                    Info.Success("Position wurde erfolgreich gelöscht!");
                }
                else
                {
                    Info.Error("Position existiert nicht!");
                }
            }
            catch (Exception)
            {
                Info.Error("Zuerst Positionen löschen!");
                DB.getCon().Close();
            }
        }
        public static void LoescheProdSchrittPosition()
        {
            try
            {
                DB.cmd = DB.createCmd($"SELECT count(*) FROM ProduktionsschrittPosition WHERE Produktionsschritt = {ProdSchrittNr} AND Rohstoff = {RohstoffNr} AND Rohstoffmenge = {Rohstoffmenge} AND Mengeneinheit = {Mengeneinheit}");
                DB.getCon().Open();
                int psexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                if (psexist > 0)
                {
                    DB.cmd = DB.createCmd($"DELETE FROM ProduktionsschrittPosition WHERE Produktionsschritt = {ProdSchrittNr} AND Rohstoff = {RohstoffNr} AND Rohstoffmenge = {Rohstoffmenge} AND Mengeneinheit = {Mengeneinheit}");
                    DB.getCon().Open();
                    DB.cmd.ExecuteNonQuery();
                    DB.getCon().Close();

                    Info.Success("Position wurde erfolgreich gelöscht!");
                }
                else
                {
                    Info.Error("Position existiert nicht!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
    }
}
