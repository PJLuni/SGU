﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class ProduktAdd : Form
    {
        Helfer Manni = new Helfer();
        TabControl NeededTabControl;

        int ProdNr;
        public ProduktAdd(TabControl NeededTabControl, int ProdNr = 0)
        {
            InitializeComponent();
            this.NeededTabControl = NeededTabControl;
            this.ProdNr = ProdNr;
        }

        private void ProduktAdd_Load(object sender, EventArgs e)
        {
            txtnr.Text = Manni.LetzteNummer("Produkt").ToString();
            Produkt.LoadArten(txtart);
            Mengeneinheit.LoadMengeneinheiten(txteinheit);
            Produkt.VerpackungsDataGridFuellen(Einheiten);

            if(ProdNr != 0)
            {
                txtnr.Enabled = false;
                checknr.Enabled = false;

                txtnr.Text = ProdNr.ToString();
                txtart.SelectedItem = Produkt.txtart;
                txtbez.Text = Produkt.txtbez;
                txthoehe.Value = Convert.ToDecimal(Produkt.txthoehe);
                txtbreite.Value = Convert.ToDecimal(Produkt.txtbreite);
                txtlaenge.Value = Convert.ToDecimal(Produkt.txtlaenge);
                txtgewicht.Value = Convert.ToDecimal(Produkt.txtgewicht);
                txteinheit.SelectedItem = Produkt.txteinheit;
                txthpreis.Value = Convert.ToDecimal(Produkt.txthpreis);
                txtpreis.Value = Convert.ToDecimal(Produkt.txtpreis);
                txtaktbestand.Value = Produkt.txtaktbestand;
                txtbeschreibung.Text = Produkt.txtbeschreibung;

                panel10.Visible = false;
                iconButton2.Text = "Bearbeiten";
            }
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            if(iconButton2.Text == "Hinzufügen")
            {
                bool EinheitenFilled = true;
                bool DataFilled = true;
                bool Error = false;

                foreach (Control CON in this.Controls)
                {
                    if (CON is Panel)
                    {
                        foreach (Control NUD in CON.Controls)
                        {
                            if (NUD.Text == "0,00")
                            {
                                DataFilled = false;
                            }
                        }
                    }
                    if (CON is ComboBox)
                    {
                        if ((CON as ComboBox).SelectedItem == null)
                        {
                            DataFilled = false;
                        }
                    }
                }

                for (int rowcounter = 0; rowcounter < (Einheiten.RowCount); rowcounter++)
                {
                    if (Convert.ToInt32(Einheiten.Rows[rowcounter].Cells[0].Value) <= 0 || Einheiten.Rows[rowcounter].Cells[0].Value == null)
                    {
                        EinheitenFilled = false;
                    }
                }

                if (DataFilled && EinheitenFilled)
                {
                    Produkt.txtnr = Convert.ToInt32(txtnr.Text);
                    Produkt.txtbez = txtbez.Text;
                    Produkt.txtart = txtart.Text;
                    Produkt.txthoehe = txthoehe.Value.ToString().Replace(",", ".");
                    Produkt.txtlaenge = txtlaenge.Value.ToString().Replace(",", ".");
                    Produkt.txtbreite = txtbreite.Value.ToString().Replace(",", ".");
                    Produkt.txtgewicht = txtgewicht.Value.ToString().Replace(",", ".");
                    Produkt.txtbeschreibung = txtbeschreibung.Text;
                    Produkt.txteinheit = txteinheit.Text.Replace(",", ".");
                    Produkt.txthpreis = txthpreis.Value.ToString().Replace(",", ".");
                    Produkt.txtpreis = txtpreis.Value.ToString().Replace(",", ".");
                    Produkt.txtaktbestand = Convert.ToInt32(txtaktbestand.Value);

                    try
                    {
                        Produkt.ErstelleProdukt(Einheiten);
                    }
                    catch (Exception)
                    {
                        Error = true;
                        Info.Error("Fehler beim erstellen des Produkts!");
                    }
                    if (!Error)
                    {
                        DialogResult result = MessageBox.Show("Möchten Sie die Produktionsschritte direkt im Anschluss erstellen?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (result == DialogResult.Yes)
                        {
                            TabPage TPPS = new TabPage();
                            TPPS.Text = "Produktionsschritt";
                            NeededTabControl.TabPages.Add(TPPS);
                            LoadForm.OpenTab(new ProdSchrittSuchen(NeededTabControl, Convert.ToInt32(txtnr.Text)), TPPS);
                        }
                        else
                        {
                            NeededTabControl.TabPages.Remove(NeededTabControl.SelectedTab);
                            NeededTabControl.SelectedTab = NeededTabControl.TabPages[0];
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Bitte füllen Sie alle Felder aus!\nDenken Sie auch an die Mengen-Angaben!");
                }
            }
            else
            {
                bool DataFilled = true;

                foreach (Control CON in this.Controls)
                {
                    if (CON is Panel)
                    {
                        foreach (Control NUD in CON.Controls)
                        {
                            if (NUD.Text == "0,00")
                            {
                                DataFilled = false;
                            }
                        }
                    }
                    if (CON is ComboBox)
                    {
                        if ((CON as ComboBox).SelectedItem == null)
                        {
                            DataFilled = false;
                        }
                    }
                }

                if (DataFilled)
                {
                    Produkt.txtnr = Convert.ToInt32(txtnr.Text);
                    Produkt.txtbez = txtbez.Text;
                    Produkt.txtart = txtart.Text;
                    Produkt.txthoehe = txthoehe.Value.ToString().Replace(",", ".");
                    Produkt.txtlaenge = txtlaenge.Value.ToString().Replace(",", ".");
                    Produkt.txtbreite = txtbreite.Value.ToString().Replace(",", ".");
                    Produkt.txtgewicht = txtgewicht.Value.ToString().Replace(",", ".");
                    Produkt.txtbeschreibung = txtbeschreibung.Text;
                    Produkt.txteinheit = txteinheit.Text.Replace(",", ".");
                    Produkt.txthpreis = txthpreis.Value.ToString().Replace(",", ".");
                    Produkt.txtpreis = txtpreis.Value.ToString().Replace(",", ".");
                    Produkt.txtaktbestand = Convert.ToInt32(txtaktbestand.Value);

                    try
                    {
                        Produkt.BearbeiteProdukt();
                    }
                    catch (Exception)
                    {
                        Info.Error("Fehler beim erstellen des Produkts!");
                    }
                    NeededTabControl.TabPages.Remove(NeededTabControl.SelectedTab);
                    NeededTabControl.SelectedTab = NeededTabControl.TabPages[0];
                }
                else
                {
                    MessageBox.Show("Bitte füllen Sie alle Felder aus!\nDenken Sie auch an die Mengen-Angaben!");
                }
            }
            
        }

        private void checknr_CheckedChanged(object sender, EventArgs e)
        {
            if (txtnr.Enabled == false)
            {
                txtnr.Enabled = true;
                txtnr.Clear();
            }
            else
            {
                txtnr.Enabled = false;
                txtnr.Text = Manni.LetzteNummer("Produkt").ToString();
            }
        }
        private void NUDResetText(object sender, EventArgs e)
        {
            if((sender as NumericUpDown).Value == 0)
            {
                (sender as NumericUpDown).ResetText();
            }
        }
        private void NUDLeaveBlank(object sender, EventArgs e)
        {
            if((sender as NumericUpDown).Text == "" || (sender as NumericUpDown).Text == "-")
            {
                (sender as NumericUpDown).Text = 0.00.ToString();
            }
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            NeededTabControl.TabPages.Remove(NeededTabControl.SelectedTab);
            NeededTabControl.SelectedTab = NeededTabControl.TabPages[0];
        }
    }
}
