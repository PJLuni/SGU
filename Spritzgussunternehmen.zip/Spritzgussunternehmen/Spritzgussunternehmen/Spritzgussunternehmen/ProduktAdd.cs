﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class ProduktAdd : Form
    {

        Produkt NeuesProdukt = new Produkt();
        public ProduktAdd()
        {
            InitializeComponent();
        }

        private void ProduktAdd_Load(object sender, EventArgs e)
        {
            NeuesProdukt.LoadArten(txtart);
            NeuesProdukt.LoadEinheiten(txteinheit);
            NeuesProdukt.VerpackungsDataGridFuellen(Einheiten);
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            NeuesProdukt.ErstelleProdukt(txtbez.Text, txtart.Text, txthoehe.Text, txtlaenge.Text, txtbreite.Text, txtmenge.Text, txtbeschreibung.Text,txteinheit.Text, txthpreis.Text, txtpreis.Text, txtaktbestand.Text);
        }
    }
}
