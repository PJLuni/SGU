﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class VerpackungseinheitSuchen : Form
    {
        TabControl TC;
        Helfer Manni = new Helfer();
        public VerpackungseinheitSuchen(TabControl TC)
        {
            InitializeComponent();
            this.TC = TC;
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            TabPage TPEh = new TabPage();
            TPEh.Text = "Mengeneinheit";
            TC.TabPages.Add(TPEh);
            LoadForm.OpenTab(new MengeneinheitSuchen(TC), TPEh);
            TC.TabPages.RemoveAt(0);
        }

        private void VerpackungseinheitSuchen_Load(object sender, EventArgs e)
        {
            Verpackungseinheit.SuchenDataGridFuellen(Verpackungseinheiten);
            txtnr.Text = Manni.LetzteNummer("Verpackungseinheit").ToString();
            Verpackungseinheiten.ClearSelection();
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            Verpackungseinheit.LoescheVerpackungseinheit(Verpackungseinheiten);
        }

        private void checknr_CheckedChanged(object sender, EventArgs e)
        {
            if (txtnr.Enabled == false)
            {
                txtnr.Enabled = true;
                txtnr.Clear();
            }
            else
            {
                txtnr.Enabled = false;
                txtnr.Text = Manni.LetzteNummer("Verpackungseinheit").ToString();
            }
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            if (btnehadd.Text == "Einheit hinzufügen")
            {
                txtnr.Text = Manni.LetzteNummer("Verpackungseinheit").ToString();
                txtbez.Clear();
                checknr.Checked = false;
                txtnr.Enabled = false;
            }
            else
            {
                txtnr.Text = Manni.LetzteNummer("Verpackungseinheit").ToString();
                txtbez.Clear();
                Verpackungseinheiten.ClearSelection();
                btnehadd.Text = "Einheit hinzufügen";
                checknr.Enabled = true;
                checknr.Checked = false;
                txtnr.Enabled = false;
            }
        }

        private void Verpackungseinheiten_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (Verpackungseinheiten.SelectedRows.Count > 0)
                {
                    int VerpNr = Convert.ToInt32(Verpackungseinheiten.SelectedRows[0].Cells[0].Value);
                    string Bez = Verpackungseinheiten.SelectedRows[0].Cells[1].Value.ToString();

                    txtnr.Text = VerpNr.ToString();
                    txtbez.Text = Bez;

                    btnehadd.Text = "Einheit bearbeiten";
                    checknr.Enabled = false;
                    checknr.Checked = false;
                    txtnr.Enabled = false;
                }
            }
            catch (Exception err)
            {
                throw err;
            }
        }

        private void btnehadd_Click(object sender, EventArgs e)
        {
            List<string> DataToFill = new List<string>();
            DataToFill.Add(txtnr.Text);
            DataToFill.Add(txtbez.Text);

            switch (btnehadd.Text)
            {
                case "Einheit hinzufügen":
                    Verpackungseinheit.ErstelleVerpackungseinheit(DataToFill);
                    txtnr.Text = Manni.LetzteNummer("Verpackungseinheit").ToString();
                    break;
                case "Einheit bearbeiten":
                    Verpackungseinheit.BearbeiteVerpackungseinheit(DataToFill);
                    break;
            }

            Verpackungseinheiten.DataSource = null;
            Verpackungseinheit.SuchenDataGridFuellen(Verpackungseinheiten);
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            Verpackungseinheit.SucheVerpackungseinheit(textBox1.Text, Verpackungseinheiten);
        }

        private void iconButton7_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            Verpackungseinheit.SuchenDataGridFuellen(Verpackungseinheiten);
        }
    }
}
