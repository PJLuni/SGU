﻿
namespace Spritzgussunternehmen
{
    partial class Infobox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.closeicon = new FontAwesome.Sharp.IconPictureBox();
            this.infoicon = new FontAwesome.Sharp.IconPictureBox();
            this.infotxt = new System.Windows.Forms.Label();
            this.headertxt = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.closeicon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoicon)).BeginInit();
            this.SuspendLayout();
            // 
            // closeicon
            // 
            this.closeicon.BackColor = System.Drawing.Color.Transparent;
            this.closeicon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeicon.ForeColor = System.Drawing.Color.Gainsboro;
            this.closeicon.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.closeicon.IconColor = System.Drawing.Color.Gainsboro;
            this.closeicon.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.closeicon.IconSize = 29;
            this.closeicon.Location = new System.Drawing.Point(355, 31);
            this.closeicon.Name = "closeicon";
            this.closeicon.Size = new System.Drawing.Size(29, 30);
            this.closeicon.TabIndex = 11;
            this.closeicon.TabStop = false;
            this.closeicon.Visible = false;
            this.closeicon.Click += new System.EventHandler(this.closeicon_Click);
            // 
            // infoicon
            // 
            this.infoicon.BackColor = System.Drawing.Color.Transparent;
            this.infoicon.ForeColor = System.Drawing.Color.Gainsboro;
            this.infoicon.IconChar = FontAwesome.Sharp.IconChar.ExclamationTriangle;
            this.infoicon.IconColor = System.Drawing.Color.Gainsboro;
            this.infoicon.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.infoicon.IconSize = 56;
            this.infoicon.Location = new System.Drawing.Point(12, 18);
            this.infoicon.Name = "infoicon";
            this.infoicon.Size = new System.Drawing.Size(56, 56);
            this.infoicon.TabIndex = 10;
            this.infoicon.TabStop = false;
            this.infoicon.Visible = false;
            // 
            // infotxt
            // 
            this.infotxt.AutoSize = true;
            this.infotxt.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.infotxt.ForeColor = System.Drawing.Color.White;
            this.infotxt.Location = new System.Drawing.Point(74, 44);
            this.infotxt.Name = "infotxt";
            this.infotxt.Size = new System.Drawing.Size(32, 17);
            this.infotxt.TabIndex = 9;
            this.infotxt.Text = "Info";
            this.infotxt.Visible = false;
            // 
            // headertxt
            // 
            this.headertxt.AutoSize = true;
            this.headertxt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.headertxt.ForeColor = System.Drawing.Color.White;
            this.headertxt.Location = new System.Drawing.Point(73, 23);
            this.headertxt.Name = "headertxt";
            this.headertxt.Size = new System.Drawing.Size(65, 21);
            this.headertxt.TabIndex = 8;
            this.headertxt.Text = "Header";
            this.headertxt.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Infobox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(396, 86);
            this.Controls.Add(this.closeicon);
            this.Controls.Add(this.infoicon);
            this.Controls.Add(this.infotxt);
            this.Controls.Add(this.headertxt);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Infobox";
            this.Text = "ErrorForm";
            this.Load += new System.EventHandler(this.ErrorForm_Load);
            this.Shown += new System.EventHandler(this.ErrorForm_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.closeicon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoicon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FontAwesome.Sharp.IconPictureBox closeicon;
        private FontAwesome.Sharp.IconPictureBox infoicon;
        private System.Windows.Forms.Label infotxt;
        private System.Windows.Forms.Label headertxt;
        private System.Windows.Forms.Timer timer1;
    }
}