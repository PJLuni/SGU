﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Verpackungseinheit
    {
        private static DataSet ds = new DataSet();
        public static void LoadVerpackungseinheiten(ComboBox comboBox)
        {
            try
            {
                DB.cmd = DB.createCmd("SELECT Nr FROM Verpackungseinheit WHERE IsActive = true");
                DB.getCon().Open();
                DB.dr = DB.cmd.ExecuteReader();

                while (DB.dr.Read())
                {
                    comboBox.Items.Add(DB.dr.GetInt32(0));
                }
                DB.getCon().Close();
            }
            catch (Exception)
            {
            }
            
        }
        public static void SuchenDataGridFuellen(DataGridView DataGrid)
        {
            try
            {
                DB.adap = new OleDbDataAdapter("SELECT * FROM Verpackungseinheit WHERE IsActive = true", DB.getCon());

                ds.Clear();

                DB.adap.Fill(ds, "Verpackungseinheiten");

                DataGrid.DataSource = ds;
                DataGrid.DataMember = "Verpackungseinheiten";
            }
            catch (Exception)
            {
            }
            
        }
        public static void ErstelleVerpackungseinheit(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Bez = Data[1];

                    DB.cmd = new OleDbCommand($"SELECT count(*) FROM Verpackungseinheit WHERE Nr = {Nr}", DB.getCon());
                    DB.getCon().Open();
                    int verpexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (verpexist <= 0)
                    {
                        DB.cmd = new OleDbCommand($"INSERT INTO Verpackungseinheit (Nr, Bez, IsActive) " +
                                               $"VALUES ({Nr}, '{Bez}', true)", DB.getCon());
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        Info.Success("Verpackungseinheit wurde erfolgreich hinzugefügt!");
                    }
                    else
                    {
                        Info.Error("Verpackungseinheit existiert bereits!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
        public static void BearbeiteVerpackungseinheit(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Bez = Data[1];

                    DB.cmd = new OleDbCommand($"SELECT count(*) FROM Verpackungseinheit WHERE Nr = {Nr}", DB.getCon());
                    DB.getCon().Open();
                    int verpexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (verpexist > 0)
                    {
                        DB.cmd = new OleDbCommand($"UPDATE Verpackungseinheit SET Bez = '{Bez}', IsActive = true WHERE Nr = {Nr}", DB.getCon());
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        Info.Success("Verpackungseinheit wurde erfolgreich bearbeitet!");
                    }
                    else
                    {
                        Info.Error("Verpackungseinheit existiert nicht!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
        public static void LoescheVerpackungseinheit(DataGridView DataGrid)
        {
            try
            {
                DialogResult result = MessageBox.Show("Sind Sie sicher das Sie die ausgewählte Verpackungseinheit löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (DataGrid.SelectedRows.Count != 0)
                    {
                        DataGridViewRow row = DataGrid.SelectedRows[0];
                        string ZuLoeschen = row.Cells[0].Value.ToString();

                        DB.cmd = new OleDbCommand($"SELECT count(*) FROM Verpackungseinheit WHERE Nr = {ZuLoeschen}", DB.getCon());
                        DB.getCon().Open();
                        int verpexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                        DB.getCon().Close();

                        if (verpexist > 0)
                        {
                            DB.cmd = new OleDbCommand($"UPDATE Verpackungseinheit SET IsActive = false WHERE Nr = {ZuLoeschen}", DB.getCon());
                            DB.getCon().Open();
                            DB.cmd.ExecuteNonQuery();
                            DB.getCon().Close();

                            DataGrid.Rows.Remove(row);

                            Info.Success("Verpackungseinheit wurde erfolgreich gelöscht!");
                        }
                        else
                        {
                            Info.Error("Verpackungseinheit existiert nicht!");
                        }
                    }
                    else
                    {
                        Info.Error("Bitte wählen Sie eine Verpackungseinheit aus!");
                    }
                }
            }
            catch (Exception)
            {
            }
        }
        public static void SucheVerpackungseinheit(string Search, DataGridView DataGrid)
        {
            try
            {
                bool check = int.TryParse(Search, out _);

                if (check)
                {
                    DB.adap = new OleDbDataAdapter($"SELECT * FROM Verpackungseinheit WHERE Nr LIKE '%{Search}%' AND IsActive = true", DB.getCon());
                    
                    ds.Clear();

                    DB.adap.Fill(ds, "Verpackungseinheiten");

                    DataGrid.DataSource = ds;
                    DataGrid.DataMember = "Verpackungseinheiten";
                }
                else
                {
                    DB.adap = new OleDbDataAdapter($"SELECT * FROM Verpackungseinheit WHERE Bez LIKE '%{Search}%' AND IsActive = true", DB.getCon());

                    ds.Clear();

                    DB.adap.Fill(ds, "Verpackungseinheiten");

                    DataGrid.DataSource = ds;
                    DataGrid.DataMember = "Verpackungseinheiten";
                }
            }
            catch (Exception)
            {
                Info.Error("Fehler beim Suchen!");
            }
        }
    }
}
