﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Mengeneinheit
    {
        private static DataSet ds = new DataSet();
        public static void LoadMengeneinheiten(ComboBox comboBox)
        {
            try
            {
                DB.cmd = DB.createCmd("SELECT Bez FROM Mengeneinheit WHERE IsActive = true");
                DB.getCon().Open();
                DB.dr = DB.cmd.ExecuteReader();

                while (DB.dr.Read())
                {
                    comboBox.Items.Add(DB.dr.GetString(0));
                }
                DB.getCon().Close();
            }
            catch (Exception)
            {
            }
            
        }
        public static string GetMengenBez(int Nr)
        {
            try
            {
                DB.cmd = DB.createCmd($"SELECT Bez FROM Mengeneinheit WHERE Nr = {Nr}");
                DB.getCon().Open();
                string Bez = DB.cmd.ExecuteScalar().ToString();
                DB.getCon().Close();

                return Bez;
            }
            catch (Exception){}
            return "";
        }
        public static void SuchenDataGridFuellen(DataGridView DataGrid)
        {
            try
            {
                DB.adap = new OleDbDataAdapter("SELECT * FROM Mengeneinheit WHERE IsActive = true", DB.getCon());

                ds.Clear();

                DB.adap.Fill(ds, "Mengeneinheiten");

                DataGrid.DataSource = ds;
                DataGrid.DataMember = "Mengeneinheiten";
            }
            catch (Exception)
            {
            }
        }
        public static void ErstelleMengeneinheit(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Bez = Data[1];

                    DB.cmd = new OleDbCommand($"SELECT count(*) FROM Mengeneinheit WHERE Nr = {Nr}", DB.getCon());
                    DB.getCon().Open();
                    int mengexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (mengexist <= 0)
                    {
                        DB.cmd = new OleDbCommand($"INSERT INTO Mengeneinheit (Nr, Bez, IsActive) " +
                                               $"VALUES ({Nr}, '{Bez}', true)", DB.getCon());
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        Info.Success("Mengeneinheit wurde erfolgreich hinzugefügt!");
                    }
                    else
                    {
                        Info.Error("Mengeneinheits existiert bereits!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
        public static void BearbeiteMengeneinheit(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Bez = Data[1];

                    DB.cmd = new OleDbCommand($"SELECT count(*) FROM Mengeneinheit WHERE Nr = {Nr}", DB.getCon());
                    DB.getCon().Open();
                    int mengexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (mengexist > 0)
                    {
                        DB.cmd = new OleDbCommand($"UPDATE Mengeneinheit SET Bez = '{Bez}', IsActive = true WHERE Nr = {Nr}", DB.getCon());
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        Info.Success("Mengeneinheit wurde erfolgreich bearbeitet!");
                    }
                    else
                    {
                        Info.Error("Mengeneinheit existiert nicht!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
        public static void LoescheMengeneinheit(DataGridView DataGrid)
        {
            try
            {
                DialogResult result = MessageBox.Show("Sind Sie sicher das Sie die ausgewählte Mengeneinheit löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (DataGrid.SelectedRows.Count != 0)
                    {
                        DataGridViewRow row = DataGrid.SelectedRows[0];
                        string ZuLoeschen = row.Cells[0].Value.ToString();

                        DB.cmd = new OleDbCommand($"SELECT count(*) FROM Mengeneinheit WHERE Nr = {ZuLoeschen}", DB.getCon());
                        DB.getCon().Open();
                        int mengexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                        DB.getCon().Close();

                        if (mengexist > 0)
                        {
                            DB.cmd = new OleDbCommand($"UPDATE Mengeneinheit SET IsActive = false WHERE Nr = {ZuLoeschen}", DB.getCon());
                            DB.getCon().Open();
                            DB.cmd.ExecuteNonQuery();
                            DB.getCon().Close();

                            DataGrid.Rows.Remove(row);

                            Info.Success("Mengeneinheit wurde erfolgreich gelöscht!");
                        }
                        else
                        {
                            Info.Error("Mengeneinheit existiert nicht!");
                        }
                    }
                    else
                    {
                        Info.Error("Bitte wählen Sie eine Mengeneinheit aus!");
                    }
                }
            }
            catch (Exception)
            {
            }
            
        }
        public static void SucheMengeneinheit(string Search, DataGridView DataGrid)
        {
            try
            {
                bool check = int.TryParse(Search, out _);

                if (check)
                {
                    DB.adap = new OleDbDataAdapter($"SELECT * FROM Mengeneinheit WHERE Nr LIKE '%{Search}%' AND IsActive = true", DB.getCon());

                    ds.Clear();

                    DB.adap.Fill(ds, "Mengeneinheiten");

                    DataGrid.DataSource = ds;
                    DataGrid.DataMember = "Mengeneinheiten";
                }
                else
                {
                    DB.adap = new OleDbDataAdapter($"SELECT * FROM Mengeneinheit WHERE Bez LIKE '%{Search}%' AND IsActive = true", DB.getCon());

                    ds.Clear();

                    DB.adap.Fill(ds, "Mengeneinheiten");

                    DataGrid.DataSource = ds;
                    DataGrid.DataMember = "Mengeneinheiten";
                }
            }
            catch (Exception)
            {
                Info.Error("Fehler beim Suchen!");
            }
        }
    }
}
