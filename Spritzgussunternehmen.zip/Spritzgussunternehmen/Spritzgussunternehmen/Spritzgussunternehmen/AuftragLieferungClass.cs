﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class AuftragLieferungClass
    {
        public static void LoadAL(ComboBox comboBox)
        {
            try
            {
                DB.cmd = DB.createCmd("SELECT Nr FROM AuftragLieferung");
                DB.getCon().Open();
                DB.dr = DB.cmd.ExecuteReader();

                while (DB.dr.Read())
                {
                    comboBox.Items.Add(DB.dr.GetInt32(0));
                }
                DB.getCon().Close();
            }
            catch (Exception)
            {
            }
        }
    }
}
