﻿namespace Spritzgussunternehmen
{
    partial class Hauptmenu
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Hauptmenu));
            this.sidebar = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sideEinheit = new FontAwesome.Sharp.IconButton();
            this.sideMwSt = new FontAwesome.Sharp.IconButton();
            this.sideRohstoff = new FontAwesome.Sharp.IconButton();
            this.sidePalette = new FontAwesome.Sharp.IconButton();
            this.sideProdukt = new FontAwesome.Sharp.IconButton();
            this.sideKunde = new FontAwesome.Sharp.IconButton();
            this.sidebarStammdaten = new FontAwesome.Sharp.IconButton();
            this.sidebarRechnung = new FontAwesome.Sharp.IconButton();
            this.sidebarLieferung = new FontAwesome.Sharp.IconButton();
            this.sidebarAuftrag = new FontAwesome.Sharp.IconButton();
            this.sidebarLogin = new FontAwesome.Sharp.IconButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.topbar = new System.Windows.Forms.Panel();
            this.btnaddsach = new FontAwesome.Sharp.IconButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.sachnr = new System.Windows.Forms.Label();
            this.sachname = new System.Windows.Forms.Label();
            this.topbarLogout = new FontAwesome.Sharp.IconButton();
            this.topbarClose = new FontAwesome.Sharp.IconButton();
            this.topbarSettings = new FontAwesome.Sharp.IconButton();
            this.main = new System.Windows.Forms.Panel();
            this.sidebar.SuspendLayout();
            this.panel1.SuspendLayout();
            this.topbar.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidebar
            // 
            this.sidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.sidebar.Controls.Add(this.panel1);
            this.sidebar.Controls.Add(this.sidebarRechnung);
            this.sidebar.Controls.Add(this.sidebarLieferung);
            this.sidebar.Controls.Add(this.sidebarAuftrag);
            this.sidebar.Controls.Add(this.sidebarLogin);
            this.sidebar.Controls.Add(this.panel4);
            this.sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebar.Location = new System.Drawing.Point(0, 0);
            this.sidebar.Name = "sidebar";
            this.sidebar.Size = new System.Drawing.Size(240, 845);
            this.sidebar.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.sideEinheit);
            this.panel1.Controls.Add(this.sideMwSt);
            this.panel1.Controls.Add(this.sideRohstoff);
            this.panel1.Controls.Add(this.sidePalette);
            this.panel1.Controls.Add(this.sideProdukt);
            this.panel1.Controls.Add(this.sideKunde);
            this.panel1.Controls.Add(this.sidebarStammdaten);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 360);
            this.panel1.MaximumSize = new System.Drawing.Size(247, 400);
            this.panel1.MinimumSize = new System.Drawing.Size(247, 57);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(247, 57);
            this.panel1.TabIndex = 6;
            // 
            // sideEinheit
            // 
            this.sideEinheit.Dock = System.Windows.Forms.DockStyle.Top;
            this.sideEinheit.Enabled = false;
            this.sideEinheit.FlatAppearance.BorderSize = 0;
            this.sideEinheit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sideEinheit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sideEinheit.ForeColor = System.Drawing.Color.White;
            this.sideEinheit.IconChar = FontAwesome.Sharp.IconChar.None;
            this.sideEinheit.IconColor = System.Drawing.Color.Chocolate;
            this.sideEinheit.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.sideEinheit.IconSize = 3;
            this.sideEinheit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sideEinheit.Location = new System.Drawing.Point(0, 302);
            this.sideEinheit.Name = "sideEinheit";
            this.sideEinheit.Padding = new System.Windows.Forms.Padding(70, 0, 10, 0);
            this.sideEinheit.Size = new System.Drawing.Size(247, 49);
            this.sideEinheit.TabIndex = 13;
            this.sideEinheit.TabStop = false;
            this.sideEinheit.Text = "Einheiten";
            this.sideEinheit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sideEinheit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sideEinheit.UseVisualStyleBackColor = true;
            this.sideEinheit.Click += new System.EventHandler(this.sideVerpackung_Click);
            // 
            // sideMwSt
            // 
            this.sideMwSt.Dock = System.Windows.Forms.DockStyle.Top;
            this.sideMwSt.Enabled = false;
            this.sideMwSt.FlatAppearance.BorderSize = 0;
            this.sideMwSt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sideMwSt.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sideMwSt.ForeColor = System.Drawing.Color.White;
            this.sideMwSt.IconChar = FontAwesome.Sharp.IconChar.None;
            this.sideMwSt.IconColor = System.Drawing.Color.Chocolate;
            this.sideMwSt.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.sideMwSt.IconSize = 3;
            this.sideMwSt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sideMwSt.Location = new System.Drawing.Point(0, 251);
            this.sideMwSt.Name = "sideMwSt";
            this.sideMwSt.Padding = new System.Windows.Forms.Padding(70, 0, 10, 0);
            this.sideMwSt.Size = new System.Drawing.Size(247, 51);
            this.sideMwSt.TabIndex = 12;
            this.sideMwSt.TabStop = false;
            this.sideMwSt.Text = "MwSt";
            this.sideMwSt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sideMwSt.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sideMwSt.UseVisualStyleBackColor = true;
            this.sideMwSt.Click += new System.EventHandler(this.sideMwSt_Click);
            // 
            // sideRohstoff
            // 
            this.sideRohstoff.Dock = System.Windows.Forms.DockStyle.Top;
            this.sideRohstoff.Enabled = false;
            this.sideRohstoff.FlatAppearance.BorderSize = 0;
            this.sideRohstoff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sideRohstoff.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sideRohstoff.ForeColor = System.Drawing.Color.White;
            this.sideRohstoff.IconChar = FontAwesome.Sharp.IconChar.None;
            this.sideRohstoff.IconColor = System.Drawing.Color.Chocolate;
            this.sideRohstoff.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.sideRohstoff.IconSize = 3;
            this.sideRohstoff.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sideRohstoff.Location = new System.Drawing.Point(0, 202);
            this.sideRohstoff.Name = "sideRohstoff";
            this.sideRohstoff.Padding = new System.Windows.Forms.Padding(70, 0, 10, 0);
            this.sideRohstoff.Size = new System.Drawing.Size(247, 49);
            this.sideRohstoff.TabIndex = 11;
            this.sideRohstoff.TabStop = false;
            this.sideRohstoff.Text = "Rohstoff";
            this.sideRohstoff.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sideRohstoff.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sideRohstoff.UseVisualStyleBackColor = true;
            this.sideRohstoff.Click += new System.EventHandler(this.sideRohstoff_Click);
            // 
            // sidePalette
            // 
            this.sidePalette.Dock = System.Windows.Forms.DockStyle.Top;
            this.sidePalette.Enabled = false;
            this.sidePalette.FlatAppearance.BorderSize = 0;
            this.sidePalette.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sidePalette.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sidePalette.ForeColor = System.Drawing.Color.White;
            this.sidePalette.IconChar = FontAwesome.Sharp.IconChar.None;
            this.sidePalette.IconColor = System.Drawing.Color.Chocolate;
            this.sidePalette.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.sidePalette.IconSize = 3;
            this.sidePalette.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidePalette.Location = new System.Drawing.Point(0, 153);
            this.sidePalette.Name = "sidePalette";
            this.sidePalette.Padding = new System.Windows.Forms.Padding(70, 0, 10, 0);
            this.sidePalette.Size = new System.Drawing.Size(247, 49);
            this.sidePalette.TabIndex = 10;
            this.sidePalette.TabStop = false;
            this.sidePalette.Text = "Palette";
            this.sidePalette.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidePalette.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sidePalette.UseVisualStyleBackColor = true;
            this.sidePalette.Click += new System.EventHandler(this.sidePalette_Click);
            // 
            // sideProdukt
            // 
            this.sideProdukt.Dock = System.Windows.Forms.DockStyle.Top;
            this.sideProdukt.Enabled = false;
            this.sideProdukt.FlatAppearance.BorderSize = 0;
            this.sideProdukt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sideProdukt.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sideProdukt.ForeColor = System.Drawing.Color.White;
            this.sideProdukt.IconChar = FontAwesome.Sharp.IconChar.None;
            this.sideProdukt.IconColor = System.Drawing.Color.Chocolate;
            this.sideProdukt.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.sideProdukt.IconSize = 3;
            this.sideProdukt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sideProdukt.Location = new System.Drawing.Point(0, 104);
            this.sideProdukt.Name = "sideProdukt";
            this.sideProdukt.Padding = new System.Windows.Forms.Padding(70, 0, 10, 0);
            this.sideProdukt.Size = new System.Drawing.Size(247, 49);
            this.sideProdukt.TabIndex = 8;
            this.sideProdukt.TabStop = false;
            this.sideProdukt.Text = "Produkt";
            this.sideProdukt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sideProdukt.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sideProdukt.UseVisualStyleBackColor = true;
            this.sideProdukt.Click += new System.EventHandler(this.sideProdukt_Click);
            // 
            // sideKunde
            // 
            this.sideKunde.Dock = System.Windows.Forms.DockStyle.Top;
            this.sideKunde.Enabled = false;
            this.sideKunde.FlatAppearance.BorderSize = 0;
            this.sideKunde.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sideKunde.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sideKunde.ForeColor = System.Drawing.Color.White;
            this.sideKunde.IconChar = FontAwesome.Sharp.IconChar.None;
            this.sideKunde.IconColor = System.Drawing.Color.Chocolate;
            this.sideKunde.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.sideKunde.IconSize = 3;
            this.sideKunde.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sideKunde.Location = new System.Drawing.Point(0, 57);
            this.sideKunde.Name = "sideKunde";
            this.sideKunde.Padding = new System.Windows.Forms.Padding(70, 0, 10, 0);
            this.sideKunde.Size = new System.Drawing.Size(247, 47);
            this.sideKunde.TabIndex = 7;
            this.sideKunde.TabStop = false;
            this.sideKunde.Text = "Kunde";
            this.sideKunde.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sideKunde.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sideKunde.UseVisualStyleBackColor = true;
            this.sideKunde.Click += new System.EventHandler(this.sideKunde_Click);
            // 
            // sidebarStammdaten
            // 
            this.sidebarStammdaten.Dock = System.Windows.Forms.DockStyle.Top;
            this.sidebarStammdaten.Enabled = false;
            this.sidebarStammdaten.FlatAppearance.BorderSize = 0;
            this.sidebarStammdaten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sidebarStammdaten.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sidebarStammdaten.ForeColor = System.Drawing.Color.White;
            this.sidebarStammdaten.IconChar = FontAwesome.Sharp.IconChar.Database;
            this.sidebarStammdaten.IconColor = System.Drawing.Color.Chocolate;
            this.sidebarStammdaten.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.sidebarStammdaten.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidebarStammdaten.Location = new System.Drawing.Point(0, 0);
            this.sidebarStammdaten.Name = "sidebarStammdaten";
            this.sidebarStammdaten.Padding = new System.Windows.Forms.Padding(5, 0, 10, 0);
            this.sidebarStammdaten.Size = new System.Drawing.Size(247, 57);
            this.sidebarStammdaten.TabIndex = 5;
            this.sidebarStammdaten.TabStop = false;
            this.sidebarStammdaten.Text = "Stammdaten";
            this.sidebarStammdaten.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidebarStammdaten.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sidebarStammdaten.UseVisualStyleBackColor = true;
            this.sidebarStammdaten.Click += new System.EventHandler(this.sidebarStammdaten_Click);
            // 
            // sidebarRechnung
            // 
            this.sidebarRechnung.Dock = System.Windows.Forms.DockStyle.Top;
            this.sidebarRechnung.Enabled = false;
            this.sidebarRechnung.FlatAppearance.BorderSize = 0;
            this.sidebarRechnung.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sidebarRechnung.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sidebarRechnung.ForeColor = System.Drawing.Color.White;
            this.sidebarRechnung.IconChar = FontAwesome.Sharp.IconChar.Receipt;
            this.sidebarRechnung.IconColor = System.Drawing.Color.Chocolate;
            this.sidebarRechnung.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.sidebarRechnung.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidebarRechnung.Location = new System.Drawing.Point(0, 300);
            this.sidebarRechnung.Name = "sidebarRechnung";
            this.sidebarRechnung.Padding = new System.Windows.Forms.Padding(5, 0, 10, 0);
            this.sidebarRechnung.Size = new System.Drawing.Size(240, 60);
            this.sidebarRechnung.TabIndex = 3;
            this.sidebarRechnung.TabStop = false;
            this.sidebarRechnung.Text = "Rechnung";
            this.sidebarRechnung.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidebarRechnung.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sidebarRechnung.UseVisualStyleBackColor = true;
            this.sidebarRechnung.Click += new System.EventHandler(this.iconButton4_Click);
            // 
            // sidebarLieferung
            // 
            this.sidebarLieferung.Dock = System.Windows.Forms.DockStyle.Top;
            this.sidebarLieferung.Enabled = false;
            this.sidebarLieferung.FlatAppearance.BorderSize = 0;
            this.sidebarLieferung.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sidebarLieferung.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sidebarLieferung.ForeColor = System.Drawing.Color.White;
            this.sidebarLieferung.IconChar = FontAwesome.Sharp.IconChar.Truck;
            this.sidebarLieferung.IconColor = System.Drawing.Color.Chocolate;
            this.sidebarLieferung.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.sidebarLieferung.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidebarLieferung.Location = new System.Drawing.Point(0, 240);
            this.sidebarLieferung.Name = "sidebarLieferung";
            this.sidebarLieferung.Padding = new System.Windows.Forms.Padding(5, 0, 10, 0);
            this.sidebarLieferung.Size = new System.Drawing.Size(240, 60);
            this.sidebarLieferung.TabIndex = 2;
            this.sidebarLieferung.TabStop = false;
            this.sidebarLieferung.Text = "Lieferung";
            this.sidebarLieferung.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidebarLieferung.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sidebarLieferung.UseVisualStyleBackColor = true;
            this.sidebarLieferung.Click += new System.EventHandler(this.iconButton3_Click);
            // 
            // sidebarAuftrag
            // 
            this.sidebarAuftrag.Dock = System.Windows.Forms.DockStyle.Top;
            this.sidebarAuftrag.Enabled = false;
            this.sidebarAuftrag.FlatAppearance.BorderSize = 0;
            this.sidebarAuftrag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sidebarAuftrag.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sidebarAuftrag.ForeColor = System.Drawing.Color.White;
            this.sidebarAuftrag.IconChar = FontAwesome.Sharp.IconChar.Tasks;
            this.sidebarAuftrag.IconColor = System.Drawing.Color.Chocolate;
            this.sidebarAuftrag.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.sidebarAuftrag.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidebarAuftrag.Location = new System.Drawing.Point(0, 180);
            this.sidebarAuftrag.Name = "sidebarAuftrag";
            this.sidebarAuftrag.Padding = new System.Windows.Forms.Padding(5, 0, 10, 0);
            this.sidebarAuftrag.Size = new System.Drawing.Size(240, 60);
            this.sidebarAuftrag.TabIndex = 1;
            this.sidebarAuftrag.Text = "Auftrag";
            this.sidebarAuftrag.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidebarAuftrag.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sidebarAuftrag.UseVisualStyleBackColor = true;
            this.sidebarAuftrag.EnabledChanged += new System.EventHandler(this.sidebarAuftrag_EnabledChanged);
            this.sidebarAuftrag.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // sidebarLogin
            // 
            this.sidebarLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.sidebarLogin.Dock = System.Windows.Forms.DockStyle.Top;
            this.sidebarLogin.FlatAppearance.BorderSize = 0;
            this.sidebarLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sidebarLogin.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sidebarLogin.ForeColor = System.Drawing.Color.White;
            this.sidebarLogin.IconChar = FontAwesome.Sharp.IconChar.SignInAlt;
            this.sidebarLogin.IconColor = System.Drawing.Color.Chocolate;
            this.sidebarLogin.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.sidebarLogin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidebarLogin.Location = new System.Drawing.Point(0, 120);
            this.sidebarLogin.Name = "sidebarLogin";
            this.sidebarLogin.Padding = new System.Windows.Forms.Padding(5, 0, 10, 0);
            this.sidebarLogin.Size = new System.Drawing.Size(240, 60);
            this.sidebarLogin.TabIndex = 0;
            this.sidebarLogin.TabStop = false;
            this.sidebarLogin.Text = "Login";
            this.sidebarLogin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sidebarLogin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sidebarLogin.UseVisualStyleBackColor = false;
            this.sidebarLogin.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(240, 120);
            this.panel4.TabIndex = 0;
            // 
            // topbar
            // 
            this.topbar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.topbar.Controls.Add(this.btnaddsach);
            this.topbar.Controls.Add(this.panel5);
            this.topbar.Dock = System.Windows.Forms.DockStyle.Top;
            this.topbar.Location = new System.Drawing.Point(240, 0);
            this.topbar.Name = "topbar";
            this.topbar.Size = new System.Drawing.Size(1064, 60);
            this.topbar.TabIndex = 1;
            // 
            // btnaddsach
            // 
            this.btnaddsach.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnaddsach.Enabled = false;
            this.btnaddsach.FlatAppearance.BorderSize = 0;
            this.btnaddsach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnaddsach.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddsach.ForeColor = System.Drawing.Color.White;
            this.btnaddsach.IconChar = FontAwesome.Sharp.IconChar.UserPlus;
            this.btnaddsach.IconColor = System.Drawing.Color.Chocolate;
            this.btnaddsach.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnaddsach.Location = new System.Drawing.Point(835, 0);
            this.btnaddsach.Name = "btnaddsach";
            this.btnaddsach.Padding = new System.Windows.Forms.Padding(10, 5, 10, 0);
            this.btnaddsach.Size = new System.Drawing.Size(56, 60);
            this.btnaddsach.TabIndex = 5;
            this.btnaddsach.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnaddsach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnaddsach.UseVisualStyleBackColor = true;
            this.btnaddsach.Click += new System.EventHandler(this.iconButton1_Click_1);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.sachnr);
            this.panel5.Controls.Add(this.sachname);
            this.panel5.Controls.Add(this.topbarLogout);
            this.panel5.Controls.Add(this.topbarClose);
            this.panel5.Controls.Add(this.topbarSettings);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(891, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(173, 60);
            this.panel5.TabIndex = 0;
            // 
            // sachnr
            // 
            this.sachnr.AutoSize = true;
            this.sachnr.Dock = System.Windows.Forms.DockStyle.Top;
            this.sachnr.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sachnr.ForeColor = System.Drawing.Color.White;
            this.sachnr.Location = new System.Drawing.Point(56, 18);
            this.sachnr.Name = "sachnr";
            this.sachnr.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.sachnr.Size = new System.Drawing.Size(0, 28);
            this.sachnr.TabIndex = 7;
            this.sachnr.Visible = false;
            // 
            // sachname
            // 
            this.sachname.AutoSize = true;
            this.sachname.Dock = System.Windows.Forms.DockStyle.Top;
            this.sachname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sachname.ForeColor = System.Drawing.Color.White;
            this.sachname.Location = new System.Drawing.Point(56, 0);
            this.sachname.Name = "sachname";
            this.sachname.Size = new System.Drawing.Size(0, 18);
            this.sachname.TabIndex = 1;
            this.sachname.Visible = false;
            this.sachname.SizeChanged += new System.EventHandler(this.sachname_SizeChanged);
            // 
            // topbarLogout
            // 
            this.topbarLogout.Dock = System.Windows.Forms.DockStyle.Right;
            this.topbarLogout.Enabled = false;
            this.topbarLogout.FlatAppearance.BorderSize = 0;
            this.topbarLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.topbarLogout.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.topbarLogout.ForeColor = System.Drawing.Color.White;
            this.topbarLogout.IconChar = FontAwesome.Sharp.IconChar.SignOutAlt;
            this.topbarLogout.IconColor = System.Drawing.Color.Chocolate;
            this.topbarLogout.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.topbarLogout.Location = new System.Drawing.Point(61, 0);
            this.topbarLogout.Name = "topbarLogout";
            this.topbarLogout.Padding = new System.Windows.Forms.Padding(10, 5, 10, 0);
            this.topbarLogout.Size = new System.Drawing.Size(56, 60);
            this.topbarLogout.TabIndex = 6;
            this.topbarLogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.topbarLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.topbarLogout.UseVisualStyleBackColor = true;
            this.topbarLogout.Click += new System.EventHandler(this.topbarLogout_Click);
            // 
            // topbarClose
            // 
            this.topbarClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.topbarClose.Dock = System.Windows.Forms.DockStyle.Right;
            this.topbarClose.FlatAppearance.BorderSize = 0;
            this.topbarClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.topbarClose.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.topbarClose.ForeColor = System.Drawing.Color.White;
            this.topbarClose.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.topbarClose.IconColor = System.Drawing.Color.Chocolate;
            this.topbarClose.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.topbarClose.Location = new System.Drawing.Point(117, 0);
            this.topbarClose.Name = "topbarClose";
            this.topbarClose.Padding = new System.Windows.Forms.Padding(10, 5, 10, 0);
            this.topbarClose.Size = new System.Drawing.Size(56, 60);
            this.topbarClose.TabIndex = 5;
            this.topbarClose.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.topbarClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.topbarClose.UseVisualStyleBackColor = true;
            this.topbarClose.Click += new System.EventHandler(this.topbarClose_Click);
            // 
            // topbarSettings
            // 
            this.topbarSettings.Dock = System.Windows.Forms.DockStyle.Left;
            this.topbarSettings.Enabled = false;
            this.topbarSettings.FlatAppearance.BorderSize = 0;
            this.topbarSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.topbarSettings.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.topbarSettings.ForeColor = System.Drawing.Color.White;
            this.topbarSettings.IconChar = FontAwesome.Sharp.IconChar.UserCog;
            this.topbarSettings.IconColor = System.Drawing.Color.Chocolate;
            this.topbarSettings.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.topbarSettings.Location = new System.Drawing.Point(0, 0);
            this.topbarSettings.Name = "topbarSettings";
            this.topbarSettings.Padding = new System.Windows.Forms.Padding(10, 5, 10, 0);
            this.topbarSettings.Size = new System.Drawing.Size(56, 60);
            this.topbarSettings.TabIndex = 4;
            this.topbarSettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.topbarSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.topbarSettings.UseVisualStyleBackColor = true;
            this.topbarSettings.Click += new System.EventHandler(this.topbarSettings_Click);
            // 
            // main
            // 
            this.main.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.main.Location = new System.Drawing.Point(240, 60);
            this.main.Name = "main";
            this.main.Size = new System.Drawing.Size(1064, 785);
            this.main.TabIndex = 2;
            // 
            // Hauptmenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(47)))), ((int)(((byte)(47)))));
            this.ClientSize = new System.Drawing.Size(1304, 845);
            this.Controls.Add(this.main);
            this.Controls.Add(this.topbar);
            this.Controls.Add(this.sidebar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Hauptmenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Firmenname";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.sidebar.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.topbar.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidebar;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel topbar;
        private System.Windows.Forms.Panel main;
        private FontAwesome.Sharp.IconButton sidebarRechnung;
        private FontAwesome.Sharp.IconButton sidebarLieferung;
        private FontAwesome.Sharp.IconButton sidebarAuftrag;
        private FontAwesome.Sharp.IconButton sidebarLogin;
        private System.Windows.Forms.Panel panel5;
        private FontAwesome.Sharp.IconButton topbarLogout;
        private FontAwesome.Sharp.IconButton topbarClose;
        private FontAwesome.Sharp.IconButton topbarSettings;
        private System.Windows.Forms.Label sachname;
        private System.Windows.Forms.Label sachnr;
        private System.Windows.Forms.Panel panel1;
        private FontAwesome.Sharp.IconButton sideMwSt;
        private FontAwesome.Sharp.IconButton sideRohstoff;
        private FontAwesome.Sharp.IconButton sidePalette;
        private FontAwesome.Sharp.IconButton sideProdukt;
        private FontAwesome.Sharp.IconButton sideKunde;
        private FontAwesome.Sharp.IconButton sidebarStammdaten;
        private FontAwesome.Sharp.IconButton sideEinheit;
        private FontAwesome.Sharp.IconButton btnaddsach;
    }
}

