﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    public partial class AuftragPalette : Form
    {
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        public AuftragPalette()
        {
            InitializeComponent();
        }
        public static int auftragPalette = 0;
        public void lieferung()
        {
            comboBox2.DataSource = AuftragAdd.lieferungNr;
        }
        public void palette()
        {
            try
            {
                comboBox3.Text = "";
                comboBox3.Items.Clear();
                con.Open();
                cmd = new OleDbCommand("SELECT Palette.Bez from Palette where Palette.IsActive", con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    comboBox3.Items.Add(dr.GetString(0));
                }
                con.Close();
            }
            catch { }
        }
        private void AuftragPalette_Load(object sender, EventArgs e)
        {
            comboBox2.Text = "";
            comboBox3.Text = "";
            textBox3.Text = "";

            palette();
            lieferung();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            try
            {
                auftragPalette = 1;
                String[] row = { Convert.ToString(comboBox2.SelectedItem), Convert.ToString(comboBox3.SelectedItem), textBox3.Text };
                AuftragAdd.rows = row;
                comboBox2.Text = "";
                comboBox3.Text = "";
                textBox3.Text = "";
            }
            catch { }
        }

        private void AuftragPalette_Enter(object sender, EventArgs e)
        {
            try
            {
                palette();
                lieferung();
            }
            catch { }
        }
    }
}
