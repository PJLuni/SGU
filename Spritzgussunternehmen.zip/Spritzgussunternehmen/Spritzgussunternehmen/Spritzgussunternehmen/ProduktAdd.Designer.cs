﻿namespace Spritzgussunternehmen
{
    partial class ProduktAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label17 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtart = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtbeschreibung = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbez = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txteinheit = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Einheiten = new System.Windows.Forms.DataGridView();
            this.Menge = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.iconButton4 = new FontAwesome.Sharp.IconButton();
            this.txtnr = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.checknr = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txthoehe = new System.Windows.Forms.NumericUpDown();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtlaenge = new System.Windows.Forms.NumericUpDown();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtgewicht = new System.Windows.Forms.NumericUpDown();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtbreite = new System.Windows.Forms.NumericUpDown();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtaktbestand = new System.Windows.Forms.NumericUpDown();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txthpreis = new System.Windows.Forms.NumericUpDown();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txtpreis = new System.Windows.Forms.NumericUpDown();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Einheiten)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txthoehe)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtlaenge)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtgewicht)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtbreite)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtaktbestand)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txthpreis)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtpreis)).BeginInit();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Chocolate;
            this.label17.Location = new System.Drawing.Point(5, 9);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(248, 40);
            this.label17.TabIndex = 122;
            this.label17.Text = "Produktdaten";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Chocolate;
            this.label22.Location = new System.Drawing.Point(312, 45);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(120, 18);
            this.label22.TabIndex = 142;
            this.label22.Text = "Beschreibung";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Chocolate;
            this.label21.Location = new System.Drawing.Point(8, 407);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(151, 18);
            this.label21.TabIndex = 141;
            this.label21.Text = "Aktueller Bestand";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Chocolate;
            this.label1.Location = new System.Drawing.Point(8, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 18);
            this.label1.TabIndex = 121;
            this.label1.Text = "Bezeichnung";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Chocolate;
            this.label20.Location = new System.Drawing.Point(8, 361);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(154, 18);
            this.label20.TabIndex = 140;
            this.label20.Text = "Herstellungs Preis";
            // 
            // txtart
            // 
            this.txtart.BackColor = System.Drawing.Color.White;
            this.txtart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtart.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtart.FormattingEnabled = true;
            this.txtart.Location = new System.Drawing.Point(12, 187);
            this.txtart.Name = "txtart";
            this.txtart.Size = new System.Drawing.Size(289, 26);
            this.txtart.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Chocolate;
            this.label8.Location = new System.Drawing.Point(196, 361);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 18);
            this.label8.TabIndex = 139;
            this.label8.Text = "Preis";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Chocolate;
            this.label7.Location = new System.Drawing.Point(157, 311);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 18);
            this.label7.TabIndex = 138;
            this.label7.Text = "Einheit";
            // 
            // txtbeschreibung
            // 
            this.txtbeschreibung.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbeschreibung.Location = new System.Drawing.Point(315, 66);
            this.txtbeschreibung.Multiline = true;
            this.txtbeschreibung.Name = "txtbeschreibung";
            this.txtbeschreibung.Size = new System.Drawing.Size(274, 387);
            this.txtbeschreibung.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Chocolate;
            this.label6.Location = new System.Drawing.Point(8, 311);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 18);
            this.label6.TabIndex = 137;
            this.label6.Text = "Gewicht";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Chocolate;
            this.label5.Location = new System.Drawing.Point(8, 263);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 18);
            this.label5.TabIndex = 136;
            this.label5.Text = "Länge (mm)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Chocolate;
            this.label4.Location = new System.Drawing.Point(157, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 18);
            this.label4.TabIndex = 135;
            this.label4.Text = "Breite (mm)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Chocolate;
            this.label3.Location = new System.Drawing.Point(8, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 18);
            this.label3.TabIndex = 134;
            this.label3.Text = "Höhe (mm)";
            // 
            // txtbez
            // 
            this.txtbez.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbez.Location = new System.Drawing.Point(12, 139);
            this.txtbez.Name = "txtbez";
            this.txtbez.Size = new System.Drawing.Size(289, 26);
            this.txtbez.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Chocolate;
            this.label2.Location = new System.Drawing.Point(8, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 18);
            this.label2.TabIndex = 133;
            this.label2.Text = "Art";
            // 
            // txteinheit
            // 
            this.txteinheit.BackColor = System.Drawing.Color.White;
            this.txteinheit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txteinheit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txteinheit.FormattingEnabled = true;
            this.txteinheit.Location = new System.Drawing.Point(160, 331);
            this.txteinheit.Name = "txteinheit";
            this.txteinheit.Size = new System.Drawing.Size(140, 26);
            this.txteinheit.TabIndex = 7;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Einheiten);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(3, 57);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(393, 387);
            this.panel2.TabIndex = 152;
            // 
            // Einheiten
            // 
            this.Einheiten.AllowUserToAddRows = false;
            this.Einheiten.AllowUserToDeleteRows = false;
            this.Einheiten.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Einheiten.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Einheiten.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Menge});
            this.Einheiten.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Einheiten.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Einheiten.Location = new System.Drawing.Point(0, 0);
            this.Einheiten.Name = "Einheiten";
            this.Einheiten.Size = new System.Drawing.Size(393, 352);
            this.Einheiten.TabIndex = 11;
            // 
            // Menge
            // 
            this.Menge.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Menge.DataPropertyName = "DGVMenge";
            this.Menge.HeaderText = "Menge";
            this.Menge.Name = "Menge";
            this.Menge.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Menge.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.iconPictureBox1);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 352);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(393, 35);
            this.panel1.TabIndex = 147;
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.iconPictureBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.InfoCircle;
            this.iconPictureBox1.IconColor = System.Drawing.SystemColors.HotTrack;
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.Location = new System.Drawing.Point(3, 3);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(32, 32);
            this.iconPictureBox1.TabIndex = 2;
            this.iconPictureBox1.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Silver;
            this.label10.Location = new System.Drawing.Point(41, 4);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(275, 24);
            this.label10.TabIndex = 1;
            this.label10.Text = "Legen Sie hier bitte fest wie oft dieses Produkt \r\nin die entsprechende Verpackun" +
    "gseinheit passt!";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Chocolate;
            this.label9.Location = new System.Drawing.Point(2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(400, 40);
            this.label9.TabIndex = 151;
            this.label9.Text = "Verpackungseinheiten";
            // 
            // iconButton2
            // 
            this.iconButton2.BackColor = System.Drawing.Color.White;
            this.iconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.FolderPlus;
            this.iconButton2.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.IconSize = 26;
            this.iconButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton2.Location = new System.Drawing.Point(866, 580);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Size = new System.Drawing.Size(134, 35);
            this.iconButton2.TabIndex = 150;
            this.iconButton2.Text = "Hinzufügen";
            this.iconButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton2.UseVisualStyleBackColor = false;
            this.iconButton2.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // iconButton4
            // 
            this.iconButton4.BackColor = System.Drawing.Color.White;
            this.iconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton4.IconChar = FontAwesome.Sharp.IconChar.HandPaper;
            this.iconButton4.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton4.IconSize = 26;
            this.iconButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton4.Location = new System.Drawing.Point(719, 580);
            this.iconButton4.Name = "iconButton4";
            this.iconButton4.Size = new System.Drawing.Size(141, 35);
            this.iconButton4.TabIndex = 149;
            this.iconButton4.Text = "Abbrechen";
            this.iconButton4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconButton4.UseVisualStyleBackColor = false;
            this.iconButton4.Click += new System.EventHandler(this.iconButton4_Click);
            // 
            // txtnr
            // 
            this.txtnr.Enabled = false;
            this.txtnr.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnr.Location = new System.Drawing.Point(11, 68);
            this.txtnr.Name = "txtnr";
            this.txtnr.Size = new System.Drawing.Size(289, 26);
            this.txtnr.TabIndex = 153;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Chocolate;
            this.label11.Location = new System.Drawing.Point(8, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 18);
            this.label11.TabIndex = 154;
            this.label11.Text = "Nr";
            // 
            // checknr
            // 
            this.checknr.AutoSize = true;
            this.checknr.ForeColor = System.Drawing.Color.White;
            this.checknr.Location = new System.Drawing.Point(12, 100);
            this.checknr.Name = "checknr";
            this.checknr.Size = new System.Drawing.Size(150, 16);
            this.checknr.TabIndex = 320;
            this.checknr.Text = "Nummer selbst wählen";
            this.checknr.UseVisualStyleBackColor = true;
            this.checknr.CheckedChanged += new System.EventHandler(this.checknr_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txthoehe);
            this.panel3.Location = new System.Drawing.Point(11, 236);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(141, 27);
            this.panel3.TabIndex = 325;
            // 
            // txthoehe
            // 
            this.txthoehe.DecimalPlaces = 2;
            this.txthoehe.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txthoehe.Location = new System.Drawing.Point(0, 0);
            this.txthoehe.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.txthoehe.Name = "txthoehe";
            this.txthoehe.Size = new System.Drawing.Size(163, 26);
            this.txthoehe.TabIndex = 326;
            this.txthoehe.Enter += new System.EventHandler(this.NUDResetText);
            this.txthoehe.Leave += new System.EventHandler(this.NUDLeaveBlank);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtlaenge);
            this.panel4.Location = new System.Drawing.Point(12, 284);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(140, 27);
            this.panel4.TabIndex = 327;
            // 
            // txtlaenge
            // 
            this.txtlaenge.DecimalPlaces = 2;
            this.txtlaenge.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlaenge.Location = new System.Drawing.Point(0, 0);
            this.txtlaenge.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.txtlaenge.Name = "txtlaenge";
            this.txtlaenge.Size = new System.Drawing.Size(163, 26);
            this.txtlaenge.TabIndex = 326;
            this.txtlaenge.Enter += new System.EventHandler(this.NUDResetText);
            this.txtlaenge.Leave += new System.EventHandler(this.NUDLeaveBlank);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txtgewicht);
            this.panel5.Location = new System.Drawing.Point(12, 331);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(140, 27);
            this.panel5.TabIndex = 327;
            // 
            // txtgewicht
            // 
            this.txtgewicht.DecimalPlaces = 2;
            this.txtgewicht.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgewicht.Location = new System.Drawing.Point(0, 0);
            this.txtgewicht.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.txtgewicht.Name = "txtgewicht";
            this.txtgewicht.Size = new System.Drawing.Size(163, 26);
            this.txtgewicht.TabIndex = 326;
            this.txtgewicht.Enter += new System.EventHandler(this.NUDResetText);
            this.txtgewicht.Leave += new System.EventHandler(this.NUDLeaveBlank);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txtbreite);
            this.panel6.Location = new System.Drawing.Point(160, 236);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(141, 27);
            this.panel6.TabIndex = 327;
            // 
            // txtbreite
            // 
            this.txtbreite.DecimalPlaces = 2;
            this.txtbreite.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbreite.Location = new System.Drawing.Point(0, 0);
            this.txtbreite.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.txtbreite.Name = "txtbreite";
            this.txtbreite.Size = new System.Drawing.Size(163, 26);
            this.txtbreite.TabIndex = 326;
            this.txtbreite.Enter += new System.EventHandler(this.NUDResetText);
            this.txtbreite.Leave += new System.EventHandler(this.NUDLeaveBlank);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txtaktbestand);
            this.panel7.Location = new System.Drawing.Point(12, 428);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(289, 27);
            this.panel7.TabIndex = 328;
            // 
            // txtaktbestand
            // 
            this.txtaktbestand.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaktbestand.Location = new System.Drawing.Point(0, 0);
            this.txtaktbestand.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.txtaktbestand.Name = "txtaktbestand";
            this.txtaktbestand.Size = new System.Drawing.Size(311, 26);
            this.txtaktbestand.TabIndex = 326;
            this.txtaktbestand.Enter += new System.EventHandler(this.NUDResetText);
            this.txtaktbestand.Leave += new System.EventHandler(this.NUDLeaveBlank);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txthpreis);
            this.panel8.Location = new System.Drawing.Point(11, 382);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(182, 27);
            this.panel8.TabIndex = 328;
            // 
            // txthpreis
            // 
            this.txthpreis.DecimalPlaces = 2;
            this.txthpreis.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txthpreis.Location = new System.Drawing.Point(0, 0);
            this.txthpreis.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.txthpreis.Name = "txthpreis";
            this.txthpreis.Size = new System.Drawing.Size(201, 26);
            this.txthpreis.TabIndex = 326;
            this.txthpreis.Enter += new System.EventHandler(this.NUDResetText);
            this.txthpreis.Leave += new System.EventHandler(this.NUDLeaveBlank);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.txtpreis);
            this.panel9.Location = new System.Drawing.Point(199, 382);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(102, 27);
            this.panel9.TabIndex = 329;
            // 
            // txtpreis
            // 
            this.txtpreis.DecimalPlaces = 2;
            this.txtpreis.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpreis.Location = new System.Drawing.Point(0, 0);
            this.txtpreis.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.txtpreis.Name = "txtpreis";
            this.txtpreis.Size = new System.Drawing.Size(124, 26);
            this.txtpreis.TabIndex = 326;
            this.txtpreis.Enter += new System.EventHandler(this.NUDResetText);
            this.txtpreis.Leave += new System.EventHandler(this.NUDLeaveBlank);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.panel2);
            this.panel10.Controls.Add(this.label9);
            this.panel10.Location = new System.Drawing.Point(608, 9);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(402, 446);
            this.panel10.TabIndex = 330;
            // 
            // ProduktAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1011, 626);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.checknr);
            this.Controls.Add(this.txtnr);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.iconButton2);
            this.Controls.Add(this.iconButton4);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtart);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtbeschreibung);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtbez);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txteinheit);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label8);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ProduktAdd";
            this.Text = "ProduktAdd";
            this.Load += new System.EventHandler(this.ProduktAdd_Load);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Einheiten)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txthoehe)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtlaenge)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtgewicht)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtbreite)).EndInit();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtaktbestand)).EndInit();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txthpreis)).EndInit();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtpreis)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox txtart;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtbeschreibung;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtbez;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox txteinheit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView Einheiten;
        private System.Windows.Forms.Panel panel1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private FontAwesome.Sharp.IconButton iconButton2;
        private FontAwesome.Sharp.IconButton iconButton4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Menge;
        private System.Windows.Forms.TextBox txtnr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox checknr;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.NumericUpDown txthoehe;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.NumericUpDown txtlaenge;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.NumericUpDown txtgewicht;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.NumericUpDown txtbreite;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.NumericUpDown txtaktbestand;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.NumericUpDown txthpreis;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.NumericUpDown txtpreis;
        private System.Windows.Forms.Panel panel10;
    }
}