﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class LoadForm
    {
        public static void OpenPanel(Form FormToOpen, Panel PanelToLoadIn)
        {
            try
            {
                FormToOpen.TopLevel = false;
                FormToOpen.FormBorderStyle = FormBorderStyle.None;
                FormToOpen.Dock = DockStyle.Fill;
                PanelToLoadIn.Controls.Add(FormToOpen);
                PanelToLoadIn.Tag = FormToOpen;
                FormToOpen.BringToFront();
                FormToOpen.Show();
            }
            catch (Exception)
            {
                Info.Error("Fenster konnte nicht geöffnet werden!");
            }
            
        }
        public static void OpenTab(Form FormToOpen, TabPage TabToLoadIn)
        {
            try 
            { 
                FormToOpen.TopLevel = false;
                FormToOpen.FormBorderStyle = FormBorderStyle.None;
                FormToOpen.Dock = DockStyle.Fill;
                TabToLoadIn.Controls.Add(FormToOpen);
                TabToLoadIn.Tag = FormToOpen;
                FormToOpen.BringToFront();
                FormToOpen.Show();
            }
            catch (Exception)
            {
                Info.Error("Fenster konnte nicht geöffnet werden!");
            }
}
    }
}
