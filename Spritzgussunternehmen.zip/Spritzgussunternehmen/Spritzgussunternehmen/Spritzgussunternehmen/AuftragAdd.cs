﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    public partial class AuftragAdd : Form
    {
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        Panel panel;
        String[] row;
        public AuftragAdd(String[] row,Panel panel)
        {
            this.row = row;
            this.panel = panel;
            
            InitializeComponent();
        }
        public static int kundenNummer = 0;
        public  void kundenummer()
        {
            try
            {
                con.Open();
                cmd = new OleDbCommand("SELECT Kunde.Nr from Kunde where Kunde.Bez  = '" + textBox1.Text + "'", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                kundenNummer = dr.GetInt32(0);
                con.Close();
            }
            catch (Exception)
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public void auftragSpeichern()
        {
            try
            {
                kundenummer();

                con.Open();
                cmd = new OleDbCommand("SELECT MwSt.Nr from MwSt where MwSt.Prozentsatz  = " + textBox2.Text + "", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                int mwStNummer = dr.GetInt32(0);
                con.Close();

                con.Open();
                cmd = new OleDbCommand("SELECT Auftragsstatus.Nr from Auftragsstatus where Auftragsstatus.Bez  = '" + comboBox1.SelectedItem + "'", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                int statusNummer = dr.GetInt32(0);
                con.Close();

                con.Open();
                cmd = new OleDbCommand("SELECT Benutzerkonto.Nr from Benutzerkonto where Benutzerkonto.Vorname  = '" + textBox5.Text + "'", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                int sachbearbeiterNummer = dr.GetInt32(0);
                con.Close();

                con.Open();
                cmd = new OleDbCommand("SELECT Ansprechpartner.Nr from Ansprechpartner where Ansprechpartner.Name  = '" + textBox6.Text + "'", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                int ansprechpartnerNummer = dr.GetInt32(0);
                con.Close();


                con.Open();
                cmd = new OleDbCommand("Insert into Auftrag (Nr, Kunde, MwSt, Status, Sachbearbeiter, Ansprechpartner, Zahlungsbedingungen, Auslieferungsdatum, IstSteuerfrei, Datum) values ('" + textBox17.Text + "', " + kundenNummer + ", " + mwStNummer + "," + statusNummer + "," + sachbearbeiterNummer + "," + ansprechpartnerNummer + ", '" + textBox8.Text + "', '" + dateTimePicker1.Value + "', " + checkBox7.Checked + ", '" + dateTimePicker2.Value + "')", con);
                cmd.ExecuteNonQuery();
                con.Close();

                Info.Success("Anlegen erfolreich!");

            }
            catch {
                Info.Error("Fehler beim Speichern");
            }
        }


        public void auftragLieferungSpeichern()
        {
            try {
                for (int i = 0; i < dataGridViewLieferung.Rows.Count; i++)
                {
                    int produktNummer = 0;
                    int lieferbedingungenNummer = 0;
                    int kundeLieferortNummer = 0;
                    con.Open();
                    cmd = new OleDbCommand("SELECT Produkt.Nr from Produkt where Produkt.Bez  = '" + dataGridViewLieferung.Rows[i].Cells[1].Value.ToString() + "'", con);
                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        produktNummer = dr.GetInt32(0);
                    }

                    con.Close();

                    con.Open();
                    cmd = new OleDbCommand("SELECT Lieferbedingungen.Nr from Lieferbedingungen where Lieferbedingungen.Bez  = '" + dataGridViewLieferung.Rows[i].Cells[1].Value.ToString() + "'", con);
                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        lieferbedingungenNummer = dr.GetInt32(0);
                    }
                    con.Close();

                    con.Open();
                    cmd = new OleDbCommand("SELECT KundeLieferort.Nr from KundeLieferort where KundeLieferort.Bez  = '" + dataGridViewLieferung.Rows[i].Cells[2].Value.ToString() + "'", con);
                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        kundeLieferortNummer = dr.GetInt32(0);
                    }
                    con.Close();

                    con.Open();
                    cmd = new OleDbCommand("Insert into AuftragLieferung (Nr, Lieferbedingung, KundeLieferort, Auftrag, Lieferdatum, LieferbedingungText) values (" + Convert.ToInt32(dataGridViewLieferung.Rows[i].Cells[0].Value.ToString()) + " , " + lieferbedingungenNummer + "," + kundeLieferortNummer + " ,'" + textBox17.Text + "','" + dataGridViewLieferung.Rows[i].Cells[3].Value + "', '" + dataGridViewLieferung.Rows[i].Cells[4].Value.ToString() + "')", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch { }
        }
        public void auftragPositionSpeichern()
        {
            try
            {
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    con.Open();
                    cmd = new OleDbCommand("SELECT Mengeneinheit.Nr from Mengeneinheit Where Mengeneinheit.Bez = '" + dataGridView1.Rows[i].Cells[3].Value.ToString() + "'", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    int mengeneinheitNummer = dr.GetInt32(0);
                    con.Close();

                    con.Open();
                    cmd = new OleDbCommand("Insert into AuftragPosition (Nr, Auftrag, AuftragLieferung, Mengeneinheit, ProduktVerpackungseinheit, Menge, Preis) values (" + Convert.ToInt32(dataGridView1.Rows[i].Cells[0].Value.ToString()) + " , " + textBox17.Text + "," + Convert.ToInt32(dataGridView1.Rows[i].Cells[1].Value.ToString()) + "," + mengeneinheitNummer + "," + Convert.ToInt32(dataGridView1.Rows[i].Cells[5].Value.ToString()) + ", " + Convert.ToInt32(dataGridView1.Rows[i].Cells[6].Value.ToString()) + ", " + dataGridView1.Rows[i].Cells[7].Value.ToString().Replace(",", ".") + ")", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch { }
        }
        public void auftragPaletteSpeichern()
        {
            try
            {
                for (int i = 0; i < dataGridView2.Rows.Count; i++)
                {
                    con.Open();
                    cmd = new OleDbCommand("SELECT Palette.Nr from Palette Where Palette.Bez = '" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "'", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    int paletteNummer = dr.GetInt32(0);
                    con.Close();

                    con.Open();
                    cmd = new OleDbCommand("Insert into AuftragLieferungPalette (AuftragLieferung, Palette, geplanterAusgang) values (" + Convert.ToInt32(dataGridView1.Rows[i].Cells[0].Value.ToString()) + " , " + paletteNummer + "," + Convert.ToInt32(dataGridView1.Rows[i].Cells[1].Value.ToString()) + ")", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch { }
        }
        public void status()
        {
            try
            {
                con.Open();
                cmd = new OleDbCommand("SELECT Auftragsstatus.Bez From Auftragsstatus where Auftragsstatus.IsActive = true", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    comboBox1.Items.Add(dr.GetString(0));
                }
                con.Close();
                comboBox1.SelectedItem = "In Bearbeitung";
            }
            catch { }
        }
        public void mwSt()
        {

            try
            {
                if (checkBox7.Checked)
                {
                    textBox2.Text = "";

                    con.Open();
                    cmd = new OleDbCommand("SELECT distinct MwSt.Prozentsatz from MwSt Where MwSt.Nr = 1 and MwSt.IsActive = true", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    textBox2.Text = Convert.ToString(dr.GetInt32(0));

                    con.Close();
                }
                else
                {
                    checkBox7.Checked = false;
                    textBox2.Text = "";

                    con.Open();
                    cmd = new OleDbCommand("Select MwSt.Prozentsatz from MwSt where IsActive = True and not (MwSt.Nr=1)", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    textBox2.Text = Convert.ToString(dr.GetInt32(0));

                    con.Close();
                }
            }
            catch (Exception err)
            {
                if(con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                MessageBox.Show("Rofl\n\n" + err);
            }
        }
        private void AuftragAdd_Load(object sender, EventArgs e)
        {
            mwSt();
            status();
            edit.nrHochZaehlen("Auftrag", textBox17);
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            mwSt();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                LoadForm.OpenPanel(new AuftragLieferung(), loadPanel);
                
                checkBox2.Checked = false;
                checkBox1.Checked = false;
                kundenummer();
            }
            else
            {
                if (!checkBox2.Checked&&!checkBox1.Checked)
                {
                    loadPanel.Controls.Clear();
                }
                
            }
            
        }
        public static int[] lieferungNr = { };
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (checkBox2.Checked)
                {
                    if (checkBox2.Checked)
                    {
                        int[] Data = new int[dataGridViewLieferung.Rows.Count];
                        foreach (DataGridViewRow row in dataGridViewLieferung.Rows)
                        {

                            Data[row.Index] = Convert.ToInt32(dataGridViewLieferung.Rows[row.Index].Cells["Nr"].Value.ToString());

                        }
                        lieferungNr = Data;
                    }
                    LoadForm.OpenPanel(new AuftragPosition(), loadPanel);
                    checkBox3.Checked = false;
                    checkBox1.Checked = false;
                }
                else
                {
                    if (!checkBox3.Checked && !checkBox1.Checked)
                    {
                        loadPanel.Controls.Clear();
                    }

                }
            }
            catch { }
        }
        
        public static String[] rows= {};


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                auftragSpeichern();
                auftragLieferungSpeichern();
                auftragPositionSpeichern();
                auftragPaletteSpeichern();
            }
            catch { }
            
        }
        public static int nummerLieferung = 0;
        private void iconButton3_Click(object sender, EventArgs e)
        {
            try {
                if (AuftragLieferung.auftragLieferung == 1)
                {
                    dataGridViewLieferung.Rows.Add(rows);
                    panel2.Visible = true;
                    AuftragLieferung.auftragLieferung = 0;
                    for (int i = 0; i < dataGridViewLieferung.Rows.Count; i++)
                    {
                        nummerLieferung = Convert.ToInt32(dataGridViewLieferung.Rows[i].Cells["Nr"].Value.ToString());
                        int hochzählen = nummerLieferung + 1;
                        nummerLieferung = hochzählen;
                    }
                }
            }catch { }
        }
        public static int nummerPosition = 0;
        private void iconButton1_Click(object sender, EventArgs e)
        {
            try {
                if (AuftragPosition.auftragPosition == 1)
                {
                    dataGridView1.Rows.Add(rows);
                    panel1.Visible = true;
                    AuftragPosition.auftragPosition = 0;
                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        nummerPosition = Convert.ToInt32(dataGridView1.Rows[i].Cells["P_Nr"].Value.ToString());
                        int hochzählen = nummerPosition + 1;
                        nummerPosition = hochzählen;
                    } }
            }
            catch { }
        }
        
        private void iconButton5_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow item in this.dataGridViewLieferung.SelectedRows)
                {
                    dataGridViewLieferung.Rows.RemoveAt(item.Index);
                    if (dataGridViewLieferung.Rows.Count > 0)
                    {
                        for (int i = 0; i < dataGridViewLieferung.Rows.Count; i++)
                        {

                            nummerLieferung = Convert.ToInt32(dataGridViewLieferung.Rows[i].Cells["Nr"].Value.ToString());
                            int hochzählen = nummerLieferung + 1;
                            nummerLieferung = hochzählen;

                        }
                    }
                    else
                    {
                        nummerLieferung = 0;
                    }
                }
            }
            catch { }
        }

        private void iconButton7_Click(object sender, EventArgs e)
        {
            try {
                foreach (DataGridViewRow item in this.dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows.RemoveAt(item.Index);
                    if (dataGridView1.Rows.Count > 0)
                    {
                        for (int i = 0; i < dataGridView1.Rows.Count; i++)
                        {

                            nummerPosition = Convert.ToInt32(dataGridView1.Rows[i].Cells["R_Nr"].Value.ToString());
                            int hochzählen = nummerPosition + 1;
                            nummerPosition = hochzählen;

                        }
                    }
                    else
                    {
                        nummerPosition = 0;
                    } }
            }
            catch { }
        }
        public static int kunde = 0;
        public static int kundeAnzeigen = 0;
        private void label1_Click(object sender, EventArgs e)
        {
            kundeAnzeigen = 1;
            KundeSuchen kundeSuchen = new KundeSuchen(new TabControl(), new Panel());
            kundeSuchen.Show();
            
        }

        

        public static int sachbearbeiter = 0;
        public static int sachbearbeiterAnzeigen = 0;
        private void label5_Click(object sender, EventArgs e)
        {
            sachbearbeiterAnzeigen = 1;
            SacharbeiterSuchen sacharbeiterSuchen = new SacharbeiterSuchen();
            sacharbeiterSuchen.Show();
        }

       
        public static int ansprechpartner = 0;
        public static int ansprechpartnerAnzeigen = 0;
        private void label6_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.TextLength > 0)
                {
                    con.Open();
                    cmd = new OleDbCommand("SELECT Kunde.Nr from Kunde where Kunde.Bez = '" + textBox1.Text + "'", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    string kunde = Convert.ToString(dr.GetInt32(0));
                    con.Close();

                    ansprechpartnerAnzeigen = 1;
                    Ansprechpartner ansprechpartner = new Ansprechpartner(kunde, new TabControl(), new TabPage());
                    ansprechpartner.Show();
                }
                else
                {
                    MessageBox.Show("Geben sie zuerst einen Kunden an");
                }
            }
            catch { }
        }
        

        private void iconButton4_Click(object sender, EventArgs e)
        {
            try
            {
                if (kunde > 0)
                {
                    con.Open();
                    cmd = new OleDbCommand("SELECT Kunde.Bez from Kunde where Kunde.Nr  =" + kunde + "", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    string kundeBez = dr.GetString(0);
                    con.Close();
                    textBox1.Text = Convert.ToString(kundeBez);
                    kunde = 0;
                }

                if (sachbearbeiter > 0)
                {
                    adap = new OleDbDataAdapter("SELECT Benutzerkonto.Nr from Benutzerkonto where Benutzerkonto.Nr  =" + sachbearbeiter + "and Benutzerkonto.IsActive=True", con);
                    con.Open();
                    DataTable dt = new DataTable();
                    DataRow d = dt.NewRow();
                    adap.Fill(dt);
                    con.Close();

                    if (dt.Rows.Count > 0)
                    {
                        con.Open();
                        cmd = new OleDbCommand("SELECT Benutzerkonto.Vorname from Benutzerkonto where Benutzerkonto.Nr  =" + sachbearbeiter + "and Benutzerkonto.IsActive=True", con);
                        dr = cmd.ExecuteReader();
                        dr.Read();
                        string SachbearbeiterBez = dr.GetString(0);
                        con.Close();
                        textBox5.Text = Convert.ToString(SachbearbeiterBez);
                        sachbearbeiter = 0;
                    }
                    else
                    {
                        MessageBox.Show("Die nummer gehört keinem Mitarbeiter oder einem nicht Aktiven");
                    }
                }

                if (ansprechpartner > 0)
                {
                    con.Open();
                    cmd = new OleDbCommand("SELECT Ansprechpartner.Name from Ansprechpartner where Ansprechpartner.Nr  =" + ansprechpartner + "", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    string AnsprechpartnerName = dr.GetString(0);
                    con.Close();
                    textBox6.Text = Convert.ToString(AnsprechpartnerName);
                    ansprechpartner = 0;
                }
            }
            catch { }
        }

        private void label1_MouseHover(object sender, EventArgs e)
        {
            Font font = new Font(label1.Font, FontStyle.Underline);
            label1.Font = font;
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            Font font = new Font(label1.Font, FontStyle.Regular);
            label1.Font = font;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (checkBox1.Checked)
                {
                    int[] Data = new int[dataGridViewLieferung.Rows.Count];
                    foreach (DataGridViewRow row in dataGridViewLieferung.Rows)
                    {
                        Data[row.Index] = Convert.ToInt32(dataGridViewLieferung.Rows[row.Index].Cells["Nr"].Value.ToString());
                    }
                    lieferungNr = Data;

                    LoadForm.OpenPanel(new AuftragPalette(), loadPanel);
                    checkBox3.Checked = false;
                    checkBox2.Checked = false;
                }
                else
                {
                    if (!checkBox2.Checked && !checkBox3.Checked)
                    {
                        loadPanel.Controls.Clear();
                    }

                }
            }
            catch { }
        }
        
        private void iconButton2_Click(object sender, EventArgs e)
        {
            if (AuftragPalette.auftragPalette == 1)
            {
                dataGridView2.Rows.Add(rows);

                AuftragPalette.auftragPalette = 0;
            }
        }

        private void iconButton9_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow item in this.dataGridView2.SelectedRows)
            {
                dataGridView2.Rows.RemoveAt(item.Index);
            }
        }

        private void label5_MouseHover(object sender, EventArgs e)
        {
            Font font = new Font(label5.Font, FontStyle.Underline);
            label5.Font = font;
        }

        private void label5_MouseLeave(object sender, EventArgs e)
        {
            Font font = new Font(label5.Font, FontStyle.Regular);
            label5.Font = font;
        }

        private void label6_MouseHover(object sender, EventArgs e)
        {
            Font font = new Font(label6.Font, FontStyle.Underline);
            label6.Font = font;
        }

        private void label6_MouseLeave(object sender, EventArgs e)
        {
            Font font = new Font(label6.Font, FontStyle.Regular);
            label6.Font = font;
        }
    }
    }

