﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Produktart
    {
        private static DataSet ds = new DataSet();
        public static void LoadProduktarten(ComboBox comboBox)
        {
            try
            {
                DB.cmd = DB.createCmd("SELECT Bez FROM Produktart WHERE IsActive = true");
                DB.getCon().Open();
                DB.dr = DB.cmd.ExecuteReader();

                while (DB.dr.Read())
                {
                    comboBox.Items.Add(DB.dr.GetString(0));
                }
                DB.getCon().Close();
            }
            catch (Exception)
            {
            }
            
        }
        public static void SuchenDataGridFuellen(DataGridView DataGrid)
        {
            try
            {
                DB.adap = new OleDbDataAdapter("SELECT * FROM Produktart WHERE IsActive = true", DB.getCon());

                ds.Clear();

                DB.adap.Fill(ds, "Produktarten");

                DataGrid.DataSource = ds;
                DataGrid.DataMember = "Produktarten";

                DataGrid.ClearSelection();
            }
            catch (Exception)
            {
            }
            
        }
        public static string GetProdArtBez(int Nr)
        {
            try
            {
                DB.cmd = DB.createCmd($"SELECT Bez FROM ProduktArt WHERE Nr = {Nr}");
                DB.getCon().Open();
                string Bez = DB.cmd.ExecuteScalar().ToString();
                DB.getCon().Close();

                return Bez;
            }
            catch (Exception) { }
            return "";
        }
        public static void ErstelleProduktart(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Bez = Data[1];

                    DB.cmd = new OleDbCommand($"SELECT count(*) FROM Produktart WHERE Nr = {Nr}", DB.getCon());
                    DB.getCon().Open();
                    int partexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (partexist <= 0)
                    {
                        DB.cmd = new OleDbCommand($"INSERT INTO Produktart (Nr, Bez, IsActive) " +
                                               $"VALUES ({Nr}, '{Bez}', true)", DB.getCon());
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        Info.Success("Produktart wurde erfolgreich hinzugefügt!");
                    }
                    else
                    {
                        Info.Error("Produktart existiert bereits!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
        public static void BearbeiteProduktart(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Bez = Data[1];

                    DB.cmd = new OleDbCommand($"SELECT count(*) FROM Produktart WHERE Nr = {Nr}", DB.getCon());
                    DB.getCon().Open();
                    int mengexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (mengexist > 0)
                    {
                        DB.cmd = new OleDbCommand($"UPDATE Produktart SET Bez = '{Bez}', IsActive = true WHERE Nr = {Nr}", DB.getCon());
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        Info.Success("Produktart wurde erfolgreich bearbeitet!");
                    }
                    else
                    {
                        Info.Error("Produktart existiert nicht!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
        public static void LoescheProduktart(DataGridView DataGrid)
        {
            try
            {
                DialogResult result = MessageBox.Show("Sind Sie sicher das Sie die ausgewählte Produktart löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (DataGrid.SelectedRows.Count != 0)
                    {
                        DataGridViewRow row = DataGrid.SelectedRows[0];
                        string ZuLoeschen = row.Cells[0].Value.ToString();

                        DB.cmd = new OleDbCommand($"SELECT count(*) FROM Produktart WHERE Nr = {ZuLoeschen}", DB.getCon());
                        DB.getCon().Open();
                        int mengexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                        DB.getCon().Close();

                        if (mengexist > 0)
                        {
                            DB.cmd = new OleDbCommand($"UPDATE Produktart SET IsActive = false WHERE Nr = {ZuLoeschen}", DB.getCon());
                            DB.getCon().Open();
                            DB.cmd.ExecuteNonQuery();
                            DB.getCon().Close();

                            DataGrid.Rows.Remove(row);

                            Info.Success("Produktart wurde erfolgreich gelöscht!");
                        }
                        else
                        {
                            Info.Error("Produktart existiert nicht!");
                        }
                    }
                    else
                    {
                        Info.Information("Bitte wählen Sie eine Produktart aus!");
                    }
                }
            }
            catch (Exception)
            {
            }
           
        }
        public static void SucheProduktart(string Search, DataGridView DataGrid)
        {
            try
            {
                bool check = int.TryParse(Search, out _);

                if (check)
                {
                    DB.adap = new OleDbDataAdapter($"SELECT * FROM Produktart WHERE Nr LIKE '%{Search}%' AND IsActive = true", DB.getCon());

                    ds.Clear();

                    DB.adap.Fill(ds, "Produktart");

                    DataGrid.DataSource = ds;
                    DataGrid.DataMember = "Produktart";
                }
                else
                {
                    DB.adap = new OleDbDataAdapter($"SELECT * FROM Produktart WHERE Bez LIKE '%{Search}%' AND IsActive = true", DB.getCon());

                    ds.Clear();

                    DB.adap.Fill(ds, "Produktart");

                    DataGrid.DataSource = ds;
                    DataGrid.DataMember = "Produktart";
                }
            }
            catch (Exception)
            {
                Info.Error("Fehler beim Suchen!");
            }
        }
    }
}
