﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class LieferscheinSuchen : Form
    {
        Helfer Manni = new Helfer();
        public LieferscheinSuchen()
        {
            InitializeComponent();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            Lieferschein.SucheLieferschein(txtsearch.Text, Lieferscheine);
        }

        private void LieferscheinSuchen_Load(object sender, EventArgs e)
        {
            date.MinDate = DateTime.Today;
            txtnr.Text = Manni.LetzteNummer("Lieferschein").ToString();
            
            Lieferschein.SuchenDataGridFuellen(Lieferscheine);
            Mengeneinheit.LoadMengeneinheiten(txteinheit);
            Kunde.LoadKunden(comboKunde);
            AuftragLieferungClass.LoadAL(comboLieferung);
            Palette.LoadPaletten(comboPalette);
            Lieferscheine.ClearSelection();
        }

        private void checknr_CheckedChanged(object sender, EventArgs e)
        {
            if (txtnr.Enabled == false)
            {
                txtnr.Enabled = true;
                txtnr.Clear();
            }
            else
            {
                txtnr.Enabled = false;
                try
                {
                    txtnr.Text = Manni.LetzteNummer("Lieferschein").ToString();
                }
                catch (Exception)
                {
                    txtnr.Text = 1.ToString();
                }
                
            }
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            if (btnrohadd.Text == "Lieferschein hinzufügen")
            {
                txtnr.Text = Manni.LetzteNummer("Lieferschein").ToString();
                txtgewicht.Value = 0;
                txteinheit.SelectedItem = null;
                comboKunde.SelectedItem = null;
                checknr.Checked = false;
                txtnr.Enabled = false;
            }
            else
            {
                panel1.Visible = false;
                panel2.Visible = false;
                txtnr.Text = Manni.LetzteNummer("Lieferschein").ToString();
                txtgewicht.Value = 0;
                txteinheit.SelectedItem = null;
                comboKunde.SelectedItem = null;
                Lieferscheine.ClearSelection();
                btnrohadd.Text = "Lieferschein hinzufügen";
                checknr.Enabled = true;
                checknr.Checked = false;
                txtnr.Enabled = false;
                date.MinDate = DateTime.Today;
            }
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            Lieferschein.LoescheLieferschein(Lieferscheine);
        }

        private void btnrohadd_Click(object sender, EventArgs e)
        {
            bool DataFilled = true;
            foreach(Control CON in this.Controls)
            {
                if(CON is TextBox)
                {
                    if(CON.Text == "" && CON.Name != "txtsearch")
                    {
                        DataFilled = false;
                    }
                }
                if(CON is ComboBox)
                {
                    if ((CON as ComboBox).SelectedItem == null)
                    {
                        DataFilled = false;
                    }
                }
            }
            if (DataFilled)
            {
                Lieferschein.Nr = Convert.ToInt32(txtnr.Text);
                Lieferschein.EinheitBez = txteinheit.Text;
                Lieferschein.AuftragLieferung = Convert.ToInt32(comboLieferung.Text);
                Lieferschein.Kunde = Convert.ToInt32(comboKunde.Text);
                Lieferschein.Zustellung = date.Value.ToShortDateString();
                Lieferschein.Gewicht = txtgewicht.Value.ToString();
                
                if (btnrohadd.Text == "Lieferschein hinzufügen")
                {
                    Lieferschein.ErstelleLieferschein();
                }
                else
                {
                    Lieferschein.BearbeiteLieferschein();
                }
                Lieferschein.SuchenDataGridFuellen(Lieferscheine);
            }
            else
            {
                Info.Information("Bitte alle Felder ausfüllen!");
            }
        }

        private void Lieferscheine_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (Lieferscheine.SelectedRows.Count > 0)
                {
                    int Nr = Convert.ToInt32(Lieferscheine.SelectedRows[0].Cells[0].Value);
                    int Kunde = Convert.ToInt32(Lieferscheine.SelectedRows[0].Cells[3].Value);
                    string Gewicht = Lieferscheine.SelectedRows[0].Cells[5].Value.ToString();
                    int Lieferung = Convert.ToInt32(Lieferscheine.SelectedRows[0].Cells[2].Value);
                    DateTime Date = Convert.ToDateTime(Lieferscheine.SelectedRows[0].Cells[4].Value);

                    int EinheitNr = Convert.ToInt32(Lieferscheine.SelectedRows[0].Cells[3].Value);
                    string EinheitBez = Manni.getMengenBez(EinheitNr);

                    txtsellieferschein.Text = Nr.ToString();
                    txtnr.Text = Nr.ToString();
                    comboKunde.SelectedItem = Kunde.ToString();
                    txtgewicht.Value = Convert.ToDecimal(Gewicht);
                    comboLieferung.SelectedItem = Lieferung.ToString();
                    txteinheit.SelectedItem = EinheitBez;
                    date.Value = Date;
                    

                    btnrohadd.Text = "Lieferschein bearbeiten";
                    checknr.Enabled = false;
                    checknr.Checked = false;
                    txtnr.Enabled = false;
                    panel1.Visible = true;
                    panel2.Visible = true;

                    date.MinDate = Convert.ToDateTime("01.01.1900");

                    Lieferschein.Nr = Nr;
                    Lieferschein.PalettenDataGridFuellen(Paletten);
                }
            }
            catch (Exception err)
            {
                throw err;
            }
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            bool DataFilled = true;
            foreach (Control CON in panel1.Controls)
            {
                if (CON is TextBox)
                {
                    if (CON.Text == "" && CON.Name != "txtsearch")
                    {
                        DataFilled = false;
                    }
                }
                if (CON is ComboBox)
                {
                    if ((CON as ComboBox).SelectedItem == null)
                    {
                        DataFilled = false;
                    }
                }
            }
            if (DataFilled)
            {
                Lieferschein.Nr = Convert.ToInt32(txtnr.Text);
                Lieferschein.Palette = Convert.ToInt32(comboPalette.SelectedItem);
                Lieferschein.Eingang = Convert.ToInt32(paleingang.Value);
                Lieferschein.Ausgnag = Convert.ToInt32(palausgang.Value);

                Lieferschein.ErstellePalette();
                
                Lieferschein.SuchenDataGridFuellen(Lieferscheine);
            }
            else
            {
                Info.Information("Bitte alle Felder ausfüllen!");
            }
        }

        private void Lieferscheine_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            Lieferscheine.Rows[e.RowIndex].Selected = true;
        }

        private void iconButton8_Click(object sender, EventArgs e)
        {
            Lieferschein.SuchenDataGridFuellen(Lieferscheine);
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            if(Paletten.SelectedRows != null)
            {
                Lieferschein.Nr = Convert.ToInt32(Paletten.SelectedRows[0].Cells[0].Value);
                Lieferschein.Palette = Convert.ToInt32(Paletten.SelectedRows[0].Cells[1].Value);

                Lieferschein.LoeschePalette();
                Paletten.Rows.Remove(Paletten.SelectedRows[0]);
            }
            else
            {
                Info.Information("Palette wählen!");
            }
            
        }
    }
}
