﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.ComponentModel;

namespace Spritzgussunternehmen
{
    class edit
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        
       
        public static void ClearTextBoxes(Control parent)
        {
            foreach (Control child in parent.Controls)
            {
                TextBox textBox = child as TextBox;
                if (textBox == null)
                    ClearTextBoxes(child);
                else
                    textBox.Text = "";
            }
        }

        public static void pageswitch(TabPage tabPage,TabControl TC)
        {
            if (TC.TabPages.Contains(tabPage))
            {
                MessageBox.Show("Sie können die Seite nicht zwei mal aufrufen");
            }
            else
            {

            }
        }

        public static void DataGridFuellen(OleDbDataAdapter adap,DataGridView dataGridView)
        {
            
            DataSet ds = new DataSet();
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
            if (adap == null)
            {
                adap = new OleDbDataAdapter();
            }
            else
            {

            }

            ds.Clear();

            adap.Fill(ds, "filter");

            dataGridView.DataSource = ds;
            dataGridView.DataMember = "filter";

            dataGridView.Sort(dataGridView.Columns["Nr"], ListSortDirection.Ascending);
        }

        public static void IstAktiv(OleDbDataAdapter adapter, DataGridView dataGridView, int zeile)
        {

            for (int i = dataGridView.Rows.Count-1; i >= 0; i--)
            {


                bool test = (bool)(dataGridView.Rows[i].Cells[zeile].Value);
           
            if (test == false)
            {
                    DataGridViewRow rowToRemove = dataGridView.Rows[i];
                    dataGridView.Rows.Remove(rowToRemove);
            }
            else
            {

            }
        }
        }
    }
}
