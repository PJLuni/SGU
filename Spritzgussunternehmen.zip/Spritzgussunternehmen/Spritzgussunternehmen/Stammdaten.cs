﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FontAwesome.Sharp;

namespace Spritzgussunternehmen
{
    public partial class Stammdaten : Form
    {
        IconButton SelectedBTN;
        public Stammdaten(IconButton SelectedBTN)
        {
            InitializeComponent();
            this.SelectedBTN = SelectedBTN;
        }

        private void Stammdaten_Load(object sender, EventArgs e)
        {
            switch (SelectedBTN.Name)
            {
                case "sideProdukt":
                    TabPage TPPr = new TabPage();
                    TPPr.Text = "Produkt";
                    tabControl1.TabPages.Add(TPPr);
                    LoadForm.OpenTab(new ProduktSuchen(tabControl1), TPPr);
                    break;
                case "sideKunde":
                    TabPage TPKu = new TabPage();
                    TPKu.Text = "Kunde";
                    tabControl1.TabPages.Add(TPKu);
                    LoadForm.OpenTab(new KundeSuchen(tabControl1), TPKu);
                    break;
                case "sideMitarbeiter":
                    TabPage TPMi = new TabPage();
                    TPMi.Text = "Mitarbeiter";
                    tabControl1.TabPages.Add(TPMi);
                    LoadForm.OpenTab(new MitarbeiterSuchen(), TPMi);
                    break;
                case "sidePalette":
                    TabPage TPPa = new TabPage();
                    TPPa.Text = "Palette";
                    tabControl1.TabPages.Add(TPPa);
                    LoadForm.OpenTab(new PaletteSuchen(), TPPa);
                    break;
                case "sideVerpackung":
                    TabPage TPVe = new TabPage();
                    TPVe.Text = "Verpackung";
                    tabControl1.TabPages.Add(TPVe);
                    LoadForm.OpenTab(new VerpackungSuchen(), TPVe);
                    break;
                case "sideMwSt":
                    TabPage TPMw = new TabPage();
                    TPMw.Text = "MwSt";
                    tabControl1.TabPages.Add(TPMw);
                    LoadForm.OpenTab(new MwStSuchen(), TPMw);
                    break;
            }
            
        }
    }
}
