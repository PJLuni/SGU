﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class ProduktAdd : Form
    {
        Produkt NeuesProdukt = new Produkt();
        TabControl NeededTabControl;
        public ProduktAdd(TabControl NeededTabControl)
        {
            InitializeComponent();
            this.NeededTabControl = NeededTabControl;
        }

        private void ProduktAdd_Load(object sender, EventArgs e)
        {
            NeuesProdukt.LoadArten(txtart);
            NeuesProdukt.LoadEinheiten(txteinheit);
            NeuesProdukt.VerpackungsDataGridFuellen(Einheiten);
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            if (txtbez.Text != "" || txtart.Text != "" || txthoehe.Text != "" || txtlaenge.Text != "" || txtbreite.Text != "" || txtmenge.Text != "" || txtbeschreibung.Text != "" || txteinheit.Text != "" || txthpreis.Text != "" || txtpreis.Text != "" || txtaktbestand.Text != "")
            {
                NeuesProdukt.ErstelleProdukt(txtbez.Text, txtart.Text, txthoehe.Text, txtlaenge.Text, txtbreite.Text, txtmenge.Text, txtbeschreibung.Text, txteinheit.Text, txthpreis.Text, txtpreis.Text, txtaktbestand.Text);
                DialogResult result = MessageBox.Show("Möchten Sie die Produktionsschritte direkt im Anschluss erstellen?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    NeuesProdukt.OpenProdSchritte(NeededTabControl);
                }
            }
            else
            {
                MessageBox.Show("Sehr geehrte Brüderinnen und Brüder\nIhnen ist entgangen das Sie alle Texxfelder mit Text beschmücken müssen\nMit adlichen Grüßen,\nIhr Programmierer");
            }
        }
    }
}
