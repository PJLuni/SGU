﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class PaletteSuchen : Form
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        TabControl TC;
        public PaletteSuchen(TabControl TC)
        {
            this.TC = TC;
            InitializeComponent();
        }

        private void Palette_Load(object sender, EventArgs e)
        {
            adap = new OleDbDataAdapter("Select * from Palette" , con);
            edit.DataGridFuellen(adap, dataGridView1);
        }
        TabPage paletteHinzufuegen = new TabPage();
        private void iconButton1_Click(object sender, EventArgs e)
        {
            if (TC.TabPages.Contains(paletteHinzufuegen))
            {
                edit.pageswitch(paletteHinzufuegen, TC);
            }
            else
            {
                long pNr = 0;
                paletteHinzufuegen.Controls.Clear();
                paletteHinzufuegen.Text = "Palette hinzufügen";
                TC.TabPages.Add(paletteHinzufuegen);
                LoadForm.OpenPanel(new Paletteadd(pNr), paletteHinzufuegen);
                TC.SelectedTab = paletteHinzufuegen;
            }
        }
        TabPage paletteBearbeiten = new TabPage();
        private void iconButton4_Click(object sender, EventArgs e)
        {
            if (TC.TabPages.Contains(paletteHinzufuegen))
            {
                edit.pageswitch(paletteHinzufuegen, TC);
            }
            else
            {
                string Ausgewähltezelle =dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();

                cmd = new OleDbCommand("select * from Palette where Nr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);


                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                long pNr = dr.GetInt32(0);
                con.Close();

               
                paletteBearbeiten.Controls.Clear();
                paletteBearbeiten.Text = "Palette bearbeiten";
                TC.TabPages.Add(paletteBearbeiten);
                LoadForm.OpenPanel(new Paletteadd(pNr), paletteBearbeiten);
                TC.SelectedTab = paletteBearbeiten;
            }
        }
    }
}
