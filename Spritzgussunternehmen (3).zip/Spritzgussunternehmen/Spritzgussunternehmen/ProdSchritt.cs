﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class ProdSchritt : Form
    {
        Produkt NeuesProdukt = new Produkt();
        public ProdSchritt()
        {
            InitializeComponent();
        }

        private void ProdSchritt_Load(object sender, EventArgs e)
        {
            NeuesProdukt.LoadEinheiten(rohstoffeinheit);
            NeuesProdukt.LoadProdukte(produktcombo);
        }

        private void produktcombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            NeuesProdukt.LoadProdSchritt(prodschrittcombo, Convert.ToInt32(produktcombo.Text));
            dgvlabel.Text = $"Bereits existierende Produktionsschritte für {NeuesProdukt.GetSelectedProdSchritt(Convert.ToInt32(produktcombo.Text))}";
        }

        private void checkprodschritt_CheckedChanged(object sender, EventArgs e)
        {
            if(!prodschrittcombo.Enabled)
            {
                prodschrittcombo.Enabled = true;
            }
            else
            {
                prodschrittcombo.Enabled = false;
            }
        }
    }
}
