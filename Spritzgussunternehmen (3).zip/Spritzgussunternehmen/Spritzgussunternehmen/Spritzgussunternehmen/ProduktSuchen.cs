﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class ProduktSuchen : Form
    {
        Produkt Produkt = new Produkt();

        TabPage ProduktAdd = new TabPage();
        TabControl PC;
        public ProduktSuchen(TabControl PC)
        {
            InitializeComponent();
            this.PC = PC;
        }

        private void ProduktSuchen_Load(object sender, EventArgs e)
        {
            Produkt.DataGridFuellen(Produkte);
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            if (Produkte.SelectedRows != null)
            {
                Produkt.LoescheProdukt(Produkte);
            }
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            ProduktAdd.Text = "Produkt hinzufügen";
            PC.TabPages.Add(ProduktAdd);
            LoadForm.OpenTab(new ProduktAdd(), ProduktAdd);
            PC.SelectedTab = ProduktAdd;
        }
    }
}
