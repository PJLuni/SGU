﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spritzgussunternehmen
{
    class Helfer
    {
        public static bool TBFilled(List<string> Data)
        {
            bool TextboxesFilled = true;
            foreach (var Text in Data)
            {
                if (Text == "")
                {
                    TextboxesFilled = false;
                }
                
            }
            return TextboxesFilled;
        }
    }
}
