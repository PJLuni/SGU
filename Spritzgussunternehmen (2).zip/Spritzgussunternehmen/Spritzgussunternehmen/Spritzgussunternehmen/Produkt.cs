﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Produkt
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        OleDbDataAdapter adap = null;

        DataSet ds = new DataSet();
        public void LoadEinheiten(ComboBox comboBox)
        {
            cmd = new OleDbCommand("SELECT Bez FROM Mengeneinheit", con);
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetString(0));
            }
            con.Close();
        }
        public void LoadArten(ComboBox comboBox)
        {
            cmd = new OleDbCommand("SELECT Bez FROM Produktart", con);
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetString(0));
            }
            con.Close();
        }

        public void DataGridFuellen(DataGridView DataGrid)
        {
            adap = new OleDbDataAdapter("SELECT * FROM Produkt WHERE IsActive = true", con);

            ds.Clear();

            adap.Fill(ds, "Produkte");

            DataGrid.DataSource = ds;
            DataGrid.DataMember = "Produkte";
        }

        public void ErstelleProdukt(string Bez, string Art, string Hoehe, string Laenge, string Breite, string Menge, string Beschreibung, string Einheit, string HPreis, string Preis, string AktBestand)
        {
            cmd = new OleDbCommand($"SELECT Nr FROM Produktart WHERE Bez = '{Art}'", con);
            con.Open();
            string Produktart = cmd.ExecuteScalar().ToString();
            con.Close();

            cmd = new OleDbCommand($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{Einheit}'", con);
            con.Open();
            string Produkteinheit = cmd.ExecuteScalar().ToString();
            con.Close();

            int Nr = LetzteNummer();
            cmd = new OleDbCommand($"INSERT INTO Produkt (Nr, Art, Bez, Hoehe, Breite, Laenge, Gewicht, Produktbeschreibung, Preis, Lagerbestand, Herstellungskosten, Gewichtseinheit, IsActive) values ({Nr}, '{Bez}', '{Produktart}', {Hoehe}, {Laenge}, {Breite}, {Menge}, '{Beschreibung}' ,'{Produkteinheit}', {HPreis}, {Preis}, {AktBestand}, 'true')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void BearbeiteProdukt()
        {

        }
        public void LoescheProdukt(DataGridView DataGrid)
        {
            DialogResult result = MessageBox.Show("Sind Sie sicher das Sie das ausgewählte Produkt löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                DataGridViewRow row = DataGrid.SelectedRows[0];
                string ZuLoeschen = row.Cells[0].Value.ToString();

                cmd = new OleDbCommand($"UPDATE Produkt SET IsActive = false WHERE Nr = {ZuLoeschen}", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                DataGrid.Rows.Remove(row);
            }
        }
        private int LetzteNummer()
        {
            cmd = new OleDbCommand("SELECT max(Nr) FROM Produkt", con);
            con.Open();
            int Nr = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            return Nr + 1;
        }
    }
}
