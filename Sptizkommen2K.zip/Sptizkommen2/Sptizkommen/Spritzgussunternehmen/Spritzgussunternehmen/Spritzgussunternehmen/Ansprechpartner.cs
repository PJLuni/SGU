﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    
    public partial class Ansprechpartner : Form
    {
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;

        string kundeNr;
        TabControl TC;
        TabPage KP;
        public Ansprechpartner(string kundeNr,TabControl TC,TabPage KP)
        {
            this.KP = KP;
            this.TC = TC;
            this.kundeNr = kundeNr;
            InitializeComponent();
        }
        public void ansprechpartnersuchen()
        {
            adap = new OleDbDataAdapter("SELECT * From Ansprechpartner", con);
            con.Open();
            ds.Clear();

            adap.Fill(ds, "ansprechpartner");

            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "ansprechpartner";

            panel1.Visible = false;
        }
        public void ansprechpartneradd()
        {
                filter.Visible = false;
                panel2.Visible = false;

                adap = new OleDbDataAdapter("SELECT * From Ansprechpartner where Ansprechpartner.Kunde = "+ kundeNr +"", con);
                con.Open();
                ds.Clear();
                adap.Fill(ds, "ansprechpartner");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "ansprechpartner";
                con.Close();
            
        }
        private void Ansprechpartner_Load(object sender, EventArgs e)
        {
            TC.Width = 975;
            textBox1.Text = kundeNr;
            if (textBox1.TextLength==0)
            {
                ansprechpartnersuchen();
            }
            else
            {
                ansprechpartneradd();   
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox17.TextLength>0)
            {
                if (textBox1.TextLength>0)
                {
                      con.Close();
                      con.Open();
                     cmd = new OleDbCommand("Insert into Ansprechpartner (Nr, Kunde, Anrede, Name, Vorname, Email, Telefon, Fax, IsActive) values ('" + textBox17.Text + "', '" + textBox1.Text + "', '" + textBox2.Text + "', '" + textBox3.Text + "','" + textBox9.Text + "','" + textBox4.Text + "', '" + textBox5.Text + "', '" + textBox6.Text + "'," + checkBox2.Checked + ")", con);

                     cmd.ExecuteNonQuery();
                     con.Close();

                    TabPage selectedpage = TC.SelectedTab;

                    TC.TabPages.Remove(selectedpage);
                    TC.SelectedTab = KP;
                }
                else
                {
                    MessageBox.Show("Geben sie bitte einen Kunden ein");
                    textBox1.Focus();
                }
            }
            else
            {
                MessageBox.Show("Geben sie bitte eine Nummer ein");
                textBox17.Focus();
            }
            
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows != null)
            {
                DialogResult result = MessageBox.Show("Sind Sie sicher das Sie den ausgewählten Ansprechpartner löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    con.Close();
                    string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();
                    con.Open();
                    cmd = new OleDbCommand("delete * from Ansprechpartner where Ansprechpartner.Nr = " + Ausgewähltezelle + "", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    con.Close();

                    ansprechpartnersuchen();
                    MessageBox.Show("Gelöscht.");
                }
            }
        }
    }
}
