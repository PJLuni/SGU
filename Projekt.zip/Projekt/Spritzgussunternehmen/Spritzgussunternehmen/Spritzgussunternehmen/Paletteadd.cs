﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class Paletteadd : Form
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        TabControl TC;
        long pNr;
        public Paletteadd(long pNr, TabControl TC)
        {
            this.TC = TC;
            this.pNr = pNr;
            InitializeComponent();
        }
        public void paletteBearbeitenLoad()
        {
            con.Open();
            OleDbCommand cmd = new OleDbCommand("Select * from Palette where Nr = " + pNr + "", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            textBox17.Text = Convert.ToString(dr.GetInt32(0));
            textBox1.Text = dr.GetString(1);
            textBox2.Text = Convert.ToString(dr.GetInt32(2));
            textBox3.Text = Convert.ToString(dr.GetInt32(3));
            textBox4.Text = Convert.ToString(dr.GetInt32(4));
            textBox5.Text = Convert.ToString(dr.GetInt32(5));
            textBox6.Text = Convert.ToString(dr.GetValue(6)) + " €";
            checkBox2.Checked = dr.GetBoolean(7);
            con.Close();
        }
        public void paletteHinzufuegen()
        {
            if (pNr == 0)
            {
                if (textBox17.TextLength > 0)
                {

                    con.Open();
                    cmd = new OleDbCommand("Insert into Palette (Nr, Bez, Lagerbestand, Laenge, Hoehe, Breite, Kosten, IsActive) values ('" + textBox17.Text + "', '" + textBox1.Text + "', '" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "', '" + textBox5.Text + "', '" + textBox6.Text + "'," + checkBox2.Checked + ")", con);

                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Neue Palette wurde erstellt!");

                    TabPage selectedpage = TC.SelectedTab;

                    TC.TabPages.Remove(selectedpage);
                }else
                {
                    MessageBox.Show("Geben sie eine Nummer ein");
                }
            }
        }

        private void Paletteadd_Load(object sender, EventArgs e)
        {
            if (pNr>0)
            {
                label17.Text = "Palette bearbeiten";
                paletteBearbeitenLoad();
            }
            else
            {
                label17.Text= "Palette hinzufügen";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (pNr > 0)
            {

                con.Open();
                cmd = new OleDbCommand("update Palette set Bez = '" + textBox1.Text.ToString() + "', Lagerbestand = '" + textBox2.Text.ToString() + "', Laenge = '" + textBox3.Text.ToString() + "', Hoehe = '" + textBox4.Text.ToString() + "', Breite = '" + textBox5.Text.ToString() + "', Kosten = '" + textBox6.Text.ToString() + "', IsActive = " + checkBox2.Checked + " where Nr = " + Convert.ToInt64(textBox17.Text) + "", con);

                cmd.ExecuteNonQuery();

                con.Close();

               
                    if (textBox17.TextLength == 0)
                    {
                        MessageBox.Show("Geben sie eine Nummer ein!");
                        textBox17.Focus();
                    }
                    else
                    {
                       

                        MessageBox.Show("Update erfolgreich");

                        TabPage selectedpage = TC.SelectedTab;

                        TC.TabPages.Remove(selectedpage);

                    }
            }
            else
            {
                paletteHinzufuegen();
            }

        }
    }
}
