﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FontAwesome.Sharp;
namespace Spritzgussunternehmen
{
    public partial class Stammdaten : Form
    {
        private Form neededForm;
        DataGridView gridView = new DataGridView();
        Panel panel;
        TabPage tp;
        IconButton SelectedBTN;
        public Stammdaten(IconButton SelectedBTN,Panel panel)
        {
            this.panel = panel;
            this.SelectedBTN = SelectedBTN;
            
            InitializeComponent();
        }
        TabPage tabPage1 = new TabPage();
        private void Stammdaten_Load(object sender, EventArgs e)
        {
            switch (SelectedBTN.Name)
            {
                case "sideProdukt":
                    TabPage TPPr = new TabPage();
                    TPPr.Text = "Produkt";
                    tabControl1.TabPages.Add(TPPr);
                    LoadForm.OpenTab(new ProduktSuchen(), TPPr);
                    break;
                case "sideKunde":
                    
                    tabPage1.Text = "Kunde";
                    tabControl1.TabPages.Add(tabPage1);
                    LoadForm.OpenTab(new KundeSuchen(tabControl1,panel), tabPage1);
                    break;
                case "sideMitarbeiter":
                    TabPage TPMi = new TabPage();
                    TPMi.Text = "Mitarbeiter";
                    tabControl1.TabPages.Add(TPMi);
                    LoadForm.OpenTab(new MitarbeiterSuchen(), TPMi);
                    break;
                case "sidePalette":
                    TabPage TPPa = new TabPage(gridView.ToString());
                    TPPa.Text = "Palette";
                    tabControl1.TabPages.Add(TPPa);
                    LoadForm.OpenTab(new PaletteSuchen(tabControl1), TPPa);
                    break;
                case "sideVerpackung":
                    TabPage TPVe = new TabPage();
                    TPVe.Text = "Verpackung";
                    tabControl1.TabPages.Add(TPVe);
                    LoadForm.OpenTab(new VerpackungSuchen(), TPVe);
                    break;
                case "sideMwSt":
                    TabPage TPMw = new TabPage();
                    TPMw.Text = "MwSt";
                    tabControl1.TabPages.Add(TPMw);
                    LoadForm.OpenTab(new MwStSuchen(), TPMw);
                    break;
            }
        }
       

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            TabPage selected = tabControl1.SelectedTab;
            if (tabControl1.SelectedTab==tabPage1)
            {
                
                tabControl1.Height = 727;
                tabControl1.Width = 1262;
                
            }
            if (selected.Text == "Ansprechpartner hinzufuegen" || selected.Text == "Ansprechpartner")
            {
               
                tabControl1.Width = 992;
            }
            else if (selected.Text == "Kunden hinzufügen" || selected.Text == "Kunden Bearbeiten")
            {
                tabControl1.Height = 808;
               
            }
            else
            {
                tabControl1.Width = 1064;
            }
            if (selected.Text == "Palette")
            {
                tabControl1.TabPages.Remove(selected);
                TabPage TPPa = new TabPage(gridView.ToString());
                TPPa.Text = "Palette";
                tabControl1.TabPages.Add(TPPa);
                tabControl1.SelectedTab=TPPa;
                LoadForm.OpenTab(new PaletteSuchen(tabControl1), selected);
            }
        }
        
        private void tabControl1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            tabControl1.TabPages.Remove(tabControl1.SelectedTab);
            if (tabControl1.TabPages.Count < 1)
            {
                    MainMenuPlaceholder mainMenuPlaceholder = new MainMenuPlaceholder();
                    panel.Controls.Remove(tabControl1);
                    this.Close();
                    LoadForm.OpenPanel(mainMenuPlaceholder, panel);
                    Hauptmenu.istplaceholder = true;
                
            }
        }
    }
}
