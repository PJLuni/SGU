﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class Rechnung : Form
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        Panel main;
        public Rechnung(Panel main)
        {
            this.main = main;
            InitializeComponent();
        }

        private void Rechnung_Load(object sender, EventArgs e)
        {
                adap = new OleDbDataAdapter("SELECT Rechnung.Nr, Kunde.Bez as Kunde,Rechnung.Zahlungsbedingungen, Produkt.Bez as Produkt, RechnungPosition.Menge as Menge, Mengeneinheit.Bez as Mengeneinheit, Palette.Bez as Palette, MwSt.Prozentsatz as Steuersatz, RechnungPosition.Preis as Gesamtpreis, Rechnung.IstSteuerfrei, Rechnung.Datum"
                   + " FROM Rechnung, Kunde, Produkt, RechnungPosition, Palette, MwSt, RechnungPositionPalette, Mengeneinheit where Rechnung.Kunde = Kunde.Nr and RechnungPosition.Produkt = Produkt.Nr and RechnungPosition.Mengeneinheit = Mengeneinheit.Nr and RechnungPositionPalette.Palette = Palette.Nr and Rechnung.MwSt = MwSt.Nr and RechnungPosition.Rechnung = Rechnung.Nr and RechnungPositionPalette.Rechnung = Rechnung.Nr"
                   + "", con);
            edit.DataGridFuellen("Nr",adap, dataGridView1);
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            long rechNr = 0;
             RechnungAdd rechnungAdd = new RechnungAdd(rechNr);


             main.Controls.Clear();
             LoadForm.OpenPanel(rechnungAdd, main);
            
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            long rechNr = 1;
            RechnungAdd rechnungAdd = new RechnungAdd(rechNr);


            main.Controls.Clear();
            LoadForm.OpenPanel(rechnungAdd, main);
        }
    }
}
