﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Spritzgussunternehmen
{
    class Error
    {
        public static bool ShowWarning()
        {
            DialogResult result = MessageBox.Show("Alle nicht gespeicherten Daten gehen verloren!", "Bestätigung", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.OK)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
