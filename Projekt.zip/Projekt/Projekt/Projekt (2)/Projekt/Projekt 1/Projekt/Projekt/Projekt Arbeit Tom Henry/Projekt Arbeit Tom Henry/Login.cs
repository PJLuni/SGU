﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Login : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
       OleDbCommand cmd = null;

        OleDbDataReader dr = null;
        public Login()
        {
            InitializeComponent();
            this.KeyDown += new KeyEventHandler(login_KeyDown);
        }

        //Beim Enterdrücken ausführen
       private void login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
               
                e.SuppressKeyPress = true;
                e.Handled = true;
            }
            }
       
        private void button1_Click(object sender, EventArgs e)
        {
            try { 
            string AnmelderMit = textBox1.Text;
            cmd = new OleDbCommand("SELECT * FROM Mitarbeiter WHERE MBenutzername ='" + AnmelderMit + "'", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            bool AnmelderM = dr.GetBoolean(7);
            con.Close();

            cmd = new OleDbCommand("SELECT MBenutzername FROM Mitarbeiter WHERE MBenutzername ='" + AnmelderMit + "'", con);

            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();

            string AnmelderM2 = dr.GetString(0);
            AngemeldeterMitarbeiter.Add(AnmelderM2);

                con.Close();
            if (AnmelderM == true)
            {
                    
                con.Open();

                cmd = new OleDbCommand("select * from Mitarbeiter where MPasswort = '" + textBox2.Text + "' and MBenutzername = '" + textBox1.Text + "'", con);

                dr = cmd.ExecuteReader();
                int Vergleich = 0;
                while (dr.Read())
                {
                    Hauptmenü hauptmenü = new Hauptmenü(AngemeldeterMitarbeiter);
                    hauptmenü.Show();
                    Hide();
                    Vergleich = Vergleich + 1;
                }

                if (Vergleich < 1)
                {
                    MessageBox.Show("Bitte geben sie ihre richtigen Login Daten ein!");
                }

                con.Close();
                    
                }
            }catch
            {
                
                MessageBox.Show("Der angegebende Mitarbeiter ist falsch bzw nich aktice");
            }
        }
        
   public List<string> AngemeldeterMitarbeiter = new List<string>();

        private void Login_Load(object sender, EventArgs e)
        {
          
            textBox2.UseSystemPasswordChar = true;
            
        }
       
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked == true)
            {

                textBox2.UseSystemPasswordChar = false;

            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
           Application.Exit();
        }

    }
}
