﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Einheithinzufügen : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");

        OleDbCommand cmd = null;
        OleDbDataReader dr = null;

        List<string> AngemeldeterMitarbeiter;

        public Einheithinzufügen(List<string> AngemeldeterMitarbeiter)
        {
            this.AngemeldeterMitarbeiter = AngemeldeterMitarbeiter;
            InitializeComponent();
        }
        //Hinzufügen
        private void button1_Click(object sender, EventArgs e)
        {
            Einheit einheit = new Einheit(AngemeldeterMitarbeiter);
            einheit.Show();

            Hide();

            con.Open();

            cmd = new OleDbCommand("Insert into Einheit (EhNr, EhBez, EhIsActive) values ('" + textBox1.Text + "', '" + textBox2.Text + "', "+ checkBox1.Checked +")", con);
            cmd.ExecuteNonQuery();
            con.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Einheit einheit = new Einheit(AngemeldeterMitarbeiter);
            einheit.Show();
            Hide();
        }
        
        //Hochzählen der EhNr
        private void Einheithinzufügen_Load(object sender, EventArgs e)
        {
            cmd = new OleDbCommand("SELECT count(EhNr) FROM Einheit", con);

            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();

            int Anzahl = dr.GetInt32(0);
            con.Close();

            if (Anzahl > 0)
            {
                cmd = new OleDbCommand("SELECT Max(EhNr) FROM Einheit", con);

                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox1.Text = Convert.ToString(dr.GetInt32(0) + 1);
                con.Close();
            }
            else
            {
                textBox1.Text = "1";
            }
        }
    }
}
