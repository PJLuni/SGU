﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Mitarbeiterhinzufügen : Form
    {

        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        OleDbDataReader dr = null;
        OleDbCommand cmd = null;
        List<string> AM;
        public Mitarbeiterhinzufügen(List<string> AM)
        {
            this.AM = AM;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hauptmenü hauptmenü = new Hauptmenü(AM);
            hauptmenü.Show();
            this.Hide();

           
            
            con.Open();
           
            cmd = new OleDbCommand("Insert into Mitarbeiter (MNr, MName, MVorname, MPasswort, MBenutzername, MAbtNr, MReNr, MIsActive) values ('" + textBox1.Text + "', '" + textBox2.Text + "', '" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "', '" + listBox1.SelectedItem + "', '" + listBox2.SelectedItem + "' , " + checkBox1.Checked + ")", con);
            cmd.ExecuteNonQuery();
            con.Close();
           
            

            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mitarbeiterverwaltung mitarbeiterverwaltung = new Mitarbeiterverwaltung(AM);
            mitarbeiterverwaltung.Show();
            Hide();
        }

        private void Mitarbeiterhinzufügen_Load(object sender, EventArgs e)
        {
            cmd = new OleDbCommand("SELECT count(MNr) FROM Mitarbeiter", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            int Anzahl = dr.GetInt32(0);
            con.Close();

            if (Anzahl > 0)
            {
                cmd = new OleDbCommand("SELECT Max(MNr) FROM Mitarbeiter", con);
                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox1.Text = Convert.ToString(dr.GetInt32(0) + 1);
                con.Close();
            }
            else
            {
                textBox1.Text = "1";
            }

            con.Open();
            cmd = new OleDbCommand("select * from Abteilung", con);

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                listBox1.Items.Add(dr.GetInt32(0));
            }
            con.Close();

            con.Open();
            cmd = new OleDbCommand("select * from Rechte", con);

            dr = cmd.ExecuteReader();



            while (dr.Read())
            {

                listBox2.Items.Add(dr.GetInt32(0));
            }

            con.Close();
        
    }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label1.Text = "";
            con.Open();

            int vergleich = Convert.ToInt32(listBox1.SelectedItem.ToString());
            cmd = new OleDbCommand("select AbtBez from Abteilung where AbtNr =" + vergleich, con);

            dr = cmd.ExecuteReader();
            dr.Read();

            label1.Text = dr.GetString(0);
            con.Close();
            label1.Visible = true;
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            label9.Text = "";
            con.Open();

            int vergleich = Convert.ToInt32(listBox2.SelectedItem.ToString());
            cmd = new OleDbCommand("select ReBez from Rechte where ReNr =" + vergleich, con);

            dr = cmd.ExecuteReader();
            dr.Read();

            label9.Text = dr.GetString(0);
            con.Close();
            label9.Visible = true;
        }
    }
}
