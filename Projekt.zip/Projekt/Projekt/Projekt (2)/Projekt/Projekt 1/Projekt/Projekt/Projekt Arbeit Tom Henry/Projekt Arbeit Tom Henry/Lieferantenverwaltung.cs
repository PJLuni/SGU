﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Lieferantenverwaltung : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        DataSet ds = new DataSet();
        List<string> AM;
        public Lieferantenverwaltung(List<string> AM)
        {
            this.AM = AM;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Lieferantenhinzufügen lieferantenhinzufügen = new Lieferantenhinzufügen(AM);
            lieferantenhinzufügen.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hauptmenü hauptmenü = new Hauptmenü(AM);
            hauptmenü.Show();
            this.Hide();
        }

        private void Lieferantenverwaltung_Load(object sender, EventArgs e)
        {
            try
            {
                OleDbDataAdapter Name = new OleDbDataAdapter("Select * from Lieferant ", con);
                
                ds.Clear();
                Name.Fill(ds, "Lieferantenfilter");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Lieferantenfilter";
                
            }
            catch { MessageBox.Show("Fehler beim Befühllen"); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Ansprechpartner ansprechpartner = new Ansprechpartner(AM);
            ansprechpartner.Show();
            Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string s9 = dataGridView1.CurrentRow.Cells["LrNr"].Value.ToString();

            OleDbDataAdapter Name = new OleDbDataAdapter("delete * from Lieferant where LrNr = " + s9 + "", con);
            ds.Clear();
            Name.Fill(ds, "Lieferantenfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Lieferantenfilter";

            MessageBox.Show("Gelöscht. Gehen sie jz auf Aktualisieren!");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Lieferantenverwaltung lieferantenverwaltung = new Lieferantenverwaltung(AM);
            lieferantenverwaltung.Show();
            lieferantenverwaltung.Close();

            Lieferantenverwaltung lieferantenverwaltung1 = new Lieferantenverwaltung(AM);
            lieferantenverwaltung1.Show();

            Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string s9 = dataGridView1.CurrentRow.Cells["LrNr"].Value.ToString();
           
            OleDbDataAdapter Name = new OleDbDataAdapter("update Lieferant set LrName ='" + dataGridView1.CurrentRow.Cells["LrName"].Value.ToString() + "', LrAnrede ='" + dataGridView1.CurrentRow.Cells["LrAnrede"].Value.ToString() + "', LrPostfach ='" + dataGridView1.CurrentRow.Cells["LrPostfach"].Value.ToString() + "', LrFax ='" + dataGridView1.CurrentRow.Cells["LrFax"].Value.ToString() + "', LrBez ='" + dataGridView1.CurrentRow.Cells["LrBez"].Value.ToString() + "', LrEmail ='" + dataGridView1.CurrentRow.Cells["LrEmail"].Value.ToString() + "', LrIsActive=" + dataGridView1.CurrentRow.Cells["LrIsActive"].Value.ToString() + ", LrAdresse ='" + dataGridView1.CurrentRow.Cells["LrAdresse"].Value.ToString() + "', LrTelefon ='" + dataGridView1.CurrentRow.Cells["LrTelefon"].Value.ToString() + "', LrIBAN ='" + dataGridView1.CurrentRow.Cells["LrIBAN"].Value.ToString() + "' where LrNr = " + System.Convert.ToInt64(s9) + "", con);

            ds.Clear();
            Name.Fill(ds, "U_Lieferantenfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "U_Lieferantenfilter";
        }
        private void button7_Click(object sender, EventArgs e)
        {
            Lieferantenhinzufügen lieferantenhinzufügen = new Lieferantenhinzufügen(AM);
            lieferantenhinzufügen.Show();

            Hide();
        }
    }
}
