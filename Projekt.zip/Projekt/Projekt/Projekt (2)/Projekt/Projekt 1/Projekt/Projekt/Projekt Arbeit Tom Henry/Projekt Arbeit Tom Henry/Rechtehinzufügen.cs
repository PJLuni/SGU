﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Rechtehinzufügen : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");


        OleDbDataReader dr = null;

        OleDbCommand cmd = null;
        List<string> AM;
        public Rechtehinzufügen(List<string> AM)
        {
            this.AM = AM;
            InitializeComponent();
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            Rechte rechte = new Rechte(AM);
            rechte.Show();
            Hide();
            con.Open();
            
            cmd = new OleDbCommand("Insert into Rechte (ReNr, ReBez, ReCanArtikel, ReCanMitarbeiter, ReCanRechte, ReCanIntern, ReCanDaten, ReIsActive) values (" + textBox1.Text + ", '" + textBox2.Text + "' , " + checkBox1.Checked + ", " + checkBox2.Checked + ", " + checkBox3.Checked + ", " + checkBox4.Checked + ", " + checkBox5.Checked + ", " + checkBox6.Checked + " )", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Rechte rechte = new Rechte(AM);
            rechte.Show();
            Hide();
        }

        private void Rechtehinzufügen_Load(object sender, EventArgs e)
        {
            cmd = new OleDbCommand("SELECT count(ReNr) FROM  Rechte", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            int Anzahl = dr.GetInt32(0);
            con.Close();

            if (Anzahl > 0)
            {
                cmd = new OleDbCommand("SELECT Max(ReNr) FROM Rechte", con);
                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox1.Text = Convert.ToString(dr.GetInt32(0) + 1);
                con.Close();
            }
            else
            {
                textBox1.Text = "1";
            }
        }
    }
}
