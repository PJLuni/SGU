﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Artikelverwaltung : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        DataSet ds = new DataSet();
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;

        List<string> AngemeldeterMitarbeiter;
        string Mitarbeiter;

        public Artikelverwaltung(List<string> AM, string Mitarbeiter)
        {
            this.Mitarbeiter = Mitarbeiter;

            this.AngemeldeterMitarbeiter = AM;
            InitializeComponent();
        }
        //Befühlen des Datagridview 
        private void Artikelverwaltung_Load(object sender, EventArgs e)
        {
            try
            {
                OleDbDataAdapter Name = new OleDbDataAdapter("Select * from Artikel ", con);

                ds.Clear();
                Name.Fill(ds, "Artikelfilter");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Artikelfilter";

            }
            catch { MessageBox.Show("Fehler beim Befühlen des ArtikeldataGridViews"); }
            //Sortieren
            this.dataGridView1.Sort(this.dataGridView1.Columns["ArtNr"], ListSortDirection.Ascending);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hauptmenü hauptmenü = new Hauptmenü(AngemeldeterMitarbeiter);
            hauptmenü.Show();
            this.Hide();
        }

        // sicherstellen ob Rechteactive true ist. Dann Zu Artikelhinzufügen
        private void button1_Click(object sender, EventArgs e)
        {
            
            cmd = new OleDbCommand("SELECT MReNr FROM Mitarbeiter where MBenutzername ='" + Mitarbeiter + "'", con);

            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            int AnmelderMit = dr.GetInt32(0);
            con.Close();

            cmd = new OleDbCommand("SELECT ReCanDaten FROM Rechte where ReNr =" + AnmelderMit + "", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            bool AActive = dr.GetBoolean(0);
            con.Close();

            if (AActive == true)
            {
               Artikelhinzufügen artikelhinzufügen = new Artikelhinzufügen(AngemeldeterMitarbeiter,Mitarbeiter);
            artikelhinzufügen.Show();
            this.Hide();
            }
            else { MessageBox.Show("Fehler. Sie besietzen nich die Rechte dafür"); }

            button1.Enabled = true;
            
        }
        // Aktualisieren des Datagridviews im Hauptmenü und Artikelverwaltung
        private void button3_Click(object sender, EventArgs e)
        {
            

            Hauptmenü hauptmenü = new Hauptmenü(AngemeldeterMitarbeiter);
            hauptmenü.Show();
            hauptmenü.Close();

            Artikelverwaltung artikelverwaltung = new Artikelverwaltung(AngemeldeterMitarbeiter,Mitarbeiter);
            artikelverwaltung.Show();
            artikelverwaltung.Close();

            Artikelverwaltung artikelverwaltung2 = new Artikelverwaltung(AngemeldeterMitarbeiter,Mitarbeiter);
            artikelverwaltung2.Show();

            Hide();
        }
        //sicherstellen ob Rechteactive true ist. Dann Zu Artikellöschen
        private void button4_Click(object sender, EventArgs e)
        {

            cmd = new OleDbCommand("SELECT MReNr FROM Mitarbeiter where MBenutzername ='" + Mitarbeiter + "'", con);

            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            int AnmelderMit = dr.GetInt32(0);
            con.Close();

            cmd = new OleDbCommand("SELECT ReCanDaten FROM Rechte where ReNr =" + AnmelderMit + "", con);

            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            bool Active = dr.GetBoolean(0);
            con.Close();

            if (Active == true)
            {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["ArtNr"].Value.ToString();
           
            OleDbDataAdapter Name = new OleDbDataAdapter("delete * from Artikel where ArtNr = " + Ausgewähltezelle + "", con);

            ds.Clear();
            Name.Fill(ds, "L_Artikelfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "L_Artikelfilter";

            MessageBox.Show("Gelöscht. Gehen sie jz auf Aktualisieren!");

            }
            else { MessageBox.Show("Fehler"); }

            button4.Enabled = true;
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["ArtNr"].Value.ToString();
          
           OleDbDataAdapter Name = new OleDbDataAdapter("update Artikel set ArtBez ='" + dataGridView1.CurrentRow.Cells["ArtBez"].Value.ToString() + "' , ArtLagerPreis = '" + dataGridView1.CurrentRow.Cells["ArtLagerPreis"].Value.ToString() + "' , ArtEinkaufsPreis = '" + dataGridView1.CurrentRow.Cells["ArtEinkaufsPreis"].Value.ToString() + "' , ArtMeldebestand = '" + dataGridView1.CurrentRow.Cells["ArtMeldebestand"].Value.ToString() + "' , ArtAktuellerbestand = '" + dataGridView1.CurrentRow.Cells["ArtAktuellerbestand"].Value.ToString() + "' , ArtEhNr = '" + dataGridView1.CurrentRow.Cells["ArtEhNr"].Value.ToString() + "' , ArtLaNr = '" + dataGridView1.CurrentRow.Cells["ArtLaNr"].Value.ToString() + "', ArtIsActive = " + dataGridView1.CurrentRow.Cells["ArtIsActive"].Value.ToString()+ " where ArtNr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);

            ds.Clear();
            Name.Fill(ds, "U_Artikelfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "U_Artikelfilter";

            MessageBox.Show("Geändert. Gehen sie jz auf Aktualisieren!");

        }

       
    }
}
