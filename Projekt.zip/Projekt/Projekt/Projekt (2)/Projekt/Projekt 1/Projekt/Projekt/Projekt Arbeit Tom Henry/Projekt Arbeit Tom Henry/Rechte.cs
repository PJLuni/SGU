﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Rechte : Form
    {

        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        DataSet ds = new DataSet();
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        List<string> AM;

        public Rechte(List<string> AM)
        {
            this.AM = AM;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hauptmenü hauptmenü = new Hauptmenü(AM);
            hauptmenü.Show();
            Hide();
        }

        private void Rechte_Load(object sender, EventArgs e)
        {
            OleDbDataAdapter Name = new OleDbDataAdapter("SELECT * FROM Rechte ", con);


            ds.Clear();
            Name.Fill(ds, "Rechtefilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Rechtefilter";
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Rechtehinzufügen rechtehinzufügen = new Rechtehinzufügen(AM);
            rechtehinzufügen.Show();
            Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Rechte rechte = new Rechte(AM);
            rechte.Show();
            rechte.Close();

            Rechte rechte2 = new Rechte(AM);
            rechte2.Show();
            Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string s9 = dataGridView1.CurrentRow.Cells["ReNr"].Value.ToString();

            OleDbDataAdapter Name = new OleDbDataAdapter("delete * from Rechte where ReNr = " + s9 + "", con);
            ds.Clear();
            Name.Fill(ds, "Rechtefilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Rechtefilter";

            MessageBox.Show("Gelöscht. Gehen sie jz auf Aktualisieren!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            string s9 = dataGridView1.CurrentRow.Cells["ReNr"].Value.ToString();
           


           cmd = new OleDbCommand("update Rechte set ReBez ='" + dataGridView1.CurrentRow.Cells["ReBez"].Value.ToString() + "', ReCanArtikel = " + dataGridView1.CurrentRow.Cells["ReCanArtikel"].Value.ToString() + ", ReCanMitarbeiter = " + dataGridView1.CurrentRow.Cells["ReCanMitarbeiter"].Value.ToString() + ", ReCanRechte = " + dataGridView1.CurrentRow.Cells["ReCanRechte"].Value.ToString() + ", ReCanIntern = " + dataGridView1.CurrentRow.Cells["ReCanIntern"].Value.ToString() + ", ReCanDaten = " + dataGridView1.CurrentRow.Cells["ReCanDaten"].Value.ToString() + ", ReIsActive = " + dataGridView1.CurrentRow.Cells["ReIsActive"].Value.ToString() + " where ReNr =" + Convert.ToInt64(s9) + "", con);

             con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            cmd = new OleDbCommand("Select ReIsActive from Rechte where ReNr = " + Convert.ToInt64(s9) + "", con);

            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            bool AnmelderMit = dr.GetBoolean(0);
            con.Close();

            if (AnmelderMit == false)
            {
                string s91 = dataGridView1.CurrentRow.Cells["ReNr"].Value.ToString();
                cmd = new OleDbCommand("update Rechte set ReBez = '' , ReCanArtikel = false , ReCanMitarbeiter = false , ReCanRechte = false , ReCanIntern = false , ReCanDaten = false  where ReNr =" + Convert.ToInt64(s91) + "", con);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }

        }


    
    }
}

    

