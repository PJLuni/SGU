﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Artikelhinzufügen : Form
    {
        // Verbindung zur Datenbank
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        OleDbDataReader dr = null;    
        OleDbCommand cmd = null;

        string Mitarbeiter;
        List<string> AngemeldeterMitarbeiter;

        public Artikelhinzufügen(List<string> AngemeldeterMitarbeiter, string Mitarbeiter)
        {
            this.Mitarbeiter = Mitarbeiter;
            this.AngemeldeterMitarbeiter = AngemeldeterMitarbeiter;
            InitializeComponent();
        }
        // Beim speichern eines neuen Artikels geht der Anwender zurück
        private void button1_Click(object sender, EventArgs e)
        {   
             Artikelverwaltung artikelverwaltung = new Artikelverwaltung(AngemeldeterMitarbeiter,Mitarbeiter);
            artikelverwaltung.Show();
            
            Hide();
             
            con.Open();
           
            cmd = new OleDbCommand("Insert into Artikel (ArtNr, ArtBez, ArtLagerPreis, ArtEinkaufsPreis, ArtMeldebestand, ArtAktuellerbestand, ArtEhNr, ArtLaNr, ArtIsActive) values ('" + textBox1.Text + "', '" + textBox2.Text + "', '" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "', '" + textBox6.Text + "', '" + listBox1.SelectedItem + "','" + listBox2.SelectedItem + "'," + checkBox1.Checked +")", con);
            cmd.ExecuteNonQuery();
            con.Close();      
        }

        //Normaler Zurück Button ohne speichern
        private void button2_Click(object sender, EventArgs e)
        {
            Artikelverwaltung artikelverwaltung = new Artikelverwaltung(AngemeldeterMitarbeiter,Mitarbeiter);
            artikelverwaltung.Show();
            Hide();
        }
        //Befühlen der Listboxen und hochzählen der ArtNr
        private void Artikelhinzufügen_Load(object sender, EventArgs e)
        {
            con.Open();
            cmd = new OleDbCommand("select * from Einheit", con);

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                listBox1.Items.Add(dr.GetInt32(0));
            }
            con.Close();

            con.Open();
            cmd = new OleDbCommand("select * from Lager", con);

            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                listBox2.Items.Add(dr.GetInt32(0));
            }


            con.Close();

            cmd = new OleDbCommand("SELECT count(ArtNr) FROM Artikel", con);

            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();

            int Anzahl = dr.GetInt32(0);
            con.Close();

            if (Anzahl > 0)
            {
                cmd = new OleDbCommand("SELECT Max(ArtNr) FROM Artikel", con);

                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox1.Text = Convert.ToString(dr.GetInt32(0) + 1);

                con.Close();
            }
            else
            {
                textBox1.Text = "1";
            }
        }
        //Befühlen der Listboxen
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label10.Text = "";
            con.Open();

            int vergleich = Convert.ToInt32(listBox1.SelectedItem.ToString());
            cmd = new OleDbCommand("select EhBez from Einheit where EhNr =" + vergleich, con);

            dr = cmd.ExecuteReader();
            dr.Read();

            label10.Text = dr.GetString(0);
            con.Close();
            label10.Visible = true;
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            label12.Text = "";
            con.Open();

            int vergleich = Convert.ToInt32(listBox2.SelectedItem.ToString());
            cmd = new OleDbCommand("select LaBez from Lager where LaNr =" + vergleich, con);

            dr = cmd.ExecuteReader();
            dr.Read();

            label12.Text = dr.GetString(0);
            con.Close();
            label12.Visible = true;
        }
    }
}
