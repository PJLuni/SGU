﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    
    public partial class Materialentnahmeschein : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
    DataSet ds = new DataSet();
        DataSet ds1 = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbDataReader dr = null;

        OleDbCommand cmd = null;
        List<string> AM;
        public Materialentnahmeschein(List<string> AM)
        {
            this.AM = AM;
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hauptmenü hauptmenü = new Hauptmenü(AM);
            hauptmenü.Show();
            Hide();
        }

        private void Materialentnahmeschein_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbDataAdapter Name = new OleDbDataAdapter("Select * from Mats ", con);

                
                ds1.Clear();
                Name.Fill(ds1, "Matsfilter");
                dataGridView1.DataSource = ds1;
                dataGridView1.DataMember = "Matsfilter";
                con.Close();

            }
            catch { MessageBox.Show("Fehler");
            }
            try
            {
                con.Open();
                OleDbDataAdapter Name2= new OleDbDataAdapter("Select * from Mats2 ", con);


                ds.Clear();
                Name2.Fill(ds, "Mats2filter");
                dataGridView2.DataSource = ds;
                dataGridView2.DataMember = "Mats2filter";
                con.Close();

            }
            catch { MessageBox.Show("Fehler2"); }

            con.Open();
            cmd = new OleDbCommand("select * from Mitarbeiter", con);

            dr = cmd.ExecuteReader();
           
            while (dr.Read())
            {

                listBox1.Items.Add(dr.GetInt32(0));
            }


            con.Close();

            con.Open();
            cmd = new OleDbCommand("select * from Mitarbeiter", con);

            dr = cmd.ExecuteReader();

            
            while (dr.Read())
            {

                listBox2.Items.Add(dr.GetInt32(0));
            }


            con.Close();

            con.Open();
            cmd = new OleDbCommand("select * from Kostenstelle", con);

            dr = cmd.ExecuteReader();
            

            while (dr.Read())
            {

                listBox3.Items.Add(dr.GetInt32(0));
            }
            

            con.Close();

            con.Open();
            cmd = new OleDbCommand("select * from Mats", con);

            dr = cmd.ExecuteReader();

            
            while (dr.Read())
            {

                listBox4.Items.Add(dr.GetInt32(0));
            }


            con.Close();

            con.Open();
            cmd = new OleDbCommand("select * from Artikel", con);

            dr = cmd.ExecuteReader();



            while (dr.Read())
            {

                listBox5.Items.Add(dr.GetInt32(0));
            }


            con.Close();

            cmd = new OleDbCommand("SELECT count(MatsNr) FROM Mats", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            int Anzahl = dr.GetInt32(0);
            con.Close();

            if (Anzahl > 0)
            {
                cmd = new OleDbCommand("SELECT Max(MatsNr) FROM Mats", con);
                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox1.Text = Convert.ToString(dr.GetInt32(0) + 1);
                con.Close();
            }
            else
            {
                textBox1.Text = "1";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Materialentnahmeschein materialentnahmeschein = new Materialentnahmeschein(AM);
            materialentnahmeschein.Show();
            materialentnahmeschein.Close();

            Materialentnahmeschein materialentnahmeschein1 = new Materialentnahmeschein(AM);
            materialentnahmeschein1.Show();

            Hide();
        }

       
        private void button8_Click(object sender, EventArgs e)
        {
          

            con.Open();

            cmd = new OleDbCommand("Insert into Mats2 (Mats2MatsNr, Mats2ArtNr, Mats2Menge, Mats2Preis, MatsGesamtpreis) values ('" + listBox4.SelectedItem + "', '" + listBox5.SelectedItem + "', '" + textBox3.Text + "', " + textBox4.Text + ", " + textBox5.Text + ")", con);
            cmd.ExecuteNonQuery();
            con.Close();
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string s9 = dataGridView1.CurrentRow.Cells["MatsNr"].Value.ToString();
            cmd= new OleDbCommand("delete * from Mats where MatsNr = " + s9 + "", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();


            MessageBox.Show("Gelöscht. Gehen sie jz auf Aktualisieren!");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string s9 = dataGridView1.CurrentRow.Cells["MatsNr"].Value.ToString();
            
            
            cmd= new OleDbCommand("update Mats set MatsDatum ='" + dataGridView1.CurrentRow.Cells["MatsDatum"].Value.ToString() + "' , MatsBemerkung = '" + dataGridView1.CurrentRow.Cells["MatsBemerkung"].Value.ToString() + "' , MatsMNr = '" + dataGridView1.CurrentRow.Cells["MatsMNr"].Value.ToString() + "' , MatsSachMNr = '" + dataGridView1.CurrentRow.Cells["MatsSachMNr"].Value.ToString() + "' , MatsKsNr = '" + dataGridView1.CurrentRow.Cells["MatsKsNr"].Value.ToString() + "' , MatsIsActive = " + dataGridView1.CurrentRow.Cells["MatsIsActive"].Value.ToString() + " where MatsNr = " + System.Convert.ToInt64(s9) + "", con);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        
        private void button4_Click(object sender, EventArgs e)
        {

            string s9 = dataGridView2.CurrentRow.Cells["Mats2MatsNr"].Value.ToString();

           cmd = new OleDbCommand("delete * from Mats2 where Mats2MatsNr = " + s9 + "", con);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Gelöscht. Gehen sie jz auf Aktualisieren!");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string s9 = dataGridView1.CurrentRow.Cells["Mats2MatsNr"].Value.ToString();

            
            cmd = new OleDbCommand("update Mats2 set Mats2Menge ='" + dataGridView1.CurrentRow.Cells["Mats2Menge"].Value.ToString() + "' , Mats2Preis = '" + dataGridView1.CurrentRow.Cells["Mats2Preis"].Value.ToString() + " where MatsNr = " + System.Convert.ToInt64(s9) + "", con);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();

            cmd = new OleDbCommand("Insert into Mats (MatsNr, MatsDatum, MatsBemerkung, MatsMNr, MatsSachMNr, MatsKsNr, MatsIsActive) values ('" + textBox1.Text + "', '" + dateTimePicker1.Value + "', '" + textBox2.Text + "','" + listBox1.SelectedItem + "','" + listBox2.SelectedItem + "', '" + listBox3.SelectedItem + "', " + checkBox1.Checked + ")", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            con.Open();
            OleDbDataAdapter Name2 = new OleDbDataAdapter("Select * from Mats2 ", con);
            

            ds.Clear();
            Name2.Fill(ds, "Mats2filter");
            dataGridView2.DataSource = ds;
            dataGridView2.DataMember = "Mats2filter";
            int gesamtpreis = 0;
            int Menge = Convert.ToInt32(textBox3.Text);
            int Preis = Convert.ToInt32(textBox4.Text);

            gesamtpreis = Menge * Preis;
            con.Close();

            textBox5.Text = Convert.ToString(gesamtpreis);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            
            cmd = new OleDbCommand("Select ArtAktuellerbestand from Artikel where ArtNr = " + listBox5.SelectedItem + "", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            int AMenge = dr.GetInt32(0);
           
            con.Close();
          
            cmd = new OleDbCommand("Select Mats2Menge from Mats2 where Mats2MatsNr = " + listBox4.SelectedItem + "", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();

            int Menge = dr.GetInt32(0);
           
            
            con.Close();
               
            int MengenBerechnung = 0;
            MengenBerechnung = AMenge - Menge;


            string s9 = Convert.ToString(listBox5.SelectedItem);



            cmd = new OleDbCommand("update Artikel set  ArtAktuellerbestand = " + MengenBerechnung + " where ArtNr = " + System.Convert.ToInt64(s9) + "", con);

            con.Open();
            cmd.ExecuteReader();           

            con.Close();

        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            if(Convert.ToInt32(label14.Text)>= Convert.ToInt32(textBox3.Text)) {


                con.Open();

                cmd = new OleDbCommand("Insert into Mats2 (Mats2MatsNr, Mats2ArtNr, Mats2Menge, Mats2Preis, MatsGesamtpreis) values ('" + listBox4.SelectedItem + "', '" + listBox5.SelectedItem + "', '" + textBox3.Text + "', " + textBox4.Text + ", " + textBox5.Text + ")", con);
                cmd.ExecuteNonQuery();
                con.Close();

                cmd = new OleDbCommand("Select ArtAktuellerbestand from Artikel where ArtNr = " + listBox5.SelectedItem + "", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            int AMenge = dr.GetInt32(0);

            con.Close();

            int Menge = Convert.ToInt32(textBox3.Text);


            con.Close();

            int MengenBerechnung = 0;
            MengenBerechnung = AMenge - Menge;
            
            
                string s9 = Convert.ToString(listBox5.SelectedItem);
                
                cmd = new OleDbCommand("update Artikel set  ArtAktuellerbestand = " + MengenBerechnung + " where ArtNr = " + System.Convert.ToInt64(s9) + "", con);

                con.Open();
                cmd.ExecuteReader();

                con.Close();
            }
           
            else { MessageBox.Show("Bitte geben sie ein Richtigen Mengenwert an");
            }
        }

        private void listBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            label14.Text = "";
            con.Open();

            int vergleich = Convert.ToInt32(listBox5.SelectedItem.ToString());
            cmd = new OleDbCommand("select ArtAktuellerbestand from Artikel where ArtNr =" + vergleich, con);

            dr = cmd.ExecuteReader();
            dr.Read();

            label14.Text = Convert.ToString(dr.GetInt32(0));
            con.Close();
            label14.Visible = true;
        }

     
    }
}
