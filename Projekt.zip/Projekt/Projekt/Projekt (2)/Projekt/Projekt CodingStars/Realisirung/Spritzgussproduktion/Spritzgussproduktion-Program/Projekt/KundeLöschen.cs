﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt
{
    public partial class KundeLöschen : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Datenbank.accdb");
        DataSet ds = new DataSet();
        OleDbDataReader dr = null;
        OleDbCommand cmd = null;

        string Benutzer;
        public KundeLöschen(string Benutzer)
        {
            this.Benutzer = Benutzer;
            InitializeComponent();
        }
        public void Reset()
        {
            Formsswitch.kundelöschen(Benutzer);
            this.Dispose(false);
        }
       

        

            public void toogle()
        {
            if (alleanzeigen_button.Text == "Alle Kunden Anzeigen")
            {
                kunden_listBox.Items.Clear();
                con.Open();
                cmd = new OleDbCommand("select Bezeichnung from Kunde", con);

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    kunden_listBox.Items.Add(dr.GetString(0));
                }

                con.Close();

               

                alleanzeigen_button.Text = "Nur Kunden Anzeigen die Aktiv sind";

            }
            else if (alleanzeigen_button.Text == "Nur Kunden Anzeigen die Aktiv sind")
            {
                kunden_listBox.Items.Clear();
                con.Open();
                cmd = new OleDbCommand("select Bezeichnung from Kunde Where IstAktiv = True", con);

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    kunden_listBox.Items.Add(dr.GetString(0));
                }

                con.Close();

               

                alleanzeigen_button.Text = "Alle Kunden Anzeigen";
            }
        }
        private void löschen_button_Click(object sender, EventArgs e)
        {
            gefundendeitems_label.Visible = false;
            try
            {
                
                DialogResult benutzerentscheidung = MessageBox.Show("Wollen Sie diesen Kunden wirklich entgültig Löschen?", "Abfrage", MessageBoxButtons.YesNo);

                if (benutzerentscheidung == DialogResult.Yes)
                {
                    string vergleich = kunden_listBox.SelectedItem.ToString();
                    cmd = new OleDbCommand("delete * from Kunde where Bezeichnung = '" + vergleich + "'", con);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    

                    DialogResult weiterlöschen = MessageBox.Show("Wollen Sie einen weiteren Kunden Löschen?", "Abfrage", MessageBoxButtons.YesNo);
                    if (weiterlöschen == DialogResult.Yes)
                    {
                       
                        toogle();
                        kunden_listBox.SelectedIndex = 0;

                    }
                    else
                    {
                            Reset();
                    }
                }
                else
                {
                    Reset();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Fehler. Versuchen sie einen Kunden auszuwählen und dann auf löschen zu gehen"); 
                Reset();
            }
        }

        private void kunden_listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
           
           
                
        }

        private void KundeLöschen_Load(object sender, EventArgs e)
        {
            con.Open();
            cmd = new OleDbCommand("select Bezeichnung from Kunde Where IstAktiv = true", con);

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                kunden_listBox.Items.Add(dr.GetString(0));
            }


            con.Close();



           
        }
        private void hauptmenü_button_Click(object sender, EventArgs e)
        {

            Formsswitch.hauptmenü(Benutzer);
            Hide();

        }

        private void kundeanzeigen_button_Click(object sender, EventArgs e)
        {
            Formsswitch.kundeanzeigen(Benutzer);
            Hide();
        }

        private void suchen_button_Click(object sender, EventArgs e)
        {
            
            
            if (suchen_textBox.TextLength != 0)
            {
                kunden_listBox.SelectedItems.Clear();
               
                for (int i = kunden_listBox.Items.Count - 1; i >= 0; i--)
                {

                    if (kunden_listBox.Items[i].ToString().ToLower().Contains(suchen_textBox.Text.ToLower()))
                    {

                        kunden_listBox.SetSelected(i, true);
                    }

                }
                gefundendeitems_label.Text = kunden_listBox.SelectedItems.Count.ToString() + " '" + suchen_textBox.Text + "' " + "Gefunden";
            }
            else
            {
                MessageBox.Show("Geben sie bitte einen Kunden ein");
            }



        }

        private void zurück_button_Click(object sender, EventArgs e)
        {
            Reset();
        }
        
        private void alleanzeigen_button_Click(object sender, EventArgs e)
        {
           
            toogle();
            
        }

        private void kunden_listBox_Click(object sender, EventArgs e)
        {
           
            
        }
    }
}
