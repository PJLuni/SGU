﻿namespace Projekt
{
    partial class KundeLöschen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KundeLöschen));
            this.label1 = new System.Windows.Forms.Label();
            this.kunde_label = new System.Windows.Forms.Label();
            this.kunden_listBox = new System.Windows.Forms.ListBox();
            this.suchen_textBox = new System.Windows.Forms.TextBox();
            this.suchen_button = new System.Windows.Forms.Button();
            this.gefundendeitems_label = new System.Windows.Forms.Label();
            this.alleanzeigen_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(229, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kunde-Löschen";
            // 
            // kunde_label
            // 
            this.kunde_label.AutoSize = true;
            this.kunde_label.Location = new System.Drawing.Point(269, 170);
            this.kunde_label.Name = "kunde_label";
            this.kunde_label.Size = new System.Drawing.Size(38, 13);
            this.kunde_label.TabIndex = 3;
            this.kunde_label.Text = "Kunde";
            // 
            // kunden_listBox
            // 
            this.kunden_listBox.FormattingEnabled = true;
            this.kunden_listBox.Location = new System.Drawing.Point(198, 207);
            this.kunden_listBox.Name = "kunden_listBox";
            this.kunden_listBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.kunden_listBox.Size = new System.Drawing.Size(180, 147);
            this.kunden_listBox.TabIndex = 4;
            this.kunden_listBox.Click += new System.EventHandler(this.kunden_listBox_Click);
            this.kunden_listBox.SelectedIndexChanged += new System.EventHandler(this.kunden_listBox_SelectedIndexChanged);
            // 
            // suchen_textBox
            // 
            this.suchen_textBox.Location = new System.Drawing.Point(197, 356);
            this.suchen_textBox.Name = "suchen_textBox";
            this.suchen_textBox.Size = new System.Drawing.Size(86, 20);
            this.suchen_textBox.TabIndex = 8;
            // 
            // suchen_button
            // 
            this.suchen_button.Location = new System.Drawing.Point(317, 356);
            this.suchen_button.Name = "suchen_button";
            this.suchen_button.Size = new System.Drawing.Size(61, 23);
            this.suchen_button.TabIndex = 9;
            this.suchen_button.Text = "Suchen";
            this.suchen_button.UseVisualStyleBackColor = true;
            // 
            // gefundendeitems_label
            // 
            this.gefundendeitems_label.AutoSize = true;
            this.gefundendeitems_label.Location = new System.Drawing.Point(195, 396);
            this.gefundendeitems_label.Name = "gefundendeitems_label";
            this.gefundendeitems_label.Size = new System.Drawing.Size(0, 13);
            this.gefundendeitems_label.TabIndex = 10;
            // 
            // alleanzeigen_button
            // 
            this.alleanzeigen_button.Location = new System.Drawing.Point(188, 382);
            this.alleanzeigen_button.Name = "alleanzeigen_button";
            this.alleanzeigen_button.Size = new System.Drawing.Size(204, 24);
            this.alleanzeigen_button.TabIndex = 13;
            this.alleanzeigen_button.Text = "Alle Kunden Anzeigen";
            this.alleanzeigen_button.UseVisualStyleBackColor = true;
            this.alleanzeigen_button.Click += new System.EventHandler(this.alleanzeigen_button_Click);
            // 
            // KundeLöschen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(529, 473);
            this.Controls.Add(this.alleanzeigen_button);
            this.Controls.Add(this.gefundendeitems_label);
            this.Controls.Add(this.suchen_button);
            this.Controls.Add(this.suchen_textBox);
            this.Controls.Add(this.kunden_listBox);
            this.Controls.Add(this.kunde_label);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "KundeLöschen";
            this.Text = "KundeLöschen";
            this.Load += new System.EventHandler(this.KundeLöschen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label kunde_label;
        private System.Windows.Forms.ListBox kunden_listBox;
        private System.Windows.Forms.TextBox suchen_textBox;
        private System.Windows.Forms.Button suchen_button;
        private System.Windows.Forms.Label gefundendeitems_label;
        private System.Windows.Forms.Button alleanzeigen_button;
    }
}