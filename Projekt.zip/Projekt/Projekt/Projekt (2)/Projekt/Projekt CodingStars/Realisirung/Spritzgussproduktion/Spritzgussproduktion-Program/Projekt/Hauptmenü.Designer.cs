﻿namespace Projekt
{
    partial class Hauptmenü
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Hauptmenü));
            this.überschrift_label = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.aufträge_datagridview = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aufträge_datagridview)).BeginInit();
            this.SuspendLayout();
            // 
            // überschrift_label
            // 
            this.überschrift_label.AutoSize = true;
            this.überschrift_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.überschrift_label.Location = new System.Drawing.Point(212, 71);
            this.überschrift_label.Name = "überschrift_label";
            this.überschrift_label.Size = new System.Drawing.Size(183, 37);
            this.überschrift_label.TabIndex = 0;
            this.überschrift_label.Text = "Hauptmenü";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Silver;
            this.panel6.Controls.Add(this.aufträge_datagridview);
            this.panel6.Controls.Add(this.label1);
            this.panel6.Location = new System.Drawing.Point(12, 183);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(537, 346);
            this.panel6.TabIndex = 14;
            // 
            // aufträge_datagridview
            // 
            this.aufträge_datagridview.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.aufträge_datagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.aufträge_datagridview.Location = new System.Drawing.Point(24, 76);
            this.aufträge_datagridview.Name = "aufträge_datagridview";
            this.aufträge_datagridview.Size = new System.Drawing.Size(489, 229);
            this.aufträge_datagridview.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(202, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(259, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "Zufertigstellende Aufträge";
            // 
            // Hauptmenü
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(584, 613);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.überschrift_label);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Hauptmenü";
            this.Text = "Hauptmenü";
            this.Load += new System.EventHandler(this.Hauptmenü_Load);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aufträge_datagridview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label überschrift_label;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataGridView aufträge_datagridview;
        private System.Windows.Forms.Label label1;
    }
}