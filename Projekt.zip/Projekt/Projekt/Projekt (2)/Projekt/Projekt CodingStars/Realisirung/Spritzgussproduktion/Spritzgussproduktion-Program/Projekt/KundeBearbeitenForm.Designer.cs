﻿namespace Projekt
{
    partial class KundeBearbeitenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kundebearbeiten_label = new System.Windows.Forms.Label();
            this.bearbeitungs_panel = new System.Windows.Forms.Panel();
            this.zurück_button = new System.Windows.Forms.Button();
            this.IstAktiv_checkBox = new System.Windows.Forms.CheckBox();
            this.IstAktiv_label = new System.Windows.Forms.Label();
            this.Anmerkung_label = new System.Windows.Forms.Label();
            this.Anmerkung_textBox = new System.Windows.Forms.TextBox();
            this.Land_label = new System.Windows.Forms.Label();
            this.Land_textBox = new System.Windows.Forms.TextBox();
            this.Straße_label = new System.Windows.Forms.Label();
            this.Straße_textBox = new System.Windows.Forms.TextBox();
            this.Ort_label = new System.Windows.Forms.Label();
            this.Ort_textBox = new System.Windows.Forms.TextBox();
            this.PLZ_label = new System.Windows.Forms.Label();
            this.PLZ_textBox = new System.Windows.Forms.TextBox();
            this.Fax_label = new System.Windows.Forms.Label();
            this.Fax_textBox = new System.Windows.Forms.TextBox();
            this.Email_label = new System.Windows.Forms.Label();
            this.Email_textBox = new System.Windows.Forms.TextBox();
            this.Telefon_label = new System.Windows.Forms.Label();
            this.Telefon_textBox = new System.Windows.Forms.TextBox();
            this.Bezeichnung_label = new System.Windows.Forms.Label();
            this.Nr_label = new System.Windows.Forms.Label();
            this.bezeichnung_textBox = new System.Windows.Forms.TextBox();
            this.Nr_textBox = new System.Windows.Forms.TextBox();
            this.speichern_button = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bearbeitungs_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kundebearbeiten_label
            // 
            this.kundebearbeiten_label.AutoSize = true;
            this.kundebearbeiten_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kundebearbeiten_label.Location = new System.Drawing.Point(310, 26);
            this.kundebearbeiten_label.Name = "kundebearbeiten_label";
            this.kundebearbeiten_label.Size = new System.Drawing.Size(185, 25);
            this.kundebearbeiten_label.TabIndex = 53;
            this.kundebearbeiten_label.Text = "Kunde-Bearbeiten";
            // 
            // bearbeitungs_panel
            // 
            this.bearbeitungs_panel.Controls.Add(this.checkBox1);
            this.bearbeitungs_panel.Controls.Add(this.label1);
            this.bearbeitungs_panel.Controls.Add(this.speichern_button);
            this.bearbeitungs_panel.Controls.Add(this.zurück_button);
            this.bearbeitungs_panel.Controls.Add(this.IstAktiv_checkBox);
            this.bearbeitungs_panel.Controls.Add(this.IstAktiv_label);
            this.bearbeitungs_panel.Controls.Add(this.Anmerkung_label);
            this.bearbeitungs_panel.Controls.Add(this.Anmerkung_textBox);
            this.bearbeitungs_panel.Controls.Add(this.Land_label);
            this.bearbeitungs_panel.Controls.Add(this.Land_textBox);
            this.bearbeitungs_panel.Controls.Add(this.Straße_label);
            this.bearbeitungs_panel.Controls.Add(this.Straße_textBox);
            this.bearbeitungs_panel.Controls.Add(this.Ort_label);
            this.bearbeitungs_panel.Controls.Add(this.Ort_textBox);
            this.bearbeitungs_panel.Controls.Add(this.PLZ_label);
            this.bearbeitungs_panel.Controls.Add(this.PLZ_textBox);
            this.bearbeitungs_panel.Controls.Add(this.Fax_label);
            this.bearbeitungs_panel.Controls.Add(this.Fax_textBox);
            this.bearbeitungs_panel.Controls.Add(this.Email_label);
            this.bearbeitungs_panel.Controls.Add(this.Email_textBox);
            this.bearbeitungs_panel.Controls.Add(this.Telefon_label);
            this.bearbeitungs_panel.Controls.Add(this.Telefon_textBox);
            this.bearbeitungs_panel.Controls.Add(this.Bezeichnung_label);
            this.bearbeitungs_panel.Controls.Add(this.Nr_label);
            this.bearbeitungs_panel.Controls.Add(this.bezeichnung_textBox);
            this.bearbeitungs_panel.Controls.Add(this.Nr_textBox);
            this.bearbeitungs_panel.Location = new System.Drawing.Point(33, 77);
            this.bearbeitungs_panel.Name = "bearbeitungs_panel";
            this.bearbeitungs_panel.Size = new System.Drawing.Size(735, 348);
            this.bearbeitungs_panel.TabIndex = 52;
            this.bearbeitungs_panel.Visible = false;
            // 
            // zurück_button
            // 
            this.zurück_button.Location = new System.Drawing.Point(657, 325);
            this.zurück_button.Name = "zurück_button";
            this.zurück_button.Size = new System.Drawing.Size(75, 20);
            this.zurück_button.TabIndex = 20;
            this.zurück_button.Text = "Zurück";
            this.zurück_button.UseVisualStyleBackColor = true;
            this.zurück_button.Visible = false;
            // 
            // IstAktiv_checkBox
            // 
            this.IstAktiv_checkBox.AutoSize = true;
            this.IstAktiv_checkBox.Checked = true;
            this.IstAktiv_checkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.IstAktiv_checkBox.Location = new System.Drawing.Point(565, 307);
            this.IstAktiv_checkBox.Name = "IstAktiv_checkBox";
            this.IstAktiv_checkBox.Size = new System.Drawing.Size(15, 14);
            this.IstAktiv_checkBox.TabIndex = 48;
            this.IstAktiv_checkBox.UseVisualStyleBackColor = true;
            // 
            // IstAktiv_label
            // 
            this.IstAktiv_label.AutoSize = true;
            this.IstAktiv_label.Location = new System.Drawing.Point(504, 308);
            this.IstAktiv_label.Name = "IstAktiv_label";
            this.IstAktiv_label.Size = new System.Drawing.Size(42, 13);
            this.IstAktiv_label.TabIndex = 47;
            this.IstAktiv_label.Text = "IstAktiv";
            // 
            // Anmerkung_label
            // 
            this.Anmerkung_label.AutoSize = true;
            this.Anmerkung_label.Location = new System.Drawing.Point(485, 238);
            this.Anmerkung_label.Name = "Anmerkung_label";
            this.Anmerkung_label.Size = new System.Drawing.Size(61, 13);
            this.Anmerkung_label.TabIndex = 46;
            this.Anmerkung_label.Text = "Anmerkung";
            // 
            // Anmerkung_textBox
            // 
            this.Anmerkung_textBox.Location = new System.Drawing.Point(565, 235);
            this.Anmerkung_textBox.Multiline = true;
            this.Anmerkung_textBox.Name = "Anmerkung_textBox";
            this.Anmerkung_textBox.Size = new System.Drawing.Size(145, 66);
            this.Anmerkung_textBox.TabIndex = 45;
            // 
            // Land_label
            // 
            this.Land_label.AutoSize = true;
            this.Land_label.Location = new System.Drawing.Point(515, 193);
            this.Land_label.Name = "Land_label";
            this.Land_label.Size = new System.Drawing.Size(31, 13);
            this.Land_label.TabIndex = 44;
            this.Land_label.Text = "Land";
            // 
            // Land_textBox
            // 
            this.Land_textBox.Location = new System.Drawing.Point(565, 190);
            this.Land_textBox.Name = "Land_textBox";
            this.Land_textBox.Size = new System.Drawing.Size(100, 20);
            this.Land_textBox.TabIndex = 43;
            // 
            // Straße_label
            // 
            this.Straße_label.AutoSize = true;
            this.Straße_label.Location = new System.Drawing.Point(508, 142);
            this.Straße_label.Name = "Straße_label";
            this.Straße_label.Size = new System.Drawing.Size(38, 13);
            this.Straße_label.TabIndex = 42;
            this.Straße_label.Text = "Straße";
            // 
            // Straße_textBox
            // 
            this.Straße_textBox.Location = new System.Drawing.Point(565, 135);
            this.Straße_textBox.Name = "Straße_textBox";
            this.Straße_textBox.Size = new System.Drawing.Size(100, 20);
            this.Straße_textBox.TabIndex = 41;
            // 
            // Ort_label
            // 
            this.Ort_label.AutoSize = true;
            this.Ort_label.Location = new System.Drawing.Point(525, 92);
            this.Ort_label.Name = "Ort_label";
            this.Ort_label.Size = new System.Drawing.Size(21, 13);
            this.Ort_label.TabIndex = 40;
            this.Ort_label.Text = "Ort";
            // 
            // Ort_textBox
            // 
            this.Ort_textBox.Location = new System.Drawing.Point(565, 89);
            this.Ort_textBox.Name = "Ort_textBox";
            this.Ort_textBox.Size = new System.Drawing.Size(100, 20);
            this.Ort_textBox.TabIndex = 39;
            // 
            // PLZ_label
            // 
            this.PLZ_label.AutoSize = true;
            this.PLZ_label.Location = new System.Drawing.Point(519, 45);
            this.PLZ_label.Name = "PLZ_label";
            this.PLZ_label.Size = new System.Drawing.Size(27, 13);
            this.PLZ_label.TabIndex = 38;
            this.PLZ_label.Text = "PLZ";
            // 
            // PLZ_textBox
            // 
            this.PLZ_textBox.Location = new System.Drawing.Point(565, 42);
            this.PLZ_textBox.Name = "PLZ_textBox";
            this.PLZ_textBox.Size = new System.Drawing.Size(100, 20);
            this.PLZ_textBox.TabIndex = 37;
            // 
            // Fax_label
            // 
            this.Fax_label.AutoSize = true;
            this.Fax_label.Location = new System.Drawing.Point(62, 290);
            this.Fax_label.Name = "Fax_label";
            this.Fax_label.Size = new System.Drawing.Size(24, 13);
            this.Fax_label.TabIndex = 36;
            this.Fax_label.Text = "Fax";
            // 
            // Fax_textBox
            // 
            this.Fax_textBox.Location = new System.Drawing.Point(110, 283);
            this.Fax_textBox.Name = "Fax_textBox";
            this.Fax_textBox.Size = new System.Drawing.Size(100, 20);
            this.Fax_textBox.TabIndex = 35;
            // 
            // Email_label
            // 
            this.Email_label.AutoSize = true;
            this.Email_label.Location = new System.Drawing.Point(51, 223);
            this.Email_label.Name = "Email_label";
            this.Email_label.Size = new System.Drawing.Size(36, 13);
            this.Email_label.TabIndex = 34;
            this.Email_label.Text = "E-Mail";
            // 
            // Email_textBox
            // 
            this.Email_textBox.Location = new System.Drawing.Point(110, 223);
            this.Email_textBox.Name = "Email_textBox";
            this.Email_textBox.Size = new System.Drawing.Size(100, 20);
            this.Email_textBox.TabIndex = 33;
            // 
            // Telefon_label
            // 
            this.Telefon_label.AutoSize = true;
            this.Telefon_label.Location = new System.Drawing.Point(43, 166);
            this.Telefon_label.Name = "Telefon_label";
            this.Telefon_label.Size = new System.Drawing.Size(43, 13);
            this.Telefon_label.TabIndex = 32;
            this.Telefon_label.Text = "Telefon";
            // 
            // Telefon_textBox
            // 
            this.Telefon_textBox.Location = new System.Drawing.Point(110, 159);
            this.Telefon_textBox.Name = "Telefon_textBox";
            this.Telefon_textBox.Size = new System.Drawing.Size(100, 20);
            this.Telefon_textBox.TabIndex = 31;
            // 
            // Bezeichnung_label
            // 
            this.Bezeichnung_label.AutoSize = true;
            this.Bezeichnung_label.Location = new System.Drawing.Point(17, 104);
            this.Bezeichnung_label.Name = "Bezeichnung_label";
            this.Bezeichnung_label.Size = new System.Drawing.Size(69, 13);
            this.Bezeichnung_label.TabIndex = 30;
            this.Bezeichnung_label.Text = "Bezeichnung";
            // 
            // Nr_label
            // 
            this.Nr_label.AutoSize = true;
            this.Nr_label.Location = new System.Drawing.Point(68, 45);
            this.Nr_label.Name = "Nr_label";
            this.Nr_label.Size = new System.Drawing.Size(18, 13);
            this.Nr_label.TabIndex = 29;
            this.Nr_label.Text = "Nr";
            // 
            // bezeichnung_textBox
            // 
            this.bezeichnung_textBox.Location = new System.Drawing.Point(110, 101);
            this.bezeichnung_textBox.Name = "bezeichnung_textBox";
            this.bezeichnung_textBox.Size = new System.Drawing.Size(100, 20);
            this.bezeichnung_textBox.TabIndex = 28;
            // 
            // Nr_textBox
            // 
            this.Nr_textBox.Location = new System.Drawing.Point(110, 38);
            this.Nr_textBox.Name = "Nr_textBox";
            this.Nr_textBox.Size = new System.Drawing.Size(64, 20);
            this.Nr_textBox.TabIndex = 27;
            // 
            // speichern_button
            // 
            this.speichern_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.speichern_button.Location = new System.Drawing.Point(269, 307);
            this.speichern_button.Name = "speichern_button";
            this.speichern_button.Size = new System.Drawing.Size(152, 33);
            this.speichern_button.TabIndex = 53;
            this.speichern_button.Text = "Speichern";
            this.speichern_button.UseVisualStyleBackColor = true;
            this.speichern_button.Visible = false;
            this.speichern_button.Click += new System.EventHandler(this.speichern_button_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(565, 328);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 55;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(474, 329);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 54;
            this.label1.Text = "Extra Lieferort";
            // 
            // KundeBearbeitenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.kundebearbeiten_label);
            this.Controls.Add(this.bearbeitungs_panel);
            this.Name = "KundeBearbeitenForm";
            this.Text = "KundeBearbeitenForm";
            this.bearbeitungs_panel.ResumeLayout(false);
            this.bearbeitungs_panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label kundebearbeiten_label;
        private System.Windows.Forms.Panel bearbeitungs_panel;
        private System.Windows.Forms.Button zurück_button;
        private System.Windows.Forms.CheckBox IstAktiv_checkBox;
        private System.Windows.Forms.Label IstAktiv_label;
        private System.Windows.Forms.Label Anmerkung_label;
        private System.Windows.Forms.TextBox Anmerkung_textBox;
        private System.Windows.Forms.Label Land_label;
        private System.Windows.Forms.TextBox Land_textBox;
        private System.Windows.Forms.Label Straße_label;
        private System.Windows.Forms.TextBox Straße_textBox;
        private System.Windows.Forms.Label Ort_label;
        private System.Windows.Forms.TextBox Ort_textBox;
        private System.Windows.Forms.Label PLZ_label;
        private System.Windows.Forms.TextBox PLZ_textBox;
        private System.Windows.Forms.Label Fax_label;
        private System.Windows.Forms.TextBox Fax_textBox;
        private System.Windows.Forms.Label Email_label;
        private System.Windows.Forms.TextBox Email_textBox;
        private System.Windows.Forms.Label Telefon_label;
        private System.Windows.Forms.TextBox Telefon_textBox;
        private System.Windows.Forms.Label Bezeichnung_label;
        private System.Windows.Forms.Label Nr_label;
        private System.Windows.Forms.TextBox bezeichnung_textBox;
        private System.Windows.Forms.TextBox Nr_textBox;
        private System.Windows.Forms.Button speichern_button;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
    }
}