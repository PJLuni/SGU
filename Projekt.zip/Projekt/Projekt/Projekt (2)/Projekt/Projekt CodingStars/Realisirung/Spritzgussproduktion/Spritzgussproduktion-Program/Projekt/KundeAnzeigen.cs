﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt
{
    public partial class KundeAnzeigen : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Datenbank.accdb");
        DataSet ds = new DataSet();
       
        string Benutzer;
        public KundeAnzeigen(string Benutzer)
        {
            this.Benutzer = Benutzer;
            InitializeComponent();
        }

        private void hauptmenü_button_Click(object sender, EventArgs e)
        {
            Formsswitch.hauptmenü(Benutzer);
            Hide();

        }

        private void kunde_bearbeiten_Click(object sender, EventArgs e)
        {
            Formsswitch.kundebearbeiten(Benutzer);
            Hide();
        }

        private void kundeerstellen_button_Click(object sender, EventArgs e)
        {
            KundenErstellen kundenErstellen = new KundenErstellen(Benutzer);
            kundenErstellen.Show();
            Hide();
        }

        private void KundeAnzeigen_Load(object sender, EventArgs e)
        {
            OleDbDataAdapter Name = new OleDbDataAdapter("Select * from Kunde Where IstAktiv= True ", con);

            ds.Clear();
            Name.Fill(ds, "kundenanzeigenfilter");
            kundenanzeigen_dataGridView.DataSource = ds;
            kundenanzeigen_dataGridView.DataMember = "kundenanzeigenfilter";
            con.Close();
        }

        private void kundelöschen_button_Click(object sender, EventArgs e)
        {
            Formsswitch.kundelöschen(Benutzer);
            Hide();
        }

        DataTable table;
        private void suchen_button_Click(object sender, EventArgs e)
        {
            zurück_button.Visible = true;

            table = new DataTable();
            kundenanzeigen_dataGridView.DataSource = table;
           

                OleDbDataAdapter Name = new OleDbDataAdapter("Select * from Kunde Where IstAktiv= True ", con);

                ds.Clear();
                Name.Fill(table);
                DataView dv = table.DefaultView;
                dv.RowFilter = "Bezeichnung LIKE '" + suchen_textBox.Text + "%'";
                kundenanzeigen_dataGridView.DataSource = dv;
                con.Close();

            

            string searchValue = suchen_textBox.Text;
            
             kundenanzeigen_dataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            if (suchen_textBox.TextLength!=0)
            {


                foreach (DataGridViewRow row in kundenanzeigen_dataGridView.Rows)
                 {

                    if (row.Cells[1].Value == null) continue;
                    if (row.Cells[1].Value.ToString().Contains(searchValue))
                     {
                         row.Selected = true;
                     }
                     if (kundenanzeigen_dataGridView.SelectedRows.Count >= 1)
                     {
                         //min. ein  Element wurde markiert
                         kundenanzeigen_dataGridView.FirstDisplayedScrollingRowIndex = kundenanzeigen_dataGridView.SelectedRows[0].Index;
                     }
                    gefundene_kunden_label.Text = kundenanzeigen_dataGridView.SelectedRows.Count.ToString() + " '" + suchen_textBox.Text + "' " + "Gefunden";
                }

             }
            else
             {
                 MessageBox.Show("Geben eine richtige Kunden Bezeichnung ein");
             }

         
        }

        private void zurück_button_Click(object sender, EventArgs e)
        {
            Formsswitch.kundeanzeigen(Benutzer);
            this.Dispose(false);
        }

        private void alleanzeigen_button_Click(object sender, EventArgs e)
        {
            string searchValue = suchen_textBox.Text;
            kundenanzeigen_dataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            if (alleanzeigen_button.Text=="Alle Kunden Anzeigen")
            {
                
                OleDbDataAdapter Name = new OleDbDataAdapter("Select * from Kunde ", con);

                ds.Clear();
                Name.Fill(ds, "allekundenanzeigenfilter");
                kundenanzeigen_dataGridView.DataSource = ds;
                kundenanzeigen_dataGridView.DataMember = "allekundenanzeigenfilter";
                con.Close();
                alleanzeigen_button.Text = "Nur Kunden Anzeigen die Aktiv sind";

              

               
                if (suchen_textBox.TextLength != 0)
                {



                    foreach (DataGridViewRow row in kundenanzeigen_dataGridView.Rows)
                    {

                        if (row.Cells[1].Value == null) continue;
                        if (row.Cells[1].Value.ToString().Contains(searchValue))
                        {
                            row.Selected = true;
                        }
                        if (kundenanzeigen_dataGridView.SelectedRows.Count >= 1)
                        {
                            //min. ein  Element wurde markiert
                            kundenanzeigen_dataGridView.FirstDisplayedScrollingRowIndex = kundenanzeigen_dataGridView.SelectedRows[0].Index;
                        }
                        gefundene_kunden_label.Text = kundenanzeigen_dataGridView.SelectedRows.Count.ToString() + " '" + suchen_textBox.Text + "' " + "Gefunden";
                    }

                }
               
            }
            else if (alleanzeigen_button.Text == "Nur Kunden Anzeigen die Aktiv sind")
            {
                
                OleDbDataAdapter Name = new OleDbDataAdapter("Select * from Kunde Where IstAktiv= True ", con);

                ds.Clear();
                Name.Fill(ds, "kundenanzeigenfilter");
                kundenanzeigen_dataGridView.DataSource = ds;
                kundenanzeigen_dataGridView.DataMember = "kundenanzeigenfilter";
                con.Close();
                alleanzeigen_button.Text = "Alle Kunden Anzeigen";

                if (suchen_textBox.TextLength != 0)
                {
                    
                    foreach (DataGridViewRow row in kundenanzeigen_dataGridView.Rows)
                    {

                        if (row.Cells[1].Value == null) continue;
                        if (row.Cells[1].Value.ToString().Contains(searchValue))
                        {
                            row.Selected = true;
                        }
                        if (kundenanzeigen_dataGridView.SelectedRows.Count >= 1)
                        {
                            //min. ein  Element wurde markiert
                            kundenanzeigen_dataGridView.FirstDisplayedScrollingRowIndex = kundenanzeigen_dataGridView.SelectedRows[0].Index;
                        }
                        gefundene_kunden_label.Text = kundenanzeigen_dataGridView.SelectedRows.Count.ToString() + " '" + suchen_textBox.Text + "' " + "Gefunden";
                    }

                }
               
            }
           
        }
    }
}
