﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;
namespace Projekt
{
   

    class Kunde
    {
    OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Datenbank.accdb");
    OleDbDataReader dr = null;
    OleDbCommand cmd = null;

    HauptForm hauptForm;
      public static Button button = new Button();

        public Kunde(HauptForm hauptForm)
        {
            this.hauptForm = hauptForm;
        }

       
      
        
       
            
    }
}
