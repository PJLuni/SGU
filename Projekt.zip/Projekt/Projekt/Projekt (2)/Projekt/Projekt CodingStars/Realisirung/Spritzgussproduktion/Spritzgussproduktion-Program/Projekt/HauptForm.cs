﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt
{
    public partial class HauptForm : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Datenbank.accdb");
        DataSet ds = new DataSet();
        OleDbDataReader dr = null;
        OleDbCommand cmd = null;

        string Benutzer;
        public HauptForm(string Benutzer)
        {
            this.Benutzer = Benutzer;
            InitializeComponent();
        }

        TabPage kunde_suchen_löschen_tabPage = new TabPage();

        TabPage kunde_erstellen_tabPage = new TabPage();

        TabPage kunde_suchen_bearbeiten_tabPage = new TabPage();

        TabPage kunde_anzeigen_tabPage = new TabPage();

        private void HauptForm_Load(object sender, EventArgs e)
        {

            haupt_tabControl.TabPages.Clear();
            haupt_tabControl.Controls.Add(hauptmenü_tabPage);
            hauptmenü_anzeigen();
        }

        private void kunde_erstellen_toolStripMenuItem_Click(object sender, EventArgs e)
        {

            //Hier wird geprüft ob die tapPage schon aufgerufen ist.
            if (haupt_tabControl.TabPages.Contains(kunde_erstellen_tabPage) == true)
            {
                MessageBox.Show("Fehler");
            }
            else
            {
                kunde_erstellen_tabPage.Text = "Kunde-Erstellen";
                haupt_tabControl.Controls.Add(kunde_erstellen_tabPage);
                haupt_tabControl.SelectedTab = kunde_erstellen_tabPage;

                kunde_erstellen();

            }

        }

        private void kunde_anzeigen_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Hier wird geprüft ob die tapPage schon aufgerufen ist.
            if (haupt_tabControl.TabPages.Contains(kunde_anzeigen_tabPage) == true)
            {
                MessageBox.Show("Fehler");
            }
            else
            {

                kunde_anzeigen_tabPage.Text = "Kunden-Anzeigen";
                haupt_tabControl.Controls.Add(kunde_anzeigen_tabPage);
                haupt_tabControl.SelectedTab = kunde_anzeigen_tabPage;

                kunde_anzeigen();
            }
        }


        private void kunde_bearbeiten_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Hier wird geprüft ob die tapPage schon aufgerufen ist.
            if (haupt_tabControl.TabPages.Contains(kunde_suchen_bearbeiten_tabPage) == true)
            {
                MessageBox.Show("Fehler");
            }
            else
            {
                kunde_suchen_bearbeiten_tabPage.Text = "Kunde-suchen-Bearbeiten";
                haupt_tabControl.Controls.Add(kunde_suchen_bearbeiten_tabPage);
                haupt_tabControl.SelectedTab = kunde_suchen_bearbeiten_tabPage;

                kunde_bearbeiten();
            }
        }

        private void kunde_löschen_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Hier wird geprüft ob die tapPage schon aufgerufen ist.
            if (haupt_tabControl.TabPages.Contains(kunde_suchen_löschen_tabPage) == true)
            {
                MessageBox.Show("Fehler");
            }
            else
            {
                kunde_suchen_löschen_tabPage.Text = "Kunde-suchen-Löschen";
                haupt_tabControl.Controls.Add(kunde_suchen_löschen_tabPage);
                haupt_tabControl.SelectedTab = kunde_suchen_löschen_tabPage;

                kunde_löschen();

            }
        }

        public void hauptmenü_anzeigen()
        {



            einfügen_panel.Parent = hauptmenü_tabPage;

            einfügen_panel.Controls.Clear();
            Hauptmenü hauptmenü = new Hauptmenü(Benutzer);
            hauptmenü.TopLevel = false;
            einfügen_panel.Controls.Add(hauptmenü);
            hauptmenü.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            hauptmenü.Dock = DockStyle.Fill;
            hauptmenü.Show();


        }

        public void kunde_anzeigen()
        {


            einfügen_panel.Parent = kunde_anzeigen_tabPage;

            einfügen_panel.Controls.Clear();
            KundeAnzeigen kundeAnzeigen = new KundeAnzeigen(Benutzer);
            kundeAnzeigen.TopLevel = false;
            einfügen_panel.Controls.Add(kundeAnzeigen);
            kundeAnzeigen.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            kundeAnzeigen.Dock = DockStyle.Fill;
            kundeAnzeigen.Show();


        }

        public void kunde_erstellen()
        {


            einfügen_panel.Parent = kunde_erstellen_tabPage;


            einfügen_panel.Controls.Clear();
            KundenErstellen kundenErstellen = new KundenErstellen(Benutzer);
            kundenErstellen.TopLevel = false;
            einfügen_panel.Controls.Add(kundenErstellen);
            kundenErstellen.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            kundenErstellen.Dock = DockStyle.Fill;
            kundenErstellen.Show();

        }

        public void kunde_bearbeiten()
        {


            einfügen_panel.Parent = kunde_suchen_bearbeiten_tabPage;

            einfügen_panel.Controls.Clear();
            KundeBearbeiten kundeBearbeiten = new KundeBearbeiten(Benutzer);
            kundeBearbeiten.TopLevel = false;
            einfügen_panel.Controls.Add(kundeBearbeiten);
            kundeBearbeiten.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            kundeBearbeiten.Dock = DockStyle.Fill;
            kundeBearbeiten.Show();


        }
        public void kunde_löschen()
        {

            einfügen_panel.Parent = kunde_suchen_löschen_tabPage;

            einfügen_panel.Controls.Clear();
            KundeLöschen kundeLöschen = new KundeLöschen(Benutzer);
            kundeLöschen.TopLevel = false;
            einfügen_panel.Controls.Add(kundeLöschen);
            kundeLöschen.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            kundeLöschen.Dock = DockStyle.Fill;
            kundeLöschen.Show();

        }


        private void haupt_tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            Schließen_button.Visible = true;
            if (haupt_tabControl.SelectedTab == hauptmenü_tabPage)
            {
                hauptmenü_anzeigen();
                Schließen_button.Visible = false;
            }
            if (haupt_tabControl.SelectedTab == kunde_anzeigen_tabPage)
            {
                kunde_anzeigen();
            }
            if (haupt_tabControl.SelectedTab == kunde_erstellen_tabPage)
            {
                kunde_erstellen();
            }
            if (haupt_tabControl.SelectedTab == kunde_suchen_bearbeiten_tabPage)
            {
                kunde_bearbeiten();
            }
            if (haupt_tabControl.SelectedTab == kunde_suchen_löschen_tabPage)
            {
                kunde_löschen();
            }
        }

        private void Schließen_button_Click(object sender, EventArgs e)
        {

            //Hier wird die Aktuell ausgewählte page geschlossen.
            TabPage selectedtap = haupt_tabControl.SelectedTab;
            haupt_tabControl.TabPages.Remove(selectedtap);
            if (haupt_tabControl.TabPages.Count == 0)
            {
                MessageBox.Show("Bitte wählen sie etwas aus");

            }
        }
    }
}




