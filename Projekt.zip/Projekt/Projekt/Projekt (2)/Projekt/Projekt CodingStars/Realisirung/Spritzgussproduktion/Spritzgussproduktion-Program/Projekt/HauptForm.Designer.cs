﻿namespace Projekt
{
    partial class HauptForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HauptForm));
            this.haupt_tabControl = new System.Windows.Forms.TabControl();
            this.hauptmenü_tabPage = new System.Windows.Forms.TabPage();
            this.einfügen_panel = new System.Windows.Forms.Panel();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.kunde_ausklappen_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kunde_erstellen_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kunde_anzeigen_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kunde_bearbeiten_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kunde_löschen_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Schließen_button = new System.Windows.Forms.Button();
            this.layout_panel = new System.Windows.Forms.Panel();
            this.haupt_tabControl.SuspendLayout();
            this.hauptmenü_tabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.layout_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // haupt_tabControl
            // 
            this.haupt_tabControl.Controls.Add(this.hauptmenü_tabPage);
            this.haupt_tabControl.Location = new System.Drawing.Point(-9, 0);
            this.haupt_tabControl.Name = "haupt_tabControl";
            this.haupt_tabControl.SelectedIndex = 0;
            this.haupt_tabControl.Size = new System.Drawing.Size(643, 559);
            this.haupt_tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.haupt_tabControl.TabIndex = 21;
            this.haupt_tabControl.SelectedIndexChanged += new System.EventHandler(this.haupt_tabControl_SelectedIndexChanged);
            // 
            // hauptmenü_tabPage
            // 
            this.hauptmenü_tabPage.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.hauptmenü_tabPage.Controls.Add(this.einfügen_panel);
            this.hauptmenü_tabPage.Location = new System.Drawing.Point(4, 22);
            this.hauptmenü_tabPage.Name = "hauptmenü_tabPage";
            this.hauptmenü_tabPage.Size = new System.Drawing.Size(635, 533);
            this.hauptmenü_tabPage.TabIndex = 0;
            this.hauptmenü_tabPage.Text = "Hauptmenü";
            // 
            // einfügen_panel
            // 
            this.einfügen_panel.Location = new System.Drawing.Point(8, 0);
            this.einfügen_panel.Name = "einfügen_panel";
            this.einfügen_panel.Size = new System.Drawing.Size(622, 537);
            this.einfügen_panel.TabIndex = 0;
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.LightSlateGray;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kunde_ausklappen_toolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(84, 588);
            this.menuStrip1.TabIndex = 22;
            this.menuStrip1.Text = "Menü";
            // 
            // kunde_ausklappen_toolStripMenuItem
            // 
            this.kunde_ausklappen_toolStripMenuItem.BackColor = System.Drawing.Color.LightSlateGray;
            this.kunde_ausklappen_toolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kunde_erstellen_toolStripMenuItem,
            this.kunde_anzeigen_toolStripMenuItem,
            this.kunde_bearbeiten_toolStripMenuItem,
            this.kunde_löschen_toolStripMenuItem,
            this.toolStripMenuItem6});
            this.kunde_ausklappen_toolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kunde_ausklappen_toolStripMenuItem.Name = "kunde_ausklappen_toolStripMenuItem";
            this.kunde_ausklappen_toolStripMenuItem.Size = new System.Drawing.Size(71, 29);
            this.kunde_ausklappen_toolStripMenuItem.Text = "Kunde";
            // 
            // kunde_erstellen_toolStripMenuItem
            // 
            this.kunde_erstellen_toolStripMenuItem.Name = "kunde_erstellen_toolStripMenuItem";
            this.kunde_erstellen_toolStripMenuItem.Size = new System.Drawing.Size(239, 34);
            this.kunde_erstellen_toolStripMenuItem.Text = "Erstellen";
            this.kunde_erstellen_toolStripMenuItem.Click += new System.EventHandler(this.kunde_erstellen_toolStripMenuItem_Click);
            // 
            // kunde_anzeigen_toolStripMenuItem
            // 
            this.kunde_anzeigen_toolStripMenuItem.Name = "kunde_anzeigen_toolStripMenuItem";
            this.kunde_anzeigen_toolStripMenuItem.Size = new System.Drawing.Size(239, 34);
            this.kunde_anzeigen_toolStripMenuItem.Text = "Anzeigen";
            this.kunde_anzeigen_toolStripMenuItem.Click += new System.EventHandler(this.kunde_anzeigen_toolStripMenuItem_Click);
            // 
            // kunde_bearbeiten_toolStripMenuItem
            // 
            this.kunde_bearbeiten_toolStripMenuItem.Name = "kunde_bearbeiten_toolStripMenuItem";
            this.kunde_bearbeiten_toolStripMenuItem.Size = new System.Drawing.Size(239, 34);
            this.kunde_bearbeiten_toolStripMenuItem.Text = "Bearbeiten";
            this.kunde_bearbeiten_toolStripMenuItem.Click += new System.EventHandler(this.kunde_bearbeiten_toolStripMenuItem_Click);
            // 
            // kunde_löschen_toolStripMenuItem
            // 
            this.kunde_löschen_toolStripMenuItem.Name = "kunde_löschen_toolStripMenuItem";
            this.kunde_löschen_toolStripMenuItem.Size = new System.Drawing.Size(239, 34);
            this.kunde_löschen_toolStripMenuItem.Text = "Löschen";
            this.kunde_löschen_toolStripMenuItem.Click += new System.EventHandler(this.kunde_löschen_toolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9});
            this.toolStripMenuItem6.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(239, 34);
            this.toolStripMenuItem6.Text = "Ansprechpartner";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(136, 22);
            this.toolStripMenuItem7.Text = "Anzeigen";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(136, 22);
            this.toolStripMenuItem8.Text = "Löschen";
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(136, 22);
            this.toolStripMenuItem9.Text = "Bearbeiten";
            // 
            // menuStrip2
            // 
            this.menuStrip2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 588);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(712, 24);
            this.menuStrip2.TabIndex = 23;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4, 0, 30, 0);
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Padding = new System.Windows.Forms.Padding(30, 0, 4, 0);
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.logoutToolStripMenuItem.Text = "Logout";
            // 
            // Schließen_button
            // 
            this.Schließen_button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Schließen_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Schließen_button.Location = new System.Drawing.Point(633, 559);
            this.Schließen_button.Name = "Schließen_button";
            this.Schließen_button.Size = new System.Drawing.Size(80, 29);
            this.Schließen_button.TabIndex = 36;
            this.Schließen_button.Text = "Schließen";
            this.Schließen_button.UseVisualStyleBackColor = true;
            this.Schließen_button.Click += new System.EventHandler(this.Schließen_button_Click);
            // 
            // layout_panel
            // 
            this.layout_panel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.layout_panel.Controls.Add(this.haupt_tabControl);
            this.layout_panel.Location = new System.Drawing.Point(87, 0);
            this.layout_panel.Name = "layout_panel";
            this.layout_panel.Size = new System.Drawing.Size(537, 522);
            this.layout_panel.TabIndex = 17;
            // 
            // HauptForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(712, 612);
            this.Controls.Add(this.layout_panel);
            this.Controls.Add(this.Schließen_button);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "HauptForm";
            this.Text = "HauptForm";
            this.Load += new System.EventHandler(this.HauptForm_Load);
            this.haupt_tabControl.ResumeLayout(false);
            this.hauptmenü_tabPage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.layout_panel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TabControl haupt_tabControl;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem kunde_ausklappen_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kunde_erstellen_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kunde_anzeigen_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kunde_bearbeiten_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kunde_löschen_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Button Schließen_button;
        private System.Windows.Forms.Panel layout_panel;
        private System.Windows.Forms.TabPage hauptmenü_tabPage;
        private System.Windows.Forms.Panel einfügen_panel;
    }
}