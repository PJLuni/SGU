﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt
{
    public partial class Hauptmenü : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Datenbank.accdb");
        DataSet ds = new DataSet();
       
        string Benutzer;
        public Hauptmenü(string Benutzer)
        {
           this.Benutzer = Benutzer;
            InitializeComponent();
        }

        private void kunde_erstellen_Click(object sender, EventArgs e)
        {
            KundenErstellen kundenErstellen = new KundenErstellen(Benutzer);
            kundenErstellen.Show();
            Hide();
        }

        private void Hauptmenü_Load(object sender, EventArgs e)
        {
            OleDbDataAdapter Name = new OleDbDataAdapter("SELECT Auftrag.Nr, Auftrag.Kunde, Auftrag.Auslieferungsdatum, Auftragsstatus.Bezeichnung from Auftrag , Auftragsstatus ", con);

            ds.Clear();
            Name.Fill(ds, "Auftragfilter");
            aufträge_datagridview.DataSource = ds;
            aufträge_datagridview.DataMember = "Auftragfilter";
          
        }

        private void Logout_button_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            Hide();
        }

        private void Exit_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void kunde_anzeigen_Click(object sender, EventArgs e)
        {
            Formsswitch.kundeanzeigen(Benutzer);
            Hide();
        }

        private void kunde_löschen_Click(object sender, EventArgs e)
        {
            KundeLöschen kundeLöschen = new KundeLöschen(Benutzer);
            kundeLöschen.Show();
            Hide();
        }

        private void kunde_bearbeiten_Click(object sender, EventArgs e)
        {
            Formsswitch.kundebearbeiten(Benutzer);
            Hide();
        }
    }
}
