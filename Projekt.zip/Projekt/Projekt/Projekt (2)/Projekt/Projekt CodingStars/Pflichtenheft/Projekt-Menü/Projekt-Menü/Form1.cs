﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Projekt_Menü
{
    public partial class Form1 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Projekt.accdb");
        DataSet ds = new DataSet();

        public Form1()
        {
            InitializeComponent();
        }
        private bool P1_isaktivirt = true;
        private bool P2_isaktivirt = true;
      

        private void button1_Click(object sender, EventArgs e)
        {
            if (P1_isaktivirt==true)
            {
                panel1.Size = panel1.MaximumSize;
                if (panel1.Size==panel1.MaximumSize)
                {
                    P1_isaktivirt = false;
                }
                
            }
            else
            {
                panel1.Size = panel1.MinimumSize;
                if (panel1.Size==panel1.MinimumSize)
                {
                    P1_isaktivirt = true;
                }
            }
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (P2_isaktivirt == true)
            {
                panel2.Size = panel2.MaximumSize;
                if (panel2.Size == panel2.MaximumSize)
                {
                    P2_isaktivirt = false;
                }

            }
            else
            {
                panel2.Size = panel2.MinimumSize;
                if (panel2.Size == panel2.MinimumSize)
                {
                    P2_isaktivirt = true;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            OleDbDataAdapter Name = new OleDbDataAdapter("SELECT * FROM Auftrag WHERE auftr_statusart = false", con);

            ds.Clear();
            Name.Fill(ds, "Auftragfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Auftragfilter";

        }
    }
}
