﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt
{
    public partial class Login : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Datenbank.accdb");
        DataSet ds = new DataSet();
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        public Login()
        {
            InitializeComponent();
            this.KeyDown += new KeyEventHandler(login_KeyDown);
        }
        private void login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                login_button.PerformClick();

                e.SuppressKeyPress = true;
                e.Handled = true;
            }
        
    
        }

        private void login_button_Click(object sender, EventArgs e)
        {
            

                string Benutzer = benutzername_textBox.Text;
                string Passwort = password_textBox.Text;
                if (benutzername_textBox.TextLength != 0)
                {
                if (password_textBox.TextLength != 0)
                {

                    try
                    {
                        cmd = new OleDbCommand("Select Benutzername from Benutzerkonto where Benutzername = '" + Benutzer + "'", con);
                        con.Open();
                        dr = cmd.ExecuteReader();
                        dr.Read();
                        string Benutzername = dr.GetString(0);
                        con.Close();

                        cmd = new OleDbCommand("Select Passwort from Benutzerkonto where Benutzername = '" + Benutzername + "'", con);
                        con.Open();
                        dr = cmd.ExecuteReader();
                        dr.Read();
                        string BenutzerPasswort = dr.GetString(0);
                        con.Close();

                        cmd = new OleDbCommand("Select IstAktiv from Benutzerkonto where Benutzername = '" + Benutzername + "'", con);
                        con.Open();
                        dr = cmd.ExecuteReader();
                        dr.Read();
                        bool BenutzerIstAktiv = dr.GetBoolean(0);
                        con.Close();

                        if (Benutzer == Benutzername & Passwort == BenutzerPasswort & BenutzerIstAktiv == true)
                        {
                            con.Open();

                            cmd = new OleDbCommand("select * from Benutzerkonto where Benutzername = '" + Benutzer + "' and Passwort = '" + Passwort + "'", con);

                            dr = cmd.ExecuteReader();
                            while (dr.Read())
                            {
                                HauptForm hauptForm = new HauptForm(Benutzer);
                                hauptForm.Show();
                                Hide();
                            }


                        }
                        else
                        {
                            MessageBox.Show("Geben sie Bitte einen Erstellten Benutzer ein");
                        }

                    }
                    catch
                    {
                       
                        MessageBox.Show("Geben sie Bitte einen Erstellten Benutzer ein");
                        
                    }
                    // Hier wird nach jedem Button klick die noch zu offen scheinenden Verbindungen geschlossen
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Geben sie Bitte ein Passwort ein");
                    password_textBox.Focus();
                }


            }

            else

            {
                MessageBox.Show("Geben sie Bitte ein Benutzer ein");
                benutzername_textBox.Focus();
            }
                
        }
        private void Login_Load(object sender, EventArgs e)
        {
            bild_augeoffen.Visible = false;
            password_textBox.UseSystemPasswordChar = true;
            
        }

        private void bild_augezu_Click_1(object sender, EventArgs e)
        {
            bild_augezu.Visible = false;
            bild_augeoffen.Visible = true;
            if (bild_augeoffen.Visible == true)
            {
                password_textBox.UseSystemPasswordChar = false;
            }
            else
            {
                password_textBox.UseSystemPasswordChar = true;
            }
        }

        private void bild_augeoffen_Click_1(object sender, EventArgs e)
        {
            bild_augeoffen.Visible = false;
            bild_augezu.Visible = true;
            if (bild_augezu.Visible == false)
            {
                password_textBox.UseSystemPasswordChar = false;
            }
            else
            {
                password_textBox.UseSystemPasswordChar = true;
            }
        }

        private void exit_button_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
