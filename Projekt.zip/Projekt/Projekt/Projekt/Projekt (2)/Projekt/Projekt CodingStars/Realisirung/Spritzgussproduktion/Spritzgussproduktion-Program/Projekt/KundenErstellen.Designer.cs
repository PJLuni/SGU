﻿namespace Projekt
{
    partial class KundenErstellen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KundenErstellen));
            this.Speichern_button = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.IstAktiv_checkBox = new System.Windows.Forms.CheckBox();
            this.IstAktiv_label = new System.Windows.Forms.Label();
            this.Anmerkung_label = new System.Windows.Forms.Label();
            this.Anmerkung_textBox = new System.Windows.Forms.TextBox();
            this.Land_label = new System.Windows.Forms.Label();
            this.Land_textBox = new System.Windows.Forms.TextBox();
            this.Straße_label = new System.Windows.Forms.Label();
            this.Straße_textBox = new System.Windows.Forms.TextBox();
            this.Ort_label = new System.Windows.Forms.Label();
            this.Ort_textBox = new System.Windows.Forms.TextBox();
            this.PLZ_label = new System.Windows.Forms.Label();
            this.PLZ_textBox = new System.Windows.Forms.TextBox();
            this.Fax_label = new System.Windows.Forms.Label();
            this.Fax_textBox = new System.Windows.Forms.TextBox();
            this.Email_label = new System.Windows.Forms.Label();
            this.Email_textBox = new System.Windows.Forms.TextBox();
            this.Telefon_label = new System.Windows.Forms.Label();
            this.Telefon_textBox = new System.Windows.Forms.TextBox();
            this.Bezeichnung_label = new System.Windows.Forms.Label();
            this.Nr_label = new System.Windows.Forms.Label();
            this.bezeichnung_textBox = new System.Windows.Forms.TextBox();
            this.Nr_textBox = new System.Windows.Forms.TextBox();
            this.kundenerstellen_überschrift = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Speichern_button
            // 
            this.Speichern_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Speichern_button.Location = new System.Drawing.Point(206, 364);
            this.Speichern_button.Name = "Speichern_button";
            this.Speichern_button.Size = new System.Drawing.Size(121, 26);
            this.Speichern_button.TabIndex = 28;
            this.Speichern_button.Text = "Speichern";
            this.Speichern_button.UseVisualStyleBackColor = true;
            this.Speichern_button.Click += new System.EventHandler(this.Speichern_button_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.IstAktiv_checkBox);
            this.panel1.Controls.Add(this.Speichern_button);
            this.panel1.Controls.Add(this.IstAktiv_label);
            this.panel1.Controls.Add(this.Anmerkung_label);
            this.panel1.Controls.Add(this.Anmerkung_textBox);
            this.panel1.Controls.Add(this.Land_label);
            this.panel1.Controls.Add(this.Land_textBox);
            this.panel1.Controls.Add(this.Straße_label);
            this.panel1.Controls.Add(this.Straße_textBox);
            this.panel1.Controls.Add(this.Ort_label);
            this.panel1.Controls.Add(this.Ort_textBox);
            this.panel1.Controls.Add(this.PLZ_label);
            this.panel1.Controls.Add(this.PLZ_textBox);
            this.panel1.Controls.Add(this.Fax_label);
            this.panel1.Controls.Add(this.Fax_textBox);
            this.panel1.Controls.Add(this.Email_label);
            this.panel1.Controls.Add(this.Email_textBox);
            this.panel1.Controls.Add(this.Telefon_label);
            this.panel1.Controls.Add(this.Telefon_textBox);
            this.panel1.Controls.Add(this.Bezeichnung_label);
            this.panel1.Controls.Add(this.Nr_label);
            this.panel1.Controls.Add(this.bezeichnung_textBox);
            this.panel1.Controls.Add(this.Nr_textBox);
            this.panel1.Location = new System.Drawing.Point(37, 75);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(523, 406);
            this.panel1.TabIndex = 29;
            // 
            // IstAktiv_checkBox
            // 
            this.IstAktiv_checkBox.AutoSize = true;
            this.IstAktiv_checkBox.Checked = true;
            this.IstAktiv_checkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.IstAktiv_checkBox.Location = new System.Drawing.Point(380, 291);
            this.IstAktiv_checkBox.Name = "IstAktiv_checkBox";
            this.IstAktiv_checkBox.Size = new System.Drawing.Size(15, 14);
            this.IstAktiv_checkBox.TabIndex = 49;
            this.IstAktiv_checkBox.UseVisualStyleBackColor = true;
            // 
            // IstAktiv_label
            // 
            this.IstAktiv_label.AutoSize = true;
            this.IstAktiv_label.Location = new System.Drawing.Point(319, 292);
            this.IstAktiv_label.Name = "IstAktiv_label";
            this.IstAktiv_label.Size = new System.Drawing.Size(42, 13);
            this.IstAktiv_label.TabIndex = 48;
            this.IstAktiv_label.Text = "IstAktiv";
            // 
            // Anmerkung_label
            // 
            this.Anmerkung_label.AutoSize = true;
            this.Anmerkung_label.Location = new System.Drawing.Point(300, 242);
            this.Anmerkung_label.Name = "Anmerkung_label";
            this.Anmerkung_label.Size = new System.Drawing.Size(61, 13);
            this.Anmerkung_label.TabIndex = 47;
            this.Anmerkung_label.Text = "Anmerkung";
            // 
            // Anmerkung_textBox
            // 
            this.Anmerkung_textBox.Location = new System.Drawing.Point(380, 239);
            this.Anmerkung_textBox.Multiline = true;
            this.Anmerkung_textBox.Name = "Anmerkung_textBox";
            this.Anmerkung_textBox.Size = new System.Drawing.Size(100, 30);
            this.Anmerkung_textBox.TabIndex = 46;
            // 
            // Land_label
            // 
            this.Land_label.AutoSize = true;
            this.Land_label.Location = new System.Drawing.Point(330, 197);
            this.Land_label.Name = "Land_label";
            this.Land_label.Size = new System.Drawing.Size(31, 13);
            this.Land_label.TabIndex = 45;
            this.Land_label.Text = "Land";
            // 
            // Land_textBox
            // 
            this.Land_textBox.Location = new System.Drawing.Point(380, 194);
            this.Land_textBox.Name = "Land_textBox";
            this.Land_textBox.Size = new System.Drawing.Size(100, 20);
            this.Land_textBox.TabIndex = 44;
            this.Land_textBox.Text = "Deutschland";
            // 
            // Straße_label
            // 
            this.Straße_label.AutoSize = true;
            this.Straße_label.Location = new System.Drawing.Point(323, 146);
            this.Straße_label.Name = "Straße_label";
            this.Straße_label.Size = new System.Drawing.Size(38, 13);
            this.Straße_label.TabIndex = 43;
            this.Straße_label.Text = "Straße";
            // 
            // Straße_textBox
            // 
            this.Straße_textBox.Location = new System.Drawing.Point(380, 139);
            this.Straße_textBox.Name = "Straße_textBox";
            this.Straße_textBox.Size = new System.Drawing.Size(100, 20);
            this.Straße_textBox.TabIndex = 42;
            // 
            // Ort_label
            // 
            this.Ort_label.AutoSize = true;
            this.Ort_label.Location = new System.Drawing.Point(340, 96);
            this.Ort_label.Name = "Ort_label";
            this.Ort_label.Size = new System.Drawing.Size(21, 13);
            this.Ort_label.TabIndex = 41;
            this.Ort_label.Text = "Ort";
            // 
            // Ort_textBox
            // 
            this.Ort_textBox.Location = new System.Drawing.Point(380, 93);
            this.Ort_textBox.Name = "Ort_textBox";
            this.Ort_textBox.Size = new System.Drawing.Size(100, 20);
            this.Ort_textBox.TabIndex = 40;
            // 
            // PLZ_label
            // 
            this.PLZ_label.AutoSize = true;
            this.PLZ_label.Location = new System.Drawing.Point(334, 49);
            this.PLZ_label.Name = "PLZ_label";
            this.PLZ_label.Size = new System.Drawing.Size(27, 13);
            this.PLZ_label.TabIndex = 39;
            this.PLZ_label.Text = "PLZ";
            // 
            // PLZ_textBox
            // 
            this.PLZ_textBox.Location = new System.Drawing.Point(380, 46);
            this.PLZ_textBox.Name = "PLZ_textBox";
            this.PLZ_textBox.Size = new System.Drawing.Size(100, 20);
            this.PLZ_textBox.TabIndex = 38;
            // 
            // Fax_label
            // 
            this.Fax_label.AutoSize = true;
            this.Fax_label.Location = new System.Drawing.Point(53, 298);
            this.Fax_label.Name = "Fax_label";
            this.Fax_label.Size = new System.Drawing.Size(24, 13);
            this.Fax_label.TabIndex = 37;
            this.Fax_label.Text = "Fax";
            // 
            // Fax_textBox
            // 
            this.Fax_textBox.Location = new System.Drawing.Point(101, 291);
            this.Fax_textBox.Name = "Fax_textBox";
            this.Fax_textBox.Size = new System.Drawing.Size(100, 20);
            this.Fax_textBox.TabIndex = 36;
            // 
            // Email_label
            // 
            this.Email_label.AutoSize = true;
            this.Email_label.Location = new System.Drawing.Point(42, 231);
            this.Email_label.Name = "Email_label";
            this.Email_label.Size = new System.Drawing.Size(36, 13);
            this.Email_label.TabIndex = 35;
            this.Email_label.Text = "E-Mail";
            // 
            // Email_textBox
            // 
            this.Email_textBox.Location = new System.Drawing.Point(101, 231);
            this.Email_textBox.Name = "Email_textBox";
            this.Email_textBox.Size = new System.Drawing.Size(100, 20);
            this.Email_textBox.TabIndex = 34;
            // 
            // Telefon_label
            // 
            this.Telefon_label.AutoSize = true;
            this.Telefon_label.Location = new System.Drawing.Point(34, 174);
            this.Telefon_label.Name = "Telefon_label";
            this.Telefon_label.Size = new System.Drawing.Size(43, 13);
            this.Telefon_label.TabIndex = 33;
            this.Telefon_label.Text = "Telefon";
            // 
            // Telefon_textBox
            // 
            this.Telefon_textBox.Location = new System.Drawing.Point(101, 167);
            this.Telefon_textBox.Name = "Telefon_textBox";
            this.Telefon_textBox.Size = new System.Drawing.Size(100, 20);
            this.Telefon_textBox.TabIndex = 32;
            // 
            // Bezeichnung_label
            // 
            this.Bezeichnung_label.AutoSize = true;
            this.Bezeichnung_label.Location = new System.Drawing.Point(8, 112);
            this.Bezeichnung_label.Name = "Bezeichnung_label";
            this.Bezeichnung_label.Size = new System.Drawing.Size(69, 13);
            this.Bezeichnung_label.TabIndex = 31;
            this.Bezeichnung_label.Text = "Bezeichnung";
            // 
            // Nr_label
            // 
            this.Nr_label.AutoSize = true;
            this.Nr_label.Location = new System.Drawing.Point(59, 53);
            this.Nr_label.Name = "Nr_label";
            this.Nr_label.Size = new System.Drawing.Size(18, 13);
            this.Nr_label.TabIndex = 30;
            this.Nr_label.Text = "Nr";
            // 
            // bezeichnung_textBox
            // 
            this.bezeichnung_textBox.Location = new System.Drawing.Point(101, 109);
            this.bezeichnung_textBox.Name = "bezeichnung_textBox";
            this.bezeichnung_textBox.Size = new System.Drawing.Size(100, 20);
            this.bezeichnung_textBox.TabIndex = 29;
            // 
            // Nr_textBox
            // 
            this.Nr_textBox.Location = new System.Drawing.Point(101, 46);
            this.Nr_textBox.Name = "Nr_textBox";
            this.Nr_textBox.Size = new System.Drawing.Size(64, 20);
            this.Nr_textBox.TabIndex = 28;
            // 
            // kundenerstellen_überschrift
            // 
            this.kundenerstellen_überschrift.AutoSize = true;
            this.kundenerstellen_überschrift.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kundenerstellen_überschrift.Location = new System.Drawing.Point(208, 9);
            this.kundenerstellen_überschrift.Name = "kundenerstellen_überschrift";
            this.kundenerstellen_überschrift.Size = new System.Drawing.Size(242, 37);
            this.kundenerstellen_überschrift.TabIndex = 27;
            this.kundenerstellen_überschrift.Text = "Kunde-Erstellen";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(380, 321);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 57;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(289, 322);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 56;
            this.label1.Text = "Extra Lieferort";
            // 
            // KundenErstellen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(613, 511);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.kundenerstellen_überschrift);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "KundenErstellen";
            this.Text = "KundenErstellen";
            this.Load += new System.EventHandler(this.KundenErstellen_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Speichern_button;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox IstAktiv_checkBox;
        private System.Windows.Forms.Label IstAktiv_label;
        private System.Windows.Forms.Label Anmerkung_label;
        private System.Windows.Forms.TextBox Anmerkung_textBox;
        private System.Windows.Forms.Label Land_label;
        private System.Windows.Forms.TextBox Land_textBox;
        private System.Windows.Forms.Label Straße_label;
        private System.Windows.Forms.TextBox Straße_textBox;
        private System.Windows.Forms.Label Ort_label;
        private System.Windows.Forms.TextBox Ort_textBox;
        private System.Windows.Forms.Label PLZ_label;
        private System.Windows.Forms.TextBox PLZ_textBox;
        private System.Windows.Forms.Label Fax_label;
        private System.Windows.Forms.TextBox Fax_textBox;
        private System.Windows.Forms.Label Email_label;
        private System.Windows.Forms.TextBox Email_textBox;
        private System.Windows.Forms.Label Telefon_label;
        private System.Windows.Forms.TextBox Telefon_textBox;
        private System.Windows.Forms.Label Bezeichnung_label;
        private System.Windows.Forms.Label Nr_label;
        private System.Windows.Forms.TextBox bezeichnung_textBox;
        private System.Windows.Forms.TextBox Nr_textBox;
        private System.Windows.Forms.Label kundenerstellen_überschrift;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
    }
}