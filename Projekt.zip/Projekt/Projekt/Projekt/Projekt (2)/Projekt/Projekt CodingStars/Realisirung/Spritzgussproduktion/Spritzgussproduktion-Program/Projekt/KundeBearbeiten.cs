﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt
{
    public partial class KundeBearbeiten : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Datenbank.accdb");
        DataSet ds = new DataSet();
        OleDbDataReader dr = null;
        OleDbCommand cmd = null;

       
        string Benutzer;
        public KundeBearbeiten(string Benutzer)
        {
           
            this.Benutzer = Benutzer;
            InitializeComponent();
        }

        private void hauptmenü_button_Click(object sender, EventArgs e)
        {
            Formsswitch.hauptmenü(Benutzer);
            Hide();
        }

        private void kundeanzeigen_button_Click(object sender, EventArgs e)
        {
            Formsswitch.kundeanzeigen(Benutzer);
            Hide();
        }

        private void suchen_button_Click(object sender, EventArgs e)
        {
            kunden_listBox.SelectionMode = SelectionMode.MultiSimple;

            gefundendeitems_label.Visible = true;



            kunden_listBox.SelectedItems.Clear();
            if (suchen_textBox.TextLength != 0)
            {
                for (int i = kunden_listBox.Items.Count - 1; i >= 0; i--)
                {

                    if (kunden_listBox.Items[i].ToString().ToLower().Contains(suchen_textBox.Text.ToLower()))
                    {
                        kunden_listBox.SetSelected(i, true);
                    }

                }
                gefundendeitems_label.Text = kunden_listBox.SelectedItems.Count.ToString() + " '" + suchen_textBox.Text + "' " + "Gefunden";
            }
            else
            {
                MessageBox.Show("Geben sie bitte einen Kunden ein");
            }
            string vergleich = kunden_listBox.SelectedItem.ToString();
           

        }

        private void zurück_button_Click(object sender, EventArgs e)
        {
            Formsswitch.kundebearbeiten(Benutzer);
            this.Dispose(false);
        }

        private void KundeBearbeiten_Load(object sender, EventArgs e)
        {
            such_panel.Visible = true;


            




            con.Open();
            cmd = new OleDbCommand("select Bezeichnung from Kunde", con);

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                kunden_listBox.Items.Add(dr.GetString(0));
            }


            con.Close();
        }

        private void alleanzeigen_button_Click(object sender, EventArgs e)
        {

        }
    }
}

