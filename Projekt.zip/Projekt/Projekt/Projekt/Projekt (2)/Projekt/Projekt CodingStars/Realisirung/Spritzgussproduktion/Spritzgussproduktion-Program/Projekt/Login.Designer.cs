﻿namespace Projekt
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.login_überschrift = new System.Windows.Forms.Label();
            this.panel_links = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bild_augezu = new System.Windows.Forms.PictureBox();
            this.bild_augeoffen = new System.Windows.Forms.PictureBox();
            this.exit_button = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.login_button = new System.Windows.Forms.Button();
            this.password_textBox = new System.Windows.Forms.TextBox();
            this.benutzername_textBox = new System.Windows.Forms.TextBox();
            this.passwort_label = new System.Windows.Forms.Label();
            this.benutzername_label = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.panel_links.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bild_augezu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bild_augeoffen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // login_überschrift
            // 
            this.login_überschrift.AutoSize = true;
            this.login_überschrift.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_überschrift.Location = new System.Drawing.Point(12, 88);
            this.login_überschrift.Name = "login_überschrift";
            this.login_überschrift.Size = new System.Drawing.Size(80, 31);
            this.login_überschrift.TabIndex = 0;
            this.login_überschrift.Text = "Login";
            // 
            // panel_links
            // 
            this.panel_links.BackColor = System.Drawing.Color.DarkCyan;
            this.panel_links.Controls.Add(this.login_überschrift);
            this.panel_links.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_links.Location = new System.Drawing.Point(0, 0);
            this.panel_links.Name = "panel_links";
            this.panel_links.Size = new System.Drawing.Size(105, 195);
            this.panel_links.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.Controls.Add(this.linkLabel1);
            this.panel1.Controls.Add(this.bild_augezu);
            this.panel1.Controls.Add(this.bild_augeoffen);
            this.panel1.Controls.Add(this.exit_button);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.login_button);
            this.panel1.Controls.Add(this.password_textBox);
            this.panel1.Controls.Add(this.benutzername_textBox);
            this.panel1.Controls.Add(this.passwort_label);
            this.panel1.Controls.Add(this.benutzername_label);
            this.panel1.Location = new System.Drawing.Point(118, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(421, 184);
            this.panel1.TabIndex = 2;
            // 
            // bild_augezu
            // 
            this.bild_augezu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bild_augezu.BackgroundImage")));
            this.bild_augezu.Image = ((System.Drawing.Image)(resources.GetObject("bild_augezu.Image")));
            this.bild_augezu.Location = new System.Drawing.Point(346, 76);
            this.bild_augezu.Name = "bild_augezu";
            this.bild_augezu.Size = new System.Drawing.Size(37, 20);
            this.bild_augezu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bild_augezu.TabIndex = 9;
            this.bild_augezu.TabStop = false;
            this.bild_augezu.Click += new System.EventHandler(this.bild_augezu_Click_1);
            // 
            // bild_augeoffen
            // 
            this.bild_augeoffen.Image = ((System.Drawing.Image)(resources.GetObject("bild_augeoffen.Image")));
            this.bild_augeoffen.Location = new System.Drawing.Point(347, 76);
            this.bild_augeoffen.Name = "bild_augeoffen";
            this.bild_augeoffen.Size = new System.Drawing.Size(36, 20);
            this.bild_augeoffen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bild_augeoffen.TabIndex = 8;
            this.bild_augeoffen.TabStop = false;
            this.bild_augeoffen.Click += new System.EventHandler(this.bild_augeoffen_Click_1);
            // 
            // exit_button
            // 
            this.exit_button.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.exit_button.FlatAppearance.BorderColor = System.Drawing.Color.SeaGreen;
            this.exit_button.FlatAppearance.BorderSize = 0;
            this.exit_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkCyan;
            this.exit_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_button.Location = new System.Drawing.Point(0, 152);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(89, 32);
            this.exit_button.TabIndex = 7;
            this.exit_button.Text = "EXIT";
            this.exit_button.UseVisualStyleBackColor = false;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.DarkCyan;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 70);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 25);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 25);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // login_button
            // 
            this.login_button.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.login_button.FlatAppearance.BorderSize = 0;
            this.login_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkCyan;
            this.login_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.login_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_button.Location = new System.Drawing.Point(332, 152);
            this.login_button.Name = "login_button";
            this.login_button.Size = new System.Drawing.Size(89, 32);
            this.login_button.TabIndex = 4;
            this.login_button.Text = "LOGIN";
            this.login_button.UseVisualStyleBackColor = false;
            this.login_button.Click += new System.EventHandler(this.login_button_Click);
            // 
            // password_textBox
            // 
            this.password_textBox.Location = new System.Drawing.Point(217, 76);
            this.password_textBox.Name = "password_textBox";
            this.password_textBox.Size = new System.Drawing.Size(133, 20);
            this.password_textBox.TabIndex = 3;
            // 
            // benutzername_textBox
            // 
            this.benutzername_textBox.Location = new System.Drawing.Point(217, 18);
            this.benutzername_textBox.Name = "benutzername_textBox";
            this.benutzername_textBox.Size = new System.Drawing.Size(133, 20);
            this.benutzername_textBox.TabIndex = 2;
            // 
            // passwort_label
            // 
            this.passwort_label.AutoSize = true;
            this.passwort_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwort_label.Location = new System.Drawing.Point(61, 70);
            this.passwort_label.Name = "passwort_label";
            this.passwort_label.Size = new System.Drawing.Size(92, 25);
            this.passwort_label.TabIndex = 1;
            this.passwort_label.Text = "Passwort";
            // 
            // benutzername_label
            // 
            this.benutzername_label.AutoSize = true;
            this.benutzername_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.benutzername_label.Location = new System.Drawing.Point(61, 13);
            this.benutzername_label.Name = "benutzername_label";
            this.benutzername_label.Size = new System.Drawing.Size(139, 25);
            this.benutzername_label.TabIndex = 0;
            this.benutzername_label.Text = "Benutzername";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.Color.Black;
            this.linkLabel1.Location = new System.Drawing.Point(280, 114);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(103, 13);
            this.linkLabel1.TabIndex = 10;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Passwort-Vergessen";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(539, 195);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_links);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Login";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.panel_links.ResumeLayout(false);
            this.panel_links.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bild_augezu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bild_augeoffen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label login_überschrift;
        private System.Windows.Forms.Panel panel_links;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button login_button;
        private System.Windows.Forms.TextBox password_textBox;
        private System.Windows.Forms.TextBox benutzername_textBox;
        private System.Windows.Forms.Label passwort_label;
        private System.Windows.Forms.Label benutzername_label;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.PictureBox bild_augezu;
        private System.Windows.Forms.PictureBox bild_augeoffen;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}