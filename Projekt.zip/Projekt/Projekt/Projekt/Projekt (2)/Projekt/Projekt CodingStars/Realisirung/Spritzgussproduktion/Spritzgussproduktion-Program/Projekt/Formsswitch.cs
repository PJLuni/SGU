﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt
{
    class Formsswitch

    {
       
        public static void hauptmenü(string Benutzer )
        {
            
            Hauptmenü hauptmenü = new Hauptmenü(Benutzer);
            hauptmenü.Show();
           
        }

        public static void kundeanzeigen(string Benutzer)
        {

            KundeAnzeigen kundeAnzeigen = new KundeAnzeigen(Benutzer);
            kundeAnzeigen.Show();

        }
        public static void kundelöschen(string Benutzer)
        {
            KundeLöschen kundeLöschen = new KundeLöschen(Benutzer);
            kundeLöschen.Show();
        }

        public static void kundebearbeiten(string Benutzer)
        {
            KundeBearbeiten kundeBearbeiten = new KundeBearbeiten(Benutzer);
            kundeBearbeiten.Show();

        }
        public static void kundeerstellen(string Benutzer)
        {
            KundenErstellen kundenErstellen = new KundenErstellen(Benutzer);
            kundenErstellen.Show();
        }
        public static void logout()
        {
            Login login = new Login();
            login.Show();
        }
    }
}
