﻿namespace Projekt
{
    partial class KundeBearbeiten
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KundeBearbeiten));
            this.such_panel = new System.Windows.Forms.Panel();
            this.alleanzeigen_button = new System.Windows.Forms.Button();
            this.kunde_label = new System.Windows.Forms.Label();
            this.suchen_button = new System.Windows.Forms.Button();
            this.suchen_textBox = new System.Windows.Forms.TextBox();
            this.gefundendeitems_label = new System.Windows.Forms.Label();
            this.kunden_listBox = new System.Windows.Forms.ListBox();
            this.kundebearbeiten_label = new System.Windows.Forms.Label();
            this.such_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // such_panel
            // 
            this.such_panel.Controls.Add(this.alleanzeigen_button);
            this.such_panel.Controls.Add(this.kunde_label);
            this.such_panel.Controls.Add(this.suchen_button);
            this.such_panel.Controls.Add(this.suchen_textBox);
            this.such_panel.Controls.Add(this.gefundendeitems_label);
            this.such_panel.Controls.Add(this.kunden_listBox);
            this.such_panel.Location = new System.Drawing.Point(181, 121);
            this.such_panel.Name = "such_panel";
            this.such_panel.Size = new System.Drawing.Size(262, 266);
            this.such_panel.TabIndex = 49;
            // 
            // alleanzeigen_button
            // 
            this.alleanzeigen_button.Location = new System.Drawing.Point(35, 237);
            this.alleanzeigen_button.Name = "alleanzeigen_button";
            this.alleanzeigen_button.Size = new System.Drawing.Size(126, 23);
            this.alleanzeigen_button.TabIndex = 50;
            this.alleanzeigen_button.Text = "Alle Kunden Anzeigen";
            this.alleanzeigen_button.UseVisualStyleBackColor = true;
            this.alleanzeigen_button.Click += new System.EventHandler(this.alleanzeigen_button_Click);
            // 
            // kunde_label
            // 
            this.kunde_label.AutoSize = true;
            this.kunde_label.Location = new System.Drawing.Point(111, 20);
            this.kunde_label.Name = "kunde_label";
            this.kunde_label.Size = new System.Drawing.Size(38, 13);
            this.kunde_label.TabIndex = 16;
            this.kunde_label.Text = "Kunde";
            // 
            // suchen_button
            // 
            this.suchen_button.Location = new System.Drawing.Point(141, 214);
            this.suchen_button.Name = "suchen_button";
            this.suchen_button.Size = new System.Drawing.Size(63, 20);
            this.suchen_button.TabIndex = 19;
            this.suchen_button.Text = "Suchen";
            this.suchen_button.UseVisualStyleBackColor = true;
            this.suchen_button.Click += new System.EventHandler(this.suchen_button_Click);
            // 
            // suchen_textBox
            // 
            this.suchen_textBox.Location = new System.Drawing.Point(35, 214);
            this.suchen_textBox.Name = "suchen_textBox";
            this.suchen_textBox.Size = new System.Drawing.Size(100, 20);
            this.suchen_textBox.TabIndex = 18;
            // 
            // gefundendeitems_label
            // 
            this.gefundendeitems_label.AutoSize = true;
            this.gefundendeitems_label.Location = new System.Drawing.Point(34, 242);
            this.gefundendeitems_label.Name = "gefundendeitems_label";
            this.gefundendeitems_label.Size = new System.Drawing.Size(0, 13);
            this.gefundendeitems_label.TabIndex = 49;
            // 
            // kunden_listBox
            // 
            this.kunden_listBox.FormattingEnabled = true;
            this.kunden_listBox.Location = new System.Drawing.Point(35, 59);
            this.kunden_listBox.Name = "kunden_listBox";
            this.kunden_listBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.kunden_listBox.Size = new System.Drawing.Size(169, 147);
            this.kunden_listBox.TabIndex = 17;
            // 
            // kundebearbeiten_label
            // 
            this.kundebearbeiten_label.AutoSize = true;
            this.kundebearbeiten_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kundebearbeiten_label.Location = new System.Drawing.Point(245, 56);
            this.kundebearbeiten_label.Name = "kundebearbeiten_label";
            this.kundebearbeiten_label.Size = new System.Drawing.Size(185, 25);
            this.kundebearbeiten_label.TabIndex = 51;
            this.kundebearbeiten_label.Text = "Kunde-Bearbeiten";
            // 
            // KundeBearbeiten
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(621, 408);
            this.Controls.Add(this.such_panel);
            this.Controls.Add(this.kundebearbeiten_label);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "KundeBearbeiten";
            this.Text = "KundeBearbeiten";
            this.Load += new System.EventHandler(this.KundeBearbeiten_Load);
            this.such_panel.ResumeLayout(false);
            this.such_panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel such_panel;
        private System.Windows.Forms.Label kunde_label;
        private System.Windows.Forms.Button suchen_button;
        private System.Windows.Forms.TextBox suchen_textBox;
        private System.Windows.Forms.ListBox kunden_listBox;
        private System.Windows.Forms.Label gefundendeitems_label;
        private System.Windows.Forms.Label kundebearbeiten_label;
        private System.Windows.Forms.Button alleanzeigen_button;
    }
}