﻿namespace Projekt
{
    partial class KundeAnzeigen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KundeAnzeigen));
            this.kundenanzeigen_dataGridView = new System.Windows.Forms.DataGridView();
            this.Kundeanzeigen_label = new System.Windows.Forms.Label();
            this.suchen_textBox = new System.Windows.Forms.TextBox();
            this.suchen_button = new System.Windows.Forms.Button();
            this.zurück_button = new System.Windows.Forms.Button();
            this.alleanzeigen_button = new System.Windows.Forms.Button();
            this.gefundene_kunden_label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.kundenanzeigen_dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // kundenanzeigen_dataGridView
            // 
            this.kundenanzeigen_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kundenanzeigen_dataGridView.Location = new System.Drawing.Point(12, 83);
            this.kundenanzeigen_dataGridView.Name = "kundenanzeigen_dataGridView";
            this.kundenanzeigen_dataGridView.Size = new System.Drawing.Size(536, 222);
            this.kundenanzeigen_dataGridView.TabIndex = 3;
            // 
            // Kundeanzeigen_label
            // 
            this.Kundeanzeigen_label.AutoSize = true;
            this.Kundeanzeigen_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Kundeanzeigen_label.Location = new System.Drawing.Point(197, 26);
            this.Kundeanzeigen_label.Name = "Kundeanzeigen_label";
            this.Kundeanzeigen_label.Size = new System.Drawing.Size(183, 25);
            this.Kundeanzeigen_label.TabIndex = 4;
            this.Kundeanzeigen_label.Text = "Kunden-Anzeigen";
            // 
            // suchen_textBox
            // 
            this.suchen_textBox.Location = new System.Drawing.Point(12, 311);
            this.suchen_textBox.Name = "suchen_textBox";
            this.suchen_textBox.Size = new System.Drawing.Size(100, 20);
            this.suchen_textBox.TabIndex = 9;
            // 
            // suchen_button
            // 
            this.suchen_button.Location = new System.Drawing.Point(130, 311);
            this.suchen_button.Name = "suchen_button";
            this.suchen_button.Size = new System.Drawing.Size(75, 20);
            this.suchen_button.TabIndex = 10;
            this.suchen_button.Text = "Suchen";
            this.suchen_button.UseVisualStyleBackColor = true;
            this.suchen_button.Click += new System.EventHandler(this.suchen_button_Click);
            // 
            // zurück_button
            // 
            this.zurück_button.Location = new System.Drawing.Point(473, 310);
            this.zurück_button.Name = "zurück_button";
            this.zurück_button.Size = new System.Drawing.Size(75, 23);
            this.zurück_button.TabIndex = 11;
            this.zurück_button.Text = "Zurück";
            this.zurück_button.UseVisualStyleBackColor = true;
            this.zurück_button.Visible = false;
            this.zurück_button.Click += new System.EventHandler(this.zurück_button_Click);
            // 
            // alleanzeigen_button
            // 
            this.alleanzeigen_button.Location = new System.Drawing.Point(224, 309);
            this.alleanzeigen_button.Name = "alleanzeigen_button";
            this.alleanzeigen_button.Size = new System.Drawing.Size(218, 24);
            this.alleanzeigen_button.TabIndex = 12;
            this.alleanzeigen_button.Text = "Alle Kunden Anzeigen";
            this.alleanzeigen_button.UseVisualStyleBackColor = true;
            this.alleanzeigen_button.Click += new System.EventHandler(this.alleanzeigen_button_Click);
            // 
            // gefundene_kunden_label
            // 
            this.gefundene_kunden_label.AutoSize = true;
            this.gefundene_kunden_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gefundene_kunden_label.Location = new System.Drawing.Point(12, 343);
            this.gefundene_kunden_label.Name = "gefundene_kunden_label";
            this.gefundene_kunden_label.Size = new System.Drawing.Size(0, 16);
            this.gefundene_kunden_label.TabIndex = 13;
            // 
            // KundeAnzeigen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(668, 416);
            this.Controls.Add(this.gefundene_kunden_label);
            this.Controls.Add(this.alleanzeigen_button);
            this.Controls.Add(this.zurück_button);
            this.Controls.Add(this.suchen_button);
            this.Controls.Add(this.suchen_textBox);
            this.Controls.Add(this.Kundeanzeigen_label);
            this.Controls.Add(this.kundenanzeigen_dataGridView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "KundeAnzeigen";
            this.Text = "KundeAnzeigen";
            this.Load += new System.EventHandler(this.KundeAnzeigen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kundenanzeigen_dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView kundenanzeigen_dataGridView;
        private System.Windows.Forms.Label Kundeanzeigen_label;
        private System.Windows.Forms.TextBox suchen_textBox;
        private System.Windows.Forms.Button suchen_button;
        private System.Windows.Forms.Button zurück_button;
        private System.Windows.Forms.Button alleanzeigen_button;
        private System.Windows.Forms.Label gefundene_kunden_label;
    }
}