﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt
{
    public partial class KundenErstellen : Form
    {

        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Datenbank.accdb");
        DataSet ds = new DataSet();
        OleDbDataReader dr = null;
        OleDbCommand cmd = null;
        string Benutzer;
        public KundenErstellen(string Benutzer)
        {
          
            this.Benutzer = Benutzer;
            InitializeComponent();
        }
        
        private void hauptmenü_button_Click(object sender, EventArgs e)
        {
            Formsswitch.hauptmenü(Benutzer);
            Hide();
        }

        public void AutoCompleteList()
        {
            AutoCompleteStringCollection colValues = new AutoCompleteStringCollection();
            colValues.AddRange(new string[] { "Deutschland" });

           
            //AutoCompleteMode wird auf SuggestAppend gestellt damit er sich verhält wie das altbekannte "Ausführen Fenster"
           Land_textBox.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            // Damit die Textbox die oben definierte Liste empfangen kann muss der SourceTyp noch auf CustomSource gestellt werden.
            Land_textBox.AutoCompleteSource = AutoCompleteSource.CustomSource;

            // Liste anhängen ...
            Land_textBox.AutoCompleteCustomSource = colValues;

           Land_textBox.Size = new Size(200, 23);
            
        }

        private void KundenErstellen_Load(object sender, EventArgs e)
        {
            AutoCompleteList();

            cmd = new OleDbCommand("SELECT count(Nr) FROM Kunde", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            long Anzahl = dr.GetInt32(0);
            con.Close();
           
            if (Anzahl > 0)
            {
                cmd = new OleDbCommand("SELECT Max(Nr) FROM Kunde", con);
                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                Nr_textBox.Text = Convert.ToString(dr.GetInt32(0) + 1);
                con.Close();
            }
            else
            {
                Nr_textBox.Text = "1";
            }
            Nr_textBox.ReadOnly = true;
        }

        private void Nr_textBox_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Nr_textBox.ReadOnly = false;
        }

        private void Kundeanzeigen_button_Click(object sender, EventArgs e)
        {
            Formsswitch.kundeanzeigen(Benutzer);
            Hide();
        }

        private void Speichern_button_Click(object sender, EventArgs e)
        {
            if (bezeichnung_textBox.TextLength!=0)
            {
                con.Open();
                cmd = new OleDbCommand("Insert into Kunde (Nr, Bezeichnung, Telefon, Email, Fax, PLZ, Ort, Straße, Land, Anmerkung, IstAktiv) values ('" + Nr_textBox.Text + "', '" + bezeichnung_textBox.Text + "', '" + Telefon_textBox.Text + "','" + Email_textBox.Text + "','" + Fax_textBox.Text + "', '" + PLZ_textBox.Text + "', '" + Ort_textBox.Text + "','" + Straße_textBox.Text + "' , '" + Land_textBox.Text + "','" + Anmerkung_textBox.Text + "', " + IstAktiv_checkBox.Checked + ")", con);

                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Neuer Kunde wurde erstellt!");


                DialogResult benutzerentscheidung = MessageBox.Show("Wollen Sie noch einen Kunden Erstellen?", "Abfrage", MessageBoxButtons.YesNo);

            if (benutzerentscheidung == DialogResult.Yes)
            {
                cmd = new OleDbCommand("SELECT count(Nr) FROM Kunde", con);
                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                long Anzahl = dr.GetInt32(0);
                con.Close();

                if (Anzahl > 0)
                {
                    cmd = new OleDbCommand("SELECT Max(Nr) FROM Kunde", con);
                    con.Open();
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    Nr_textBox.Text = Convert.ToString(dr.GetInt32(0) + 1);
                    con.Close();
                }
                else
                {
                    Nr_textBox.Text = "1";
                }
            }
            else
            {
                Formsswitch.hauptmenü(Benutzer);
                this.Close();
            }
            }
            else
            { 
                MessageBox.Show("Gebne sie bitte eine Beziechnung für ihren Kunden ein!");
            }

            
        }
    }
}
