﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Ansprechpartner : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        DataSet ds = new DataSet();
        OleDbDataAdapter adapter = null;
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader dr = null;

        List<string> AngemeldeterMitarbeiter;

        public Ansprechpartner(List<string> AngemeldeterMitarbeiter)
        {
            this.AngemeldeterMitarbeiter = AngemeldeterMitarbeiter;
            InitializeComponent();
        }
        //Zurückbutton
        private void button2_Click(object sender, EventArgs e)
        {
            try { 
            Lieferantenverwaltung lieferantenverwaltung = new Lieferantenverwaltung(AngemeldeterMitarbeiter);
            lieferantenverwaltung.Show();
                Hide();
            }
            catch { MessageBox.Show("Fehler beim öffnen der Lieferantenverwaltung"); }
        }

        private void Ansprechpartner_Load(object sender, EventArgs e)
        {
            OleDbDataAdapter Name = new OleDbDataAdapter("SELECT * from Ansprechpartner ", con);

            ds.Clear();
            Name.Fill(ds, "Ansprechpartnerfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Ansprechpartnerfilter";
           
        }
        //Aktualisierenbutton
        private void button5_Click(object sender, EventArgs e)
        {
            Ansprechpartner ansprechpartnerform = new Ansprechpartner(AngemeldeterMitarbeiter);
            ansprechpartnerform.Show();
            ansprechpartnerform.Close();

            Ansprechpartner ansprechpartnerform2 = new Ansprechpartner(AngemeldeterMitarbeiter);
            ansprechpartnerform2.Show();

            Hide();
        }
        //Änderenbutton
        private void button6_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["ApNr"].Value.ToString();

            cmd= new OleDbCommand("update Ansprechpartner set ApName = '" + dataGridView1.CurrentRow.Cells["ApName"].Value.ToString() + "', ApDurchwahl = '" + dataGridView1.CurrentRow.Cells["ApDurchwahl"].Value.ToString() + "' where ApNr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Geändert. Gehen sie jz auf Aktualisieren!");
        }
        //Hinzufügenformbutton
        private void button7_Click(object sender, EventArgs e)
        {
            Ansprechpartnerhinzufügen ansprechpartnerhinzufügen = new Ansprechpartnerhinzufügen(AngemeldeterMitarbeiter);
            ansprechpartnerhinzufügen.Show();
            Hide();
        }
        //Löschen
        private void button4_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["ApNr"].Value.ToString();

            cmd = new OleDbCommand("DELETE * FROM Ansprechpartner WHERE ApNr= "+ Ausgewähltezelle +"", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Gelöscht. Gehen sie jz auf Aktualisieren!");
        }
    }
}
