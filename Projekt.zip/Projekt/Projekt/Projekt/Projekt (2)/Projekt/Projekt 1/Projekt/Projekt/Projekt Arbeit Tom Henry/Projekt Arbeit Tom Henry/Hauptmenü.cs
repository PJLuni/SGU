﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Hauptmenü : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        DataSet ds = new DataSet();
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;

        List<string> AM;

        public Hauptmenü(List<string> AM)
        {
            this.AM = AM;
            InitializeComponent();
        }
        
        // Kontrolieren ob Rechteactive = true und Anzeigen der Artikelverwaltung
        private void button3_Click(object sender, EventArgs e)
        {
            string AngemeldeterM;

            //Befühlen des Labels für Kontrolle der Rechte
            AngemeldeterM =  label3.Text;

            cmd = new OleDbCommand("SELECT MReNr FROM Mitarbeiter where MBenutzername ='" + AngemeldeterM +"'", con);

            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            int AnmelderMit = dr.GetInt32(0);
            con.Close();

            cmd = new OleDbCommand("SELECT ReCanArtikel FROM Rechte where ReNr =" + AnmelderMit + "", con);

            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            bool AActive = dr.GetBoolean(0);
            con.Close();

            if (AActive==true) {
            Artikelverwaltung artikelverwaltung = new Artikelverwaltung(AM,AngemeldeterM);
            artikelverwaltung.Show();

            Hide();
            }
            else { MessageBox.Show("Fehler"); }

            button3.Enabled = true;
        }

        //Abmeldung des eingelogten Mitarbeiters
        private void button1_Click(object sender, EventArgs e)
        {
                Login login = new Login();
                login.Show();
                this.Hide();
        }
        // Kontrolieren ob Rechteactive = true und Anzeigen der Mitarbeiterverwaltung
        private void button4_Click(object sender, EventArgs e)
        {
            string AngemeldeterM;
            AngemeldeterM = label3.Text;


            cmd = new OleDbCommand("SELECT MReNr FROM Mitarbeiter where MBenutzername ='" + AngemeldeterM + "'", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            int AnmelderMit = dr.GetInt32(0);
            con.Close();

            cmd = new OleDbCommand("SELECT ReCanMitarbeiter FROM Rechte where ReNr =" + AnmelderMit + "", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            bool AActive = dr.GetBoolean(0);
            con.Close();

            if (AActive == true)
            {
                 Mitarbeiterverwaltung mitarbeiterverwaltung = new Mitarbeiterverwaltung(AM);
            mitarbeiterverwaltung.Show();
            this.Hide();
            }
            else { MessageBox.Show("Fehler"); }
            button4.Enabled = true;
           
        }
        // Anzeigen der Lieferantenverwaltung
        private void button5_Click(object sender, EventArgs e)
        {
            Lieferantenverwaltung lieferantenverwaltung = new Lieferantenverwaltung(AM);
            lieferantenverwaltung.Show();
            this.Hide();
        }

        // Anzeigen der Lagerverwaltung
        private void button6_Click(object sender, EventArgs e)
        {
            Lagerverwaltung lagerverwaltung = new Lagerverwaltung(AM);
            lagerverwaltung.Show();
            this.Hide();
        }

        // Schließen des gesamtenprogrammes
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        // Anzeigen der Materialentnahmescheinverwaltung
        private void button8_Click(object sender, EventArgs e)
        {
            Materialentnahmeschein materialentnahmeschein = new Materialentnahmeschein(AM);
            materialentnahmeschein.Show();
            this.Hide();
        }

        // Anzeigen der Lieferscheinverwaltung
        private void button7_Click(object sender, EventArgs e)
        {
            Lieferscheinverwaltung lieferscheinverwaltung = new Lieferscheinverwaltung(AM);
            lieferscheinverwaltung.Show();
            this.Hide();
        }

        // Anzeigen der Artikel mit unterschrittenem Meldebestand
        private void Hauptmenü_Load(object sender, EventArgs e)
        {
            label3.Text = Convert.ToString(AM[0]);
            try
            {
           
                { 

                OleDbDataAdapter Name = new OleDbDataAdapter("SELECT ArtBez, ArtMeldebestand, ArtAktuellerbestand  FROM Artikel WHERE ArtMeldebestand > ArtAktuellerbestand ", con);

                ds.Clear();
                Name.Fill(ds, "Lieferantenfilter");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Lieferantenfilter";


                }
            }
            catch { MessageBox.Show("Fehler"); }
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Einheit einheit = new Einheit(AM);
            einheit.Show();
            Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Kostenstelle kostenstelle = new Kostenstelle(AM);
            kostenstelle.Show();
            Hide();
        }

        private void button11_Click(object sender, EventArgs e)
        {

            string AngemeldeterM;
            AngemeldeterM = label3.Text;


            cmd = new OleDbCommand("SELECT MReNr FROM Mitarbeiter where MBenutzername ='" + AngemeldeterM + "'", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            int AnmelderMit = dr.GetInt32(0);
            con.Close();

            cmd = new OleDbCommand("SELECT ReCanRechte FROM Rechte where ReNr =" + AnmelderMit + "", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            bool AActive = dr.GetBoolean(0);
            con.Close();

            if (AActive == true)
            {
                Rechte rechte = new Rechte(AM);
                rechte.Show();
                Hide();
            }
            else { MessageBox.Show("Fehler"); }
            button11.Enabled = true;

        }
       
    }
}
