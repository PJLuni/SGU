﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Kostenstelle : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        DataSet ds = new DataSet();
        List<string> AngemeldeterMitarbeiter;

        public Kostenstelle(List<string> AngemeldeterMitarbeiter)
        {
            this.AngemeldeterMitarbeiter = AngemeldeterMitarbeiter;
            InitializeComponent();
        }

        //Hauptmenü
        private void button2_Click(object sender, EventArgs e)
        {
            Hauptmenü hauptmenü = new Hauptmenü(AngemeldeterMitarbeiter);
            hauptmenü.Show();
            Hide();
        }

        //Kostenstellehinzufügen
        private void button1_Click(object sender, EventArgs e)
        {
            Kostenstellehinzufügen kostenstellehinzufügen = new Kostenstellehinzufügen(AngemeldeterMitarbeiter);
            kostenstellehinzufügen.Show();
            Hide();
        }

        private void Kostenstelle_Load(object sender, EventArgs e)
        {
         try{
                 
                OleDbDataAdapter Name = new OleDbDataAdapter("SELECT * from Kostenstelle ", con);

                ds.Clear();
                Name.Fill(ds, "Kostenstellefilter");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Kostenstellefilter";

            }
            catch { MessageBox.Show("Fehler"); }
        }

        //Aktualisieren
        private void button5_Click(object sender, EventArgs e)
        {
            Kostenstelle kostenstelle = new Kostenstelle(AngemeldeterMitarbeiter);
            kostenstelle.Show();
            kostenstelle.Close();

            Kostenstelle kostenstelle2 = new Kostenstelle(AngemeldeterMitarbeiter);
            kostenstelle2.Show();

            Hide();
        }
        //Ändern
        private void button7_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["KsNr"].Value.ToString();

            OleDbDataAdapter Name = new OleDbDataAdapter("update Kostenstelle set KsBez ='" + dataGridView1.CurrentRow.Cells["KsBez"].Value.ToString() + "', KsIsActive =" + dataGridView1.CurrentRow.Cells["KsIsActive"].Value.ToString() + " where KsNr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);

            ds.Clear();
            Name.Fill(ds, "U_Kostenstellefilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "U_Kostenstellefilter";

            MessageBox.Show("Geändert. Gehen sie jz auf Aktualisieren!");
        }
        //Löschen
        private void button6_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["KsNr"].Value.ToString();

            OleDbDataAdapter Name = new OleDbDataAdapter("delete * from Kostenstelle where KsNr = " + Ausgewähltezelle + "", con);

            ds.Clear();
            Name.Fill(ds, "L_Kostenstellefilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "L_Kostenstellefilter";

            MessageBox.Show("Gelöscht. Gehen sie jz auf Aktualisieren!");

        }

        private void button8_Click(object sender, EventArgs e)
        {
            Kostenstellehinzufügen kostenstellehinzufügen = new Kostenstellehinzufügen(AngemeldeterMitarbeiter);
            kostenstellehinzufügen.Show();
            Hide();
        }
    }
}
