﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Lagerverwaltung : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        DataSet ds = new DataSet();
        List<string> AngemeldeterMitarbeiter;

        public Lagerverwaltung(List<string> AngemeldeterMitarbeiter)
        {
            this.AngemeldeterMitarbeiter = AngemeldeterMitarbeiter;
            InitializeComponent();
        }

        // Zu Lagerhinzufügen
        private void button1_Click(object sender, EventArgs e)
        {
            Lagerhinzufügen lagerhinzufügen = new Lagerhinzufügen(AngemeldeterMitarbeiter);
            lagerhinzufügen.Show();
            this.Hide();
        }
        // Befühlen des Datagridviews
        private void Lagerverwaltung_Load(object sender, EventArgs e)
        {
            try
            {
                OleDbDataAdapter Name = new OleDbDataAdapter("Select * from Lager ", con);

                ds.Clear();
                Name.Fill(ds, "Lagerfilter");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Lagerfilter";
                
            }
            catch { MessageBox.Show("Fehler"); }
        }

        // zurück zum Hauptmenü
        private void button2_Click(object sender, EventArgs e)
        {
            Hauptmenü hauptmenü = new Hauptmenü(AngemeldeterMitarbeiter);
            hauptmenü.Show();
            Hide();
        }

            // Aktualisieren des Datagridviews in der Lagerverwaltung
        private void button5_Click(object sender, EventArgs e)
        {
            Lagerverwaltung lagerverwaltung = new Lagerverwaltung(AngemeldeterMitarbeiter);
            lagerverwaltung.Show();
            lagerverwaltung.Close();

            Lagerverwaltung lagerverwaltung2 = new Lagerverwaltung(AngemeldeterMitarbeiter);
            lagerverwaltung2.Show();

            Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["LaNr"].Value.ToString();
            //LagerIsActive noch zu bearbeiten


            OleDbDataAdapter Name = new OleDbDataAdapter("update Lager set LaBez ='" + dataGridView1.CurrentRow.Cells["LaBez"].Value.ToString() + "', LaIsActive =" + dataGridView1.CurrentRow.Cells["LaIsActive"].Value.ToString() + " where LaNr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);

            ds.Clear();
            Name.Fill(ds, "U_Lagerfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "U_Lagerfilter";

            MessageBox.Show("Geändert. Gehen sie jz auf Aktualisieren!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["LaNr"].Value.ToString();

            OleDbDataAdapter Name = new OleDbDataAdapter("delete * from Lager where LaNr = " + Ausgewähltezelle + "", con);
            ds.Clear();
            Name.Fill(ds, "Lagerfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Lagerfilter";

            MessageBox.Show("Gelöscht. Gehen sie jz auf Aktualisieren!");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Lagerhinzufügen lagerhinzufügen = new Lagerhinzufügen(AngemeldeterMitarbeiter);
            lagerhinzufügen.Show();
            Hide();
        }
    }
}
