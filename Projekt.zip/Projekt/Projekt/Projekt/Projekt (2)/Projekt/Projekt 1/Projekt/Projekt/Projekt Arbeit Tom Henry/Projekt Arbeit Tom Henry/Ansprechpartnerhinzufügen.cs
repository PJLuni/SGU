﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Ansprechpartnerhinzufügen : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        OleDbDataReader dr = null;
        OleDbCommand cmd = null;
        List<string> AngemeldeterMitarbeiter;
        
        public Ansprechpartnerhinzufügen(List<string> AngemeldeterMitarbeiter)
        {
            this.AngemeldeterMitarbeiter = AngemeldeterMitarbeiter;
            InitializeComponent();
        }

        //Zurückbutton
        private void button2_Click(object sender, EventArgs e)
        {
            Lieferantenverwaltung lieferantenverwaltung = new Lieferantenverwaltung(AngemeldeterMitarbeiter);
            lieferantenverwaltung.Show();

            Hide();
        }

        //Speichern und Zurück
        private void button1_Click(object sender, EventArgs e)
        {
            Ansprechpartner ansprechpartner = new Ansprechpartner(AngemeldeterMitarbeiter);
            ansprechpartner.Show();
            Hide();

            con.Open();

            cmd = new OleDbCommand("Insert into Ansprechpartner (ApNr, ApLrNr, ApName, ApDurchwahl, ApIsActive) values ('" + textBox1.Text + "', '" + listBox1.SelectedItem + "', '" + textBox2.Text + "', '" + textBox3.Text + "', " + checkBox1.Checked +")", con);
            cmd.ExecuteNonQuery();
            con.Close();
           
        }

        private void Ansprechpartnerhinzufügen_Load(object sender, EventArgs e)
        {
            con.Open();
            cmd = new OleDbCommand("select * from Lieferant", con);

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                listBox1.Items.Add(dr.GetInt32(0));
            }

            con.Close();
            //Hochzählen der ApNr
            cmd = new OleDbCommand("SELECT count(MatsNr) FROM Mats", con);
            con.Open();

            dr = cmd.ExecuteReader();
            dr.Read();
            int Anzahl = dr.GetInt32(0);
            con.Close();

            if (Anzahl > 0)
            {
                cmd = new OleDbCommand("SELECT Max(MatsNr) FROM Mats", con);
                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox1.Text = Convert.ToString(dr.GetInt32(0) + 1);
                con.Close();
            }
            else
            {
                textBox1.Text = "1";
            }
        }
        //Befühlen des Labels
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label6.Visible = true;
            con.Open();
            int vergleich = Convert.ToInt32(listBox1.SelectedItem.ToString());

            cmd = new OleDbCommand("select LrName from Lieferant where LrNr=" + vergleich, con);
       
            dr = cmd.ExecuteReader();
            dr.Read();
            string LrName = dr.GetString(0);

            label6.Text = LrName;
            
            con.Close();
        }
    }
}
