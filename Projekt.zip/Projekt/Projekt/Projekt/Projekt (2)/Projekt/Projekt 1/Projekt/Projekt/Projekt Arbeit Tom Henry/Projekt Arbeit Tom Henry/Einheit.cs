﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Einheit : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        DataSet ds = new DataSet();
        List<string> AngemeldeterMitarbeiter;

        public Einheit(List<string> AngemeldeterMitarbeiter)
        {
            this.AngemeldeterMitarbeiter = AngemeldeterMitarbeiter;
            InitializeComponent();
        }
        //Zurück
        private void button2_Click(object sender, EventArgs e)
        {
            Hauptmenü hauptmenü = new Hauptmenü(AngemeldeterMitarbeiter);
            hauptmenü.Show();
            Hide();
        }
        //Datagridview befühllen
        private void Einheit_Load(object sender, EventArgs e)
        {
            try
            {
                OleDbDataAdapter Adapter = new OleDbDataAdapter("Select * from Einheit", con);

                ds.Clear();
                Adapter.Fill(ds, "Einheitfilter");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Einheitfilter";
            }
            catch
            {
                MessageBox.Show("Fehler beim Befühllen");
            }
        }

        //Zu einheithinzufügenform
        private void button1_Click(object sender, EventArgs e)
        {
            Einheithinzufügen einheithinzufügen = new Einheithinzufügen(AngemeldeterMitarbeiter);
            einheithinzufügen.Show();
            Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Einheit Einheitform = new Einheit(AngemeldeterMitarbeiter);
            Einheitform.Show();
            Einheitform.Close();

            Einheit Einheitform2 = new Einheit(AngemeldeterMitarbeiter);
            Einheitform2.Show();

            Hide();
        }
        //Ändernbutton
        private void button7_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["EhNr"].Value.ToString();
           


            OleDbDataAdapter Name = new OleDbDataAdapter("update Einheit set EhBez ='" + dataGridView1.CurrentRow.Cells["EhBez"].Value.ToString() + "', EhIsActive =" + dataGridView1.CurrentRow.Cells["EhIsActive"].Value.ToString() + " where EhNr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);

            ds.Clear();
            Name.Fill(ds, "U_Einheitfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "U_Einheitfilter";

            MessageBox.Show("Geändert. Gehen sie jz auf Aktualisieren!");
        }
        //Löschenbutton
        private void button6_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["EhNr"].Value.ToString();

            OleDbDataAdapter Name = new OleDbDataAdapter("delete * from Einheit where EhNr = " + Ausgewähltezelle + "", con);
            ds.Clear();
            Name.Fill(ds, "Einheitfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Einheitfilter";

            MessageBox.Show("Gelöscht. Gehen sie jz auf Aktualisieren!");
        }

        //Zu Einheithinzufügenform
        private void button8_Click(object sender, EventArgs e)
        {
            Einheithinzufügen einheithinzufügen = new Einheithinzufügen(AngemeldeterMitarbeiter);
            einheithinzufügen.Show();
            Hide();
        }

    }
}
