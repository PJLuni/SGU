﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Mitarbeiterverwaltung : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        DataSet ds = new DataSet();
        List<string> AM;
        public Mitarbeiterverwaltung(List<string> AM)
        {
            this.AM = AM;
            InitializeComponent();
        }

        private void Mitarbeiterverwaltung_Load(object sender, EventArgs e)
        {
            try
            {

                OleDbDataAdapter Name = new OleDbDataAdapter("Select * from Mitarbeiter ", con);


                ds.Clear();
                Name.Fill(ds, "Mitarbeiterfilter");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Mitarbeiterfilter";


            }
            catch { MessageBox.Show("Fehler"); }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Hauptmenü hauptmenü = new Hauptmenü(AM);
            hauptmenü.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mitarbeiterhinzufügen mitarbeiterhinzufügen = new Mitarbeiterhinzufügen(AM);
            mitarbeiterhinzufügen.Show();
            Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Mitarbeiterverwaltung mitarbeiterverwaltung = new Mitarbeiterverwaltung(AM);
            mitarbeiterverwaltung.Show();
            mitarbeiterverwaltung.Close();

            Mitarbeiterverwaltung mitarbeiterverwaltung2 = new Mitarbeiterverwaltung(AM);
            mitarbeiterverwaltung2.Show();

            Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string s9 = dataGridView1.CurrentRow.Cells["MNr"].Value.ToString();
            //ApIsActive noch zu bearbeiten


            OleDbDataAdapter Name = new OleDbDataAdapter("update Mitarbeiter set MName = '" + dataGridView1.CurrentRow.Cells["MName"].Value.ToString() + "', MVorname= '" + dataGridView1.CurrentRow.Cells["MVorname"].Value.ToString() + "', MPasswort= '" + dataGridView1.CurrentRow.Cells["MPasswort"].Value.ToString()+ "' , MBenutzername= '" + dataGridView1.CurrentRow.Cells["MBenutzername"].Value.ToString()+ "' , MAbtNr= '" + dataGridView1.CurrentRow.Cells["MAbtNr"].Value.ToString()+ "' , MReNr= '" + dataGridView1.CurrentRow.Cells["MReNr"].Value.ToString()+ "', MIsActive = " + dataGridView1.CurrentRow.Cells["MIsActive"].Value.ToString() + " where MNr = " + System.Convert.ToInt64(s9) + "", con);

            ds.Clear();
            Name.Fill(ds, "Mitarbeiterfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Mitarbeiterfilter";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string s9 = dataGridView1.CurrentRow.Cells["MNr"].Value.ToString();

            OleDbDataAdapter Name = new OleDbDataAdapter("delete * from Mitarbeiter where MNr = " + s9 + "", con);
            ds.Clear();
            Name.Fill(ds, "Mitarbeiterfilter");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Mitarbeiterfilter";

            MessageBox.Show("Gelöscht. Gehen sie jz auf Aktualisieren!");
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Mitarbeiterhinzufügen mitarbeiterhinzufügen = new Mitarbeiterhinzufügen(AM);
            mitarbeiterhinzufügen.Show();
            Hide();
        }
    }
}
