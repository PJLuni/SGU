﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Projekt_Arbeit_Tom_Henry
{
    public partial class Lieferscheinverwaltung : Form
    {
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source= Project.accdb");
        OleDbDataReader dr = null;
        OleDbCommand cmd = null;
        DataSet ds = new DataSet();

        DataSet ds2 = new DataSet();
       
        List<string> AM;
        public Lieferscheinverwaltung(List<string> AM)
        {
            this.AM = AM;
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hauptmenü hauptmenü = new Hauptmenü(AM);
            hauptmenü.Show();
            this.Hide();
        }
        //Befühlen der Datagriedview und Listboxen
        private void Lieferscheinverwaltung_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbDataAdapter adapter = new OleDbDataAdapter("Select * from Lrs ", con);

                ds2.Clear();
                adapter.Fill(ds2, "Lrsfilter");
                dataGridView1.DataSource = ds2;
                dataGridView1.DataMember = "Lrsfilter";
                con.Close();

                con.Open();

                cmd = new OleDbCommand("select * from Lieferant", con);

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetInt32(0));
                }
                con.Close();
                con.Open();
                cmd = new OleDbCommand("select * from Ansprechpartner", con);

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    listBox2.Items.Add(dr.GetInt32(0));
                }
                con.Close();
                con.Open();
                cmd = new OleDbCommand("select * from Mitarbeiter", con);

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    listBox3.Items.Add(dr.GetInt32(0));
                }
                con.Close();
                con.Open();


                cmd = new OleDbCommand("select * from Lrs", con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    listBox4.Items.Add(dr.GetInt32(0));
                }
                con.Close();
                
                con.Open();
                cmd = new OleDbCommand("select * from Artikel", con);

                dr = cmd.ExecuteReader();
                
                while (dr.Read())
                {

                    listBox5.Items.Add(dr.GetInt32(0));
                }

                con.Close();
                con.Open();
                adapter = new OleDbDataAdapter("Select * from Lrs2 ", con);

                ds.Clear();
                adapter.Fill(ds, "Lrsfilter2");
                dataGridView2.DataSource = ds;
                dataGridView2.DataMember = "Lrsfilter2";
                con.Close();

            }
            catch { MessageBox.Show("Fehler"); }
            //Hochzählen
            cmd = new OleDbCommand("SELECT count(LrsNr) FROM Lrs", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            int Anzahl = dr.GetInt32(0);
            con.Close();

            if (Anzahl > 0)
            {
                cmd = new OleDbCommand("SELECT Max(LrsNr) FROM Lrs", con);
                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox1.Text = Convert.ToString(dr.GetInt32(0) + 1);
                con.Close();
            }
            else
            {
                textBox1.Text = "1";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Lieferscheinverwaltung lieferscheinverwaltung = new Lieferscheinverwaltung(AM);
            lieferscheinverwaltung.Show();
            lieferscheinverwaltung.Close();

            Lieferscheinverwaltung lieferscheinverwaltung1 = new Lieferscheinverwaltung(AM);
            lieferscheinverwaltung1.Show();
            
            Hide();
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Hauptmenü hauptmenü = new Hauptmenü(AM);
            hauptmenü.Show();

            Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            con.Open();

            cmd = new OleDbCommand("Insert into Lrs (LrsNr, LrsDatum, LrsBemerkung, LrsLrNr, LrsApNr, LrsMNr, LrsIsActive) values ('" + textBox1.Text + "', '" + dateTimePicker1.Value + "', '" + textBox2.Text + "','" + listBox1.SelectedItem + "','" + listBox2.SelectedItem + "', '" + listBox3.SelectedItem + "', " + checkBox1.Checked + ")", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        //Anzeigen Label
        private void listBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            label7.Text = "";
            con.Open();

            int vergleich = Convert.ToInt32(listBox5.SelectedItem.ToString());
            cmd = new OleDbCommand("select ArtAktuellerbestand from Artikel where ArtNr =" + vergleich, con);

            dr = cmd.ExecuteReader();
            dr.Read();

            label7.Text = Convert.ToString(dr.GetInt32(0));
            con.Close();
            label7.Visible = true;
        }
        
        private void button6_Click(object sender, EventArgs e)
        {
            string s9 = dataGridView1.CurrentRow.Cells["LrsNr"].Value.ToString();
            cmd = new OleDbCommand("delete * from Lrs where LrsNr = " + s9 + "", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            
                con.Open();

                cmd = new OleDbCommand("Insert into Lrs2 (Lrs2lrsNr, Lrs2ArtNr, Lrs2Menge, Lrs2Preis, Lrs2Gesamtpreis) values ('" + listBox4.SelectedItem + "', '" + listBox5.SelectedItem + "', '" + textBox4.Text + "', " + textBox5.Text + ", " + textBox3.Text + ")", con);
                cmd.ExecuteNonQuery();
                con.Close();

                cmd = new OleDbCommand("Select ArtAktuellerbestand from Artikel where ArtNr = " + listBox5.SelectedItem + "", con);
                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                int AMenge = dr.GetInt32(0);

                con.Close();

                int Menge = Convert.ToInt32(textBox4.Text);

                con.Close();

                int MengenBerechnung = 0;
                MengenBerechnung = AMenge + Menge;


                string s9 = Convert.ToString(listBox5.SelectedItem);

                cmd = new OleDbCommand("update Artikel set  ArtAktuellerbestand = " + MengenBerechnung + " where ArtNr = " + System.Convert.ToInt64(s9) + "", con);

                con.Open();
                cmd.ExecuteReader();

                con.Close();
            
        }
        // B
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbDataAdapter Name2 = new OleDbDataAdapter("Select * from Lrs2 ", con);

            ds.Clear();
            Name2.Fill(ds, "Lrs2filter");
            dataGridView2.DataSource = ds;
            dataGridView2.DataMember = "Lrs2filter";

            int gesamtpreis = 0;
            int Menge = Convert.ToInt32(textBox4.Text);
            int Preis = Convert.ToInt32(textBox5.Text);

            gesamtpreis = Menge * Preis;
            con.Close();

            textBox3.Text = Convert.ToString(gesamtpreis);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string s9 = dataGridView2.CurrentRow.Cells["Lrs2lrsNr"].Value.ToString();

            cmd = new OleDbCommand("delete * from Lrs2 where Lrs2lrsNr = " + s9 + "", con);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Gelöscht. Gehen sie jz auf Aktualisieren!");
        }
    }
}

