﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class KundeAdd : Form
    {
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        long Kunde;
        TabControl TC;
        TabPage KP;
        public KundeAdd(long Kunde, TabControl TC,TabPage KP)
        {
            this.KP = KP;
            this.TC = TC;
            this.Kunde = Kunde;
            InitializeComponent();
        }
        public void kundehinzufuegen_load(long Kunde)
        {
            label17.Text = "Kunde-Hinzufügen";
            position();
        }
        public void position()
        {
            if (panel1.Visible == false)
            {
                TC.Height = 647;
                button1.Location = new Point(777, 564);
            }
            if (panel2.Visible == false)
            {
                panel1.Location = new Point(21, 374);
                TC.Height = 647;
                button1.Location = new Point(777, 564);
            }
            if (panel2.Visible == true)
            {
                checkBox4.Checked = true;
            }
            if (panel1.Visible==true&&panel2.Visible==true)
            {
                TC.Height = 808;
                button1.Location = new Point(777, 727);
            }
        }
        public void kundebearbeiten_load(long Kunde)
        {
            panel1.Visible = false;
            label17.Text = "Kunde-Bearbeiten";
            cmd = new OleDbCommand("Select * from Kunde where Nr = " + Kunde + "", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            textBox17.Text = Convert.ToString(dr.GetInt32(0));
            textBox1.Text = dr.GetString(1);
            textBox2.Text = dr.GetString(2);
            textBox3.Text = dr.GetString(3);
            textBox4.Text = dr.GetString(4);
            textBox5.Text = Convert.ToString(dr.GetInt32(5));
            textBox6.Text = dr.GetString(6);
            textBox7.Text = dr.GetString(7);
            textBox8.Text = dr.GetString(8);
            checkBox2.Checked = dr.GetBoolean(9);
            con.Close();
            if (panel2.Visible == true)
            {
                checkBox4.Checked = true;
            }
            else
            {
                checkBox4.Visible = true;
            }
            
            try
            {
            ansprechpartnerBefuelen(Kunde);
           
            lieferadresseBefuelen(Kunde);
           
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            position();
        }
        public void lieferadresseBefuelen(long Kunde)
        {
            con.Open();
           OleDbDataAdapter adapp = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "", con);
            
            DataTable dt = new DataTable();
            DataRow d = dt.NewRow();
            adapp.Fill(dt);
            con.Close();
            
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                if (Enumerable.SequenceEqual(dt.Rows[i].ItemArray, d.ItemArray))
                {

                }
                else
                {
                    checkBox1.Checked = false;
                    if (dt.Rows.Count >= 1)
                    {
                        
                        panel1.Visible = true;
                        con.Open();
                          adapp = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "", con);
                       
                        ds.Clear();

                        adapp.Fill(ds, "adresse");

                        dataGridView1.DataSource = ds;
                        dataGridView1.DataMember = "adresse";
                        con.Close();
                        iconButton3.Visible = true;
                    }
                    else
                    {
                       
                    }
                }
            }
           
        }
        public void ansprechpartnerBefuelen(long Kunde)
        {
             con.Open();
            adap = new OleDbDataAdapter("SELECT Ansprechpartner.* from Ansprechpartner, Kunde where Ansprechpartner.Kunde = Kunde.Nr and Ansprechpartner.Kunde = " + Kunde + "", con);
           
            DataTable dt = new DataTable();
            DataRow d = dt.NewRow();
            adap.Fill(dt);
            con.Close();
            
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                if (Enumerable.SequenceEqual(dt.Rows[i].ItemArray, d.ItemArray))
                {
                       
                }
                else
                {
                    if (dt.Rows.Count>=1)
                    {
                       
                    panel2.Visible = true;
                    adap = new OleDbDataAdapter("SELECT Ansprechpartner.* from Ansprechpartner, Kunde where Ansprechpartner.Kunde = Kunde.Nr and Ansprechpartner.Kunde = " + Kunde + "", con);
                    con.Open();
                    ds2.Clear();

                    adap.Fill(ds2, "ansprechpartner");

                    Ansprechpartner.DataSource = ds2;
                    Ansprechpartner.DataMember = "ansprechpartner";
                    con.Close();

                    }
                    else
                    {
                        
                    }
                }
            }
            
        }
        public static void hochzaehlen(string nr,string tabelle,TextBox textBox,Panel panel)
        {
            if (panel.Visible==true)
            {
                edit.nrHochZaehlen(nr, tabelle, textBox);
            }
         
        }
        private void Kunde_Load(object sender, EventArgs e)
        {
            TC.Height = 808;
            
            if (Kunde == 0)
            {
                kundehinzufuegen_load(Kunde);
            }
            else
            {
                kundebearbeiten_load(Kunde);
            }

            lieferdaten.Visible = false;
            if (Kunde==0)
            {
                edit.nrHochZaehlen("Nr", "Kunde", textBox17);
            }

        }
        
        private void iconButton5_Click(object sender, EventArgs e)
        {
            
                string Ausgewähltezelle = Ansprechpartner.CurrentRow.Cells["Nr"].Value.ToString();
                adap = new OleDbDataAdapter("SELECT Distinct Auftrag.Ansprechpartner from Auftrag, Ansprechpartner where Ansprechpartner.Nr = Auftrag.Ansprechpartner and Auftrag.Ansprechpartner =" + Ausgewähltezelle + "", con);
                con.Open();
                DataTable dt = new DataTable();
                DataRow d = dt.NewRow();
                adap.Fill(dt);
                con.Close();

                if (dt.Rows.Count>=1)
                {
                            MessageBox.Show("Sie Können den Ansprechpartner nicht löschen, da er in einem Auftrag vorkommt." +
                            "Löschen oder änderen sie ihren Ansprechpartner im Auftrag um zu löschen!");
                }
                else
                {
                           
                    DialogResult result = MessageBox.Show("Sind Sie sicher das Sie den ausgewählten Ansprechpartner löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)

                    {
                        con.Open();
                        cmd = new OleDbCommand("Update Ansprechpartner set IsActive = false  where Nr = " + Ausgewähltezelle + "", con);
                        dr = cmd.ExecuteReader();
                        dr.Read();
                        con.Close();


                    adap = new OleDbDataAdapter("SELECT Ansprechpartner.* from Ansprechpartner, Kunde where Ansprechpartner.Kunde = Kunde.Nr and Ansprechpartner.Kunde = " + Kunde + "", con);
                    con.Open();
                    ds2.Clear();

                    adap.Fill(ds2, "ansprechpartner");

                    Ansprechpartner.DataSource = ds2;
                    Ansprechpartner.DataMember = "ansprechpartner";
                    con.Close();

                }

            }
            position();
        }
        
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                lieferdaten.Visible = false;
            }
            else
            {
                lieferdaten.Visible = true;
                iconButton3.Visible = true;
                if (Kunde==0)
                {
                    iconButton3.Visible = false;
                }
                hochzaehlen("Nr","KundeLieferort",textBox18,lieferdaten);
            }
        }
        public void updateLieferadresse ()
        {
            if (checkBox1.Checked==false&lieferdaten.Visible==true)
            {
                con.Open();
                cmd = new OleDbCommand("update KundeLieferort set Bez = '" + textBox16.Text.ToString() + "', Telefon = '" + textBox15.Text.ToString() + "', Email = '" + textBox14.Text.ToString() + "', Fax = '" + textBox13.Text.ToString() + "', PLZ = '" + textBox12.Text.ToString() + "', Ort = '" + textBox11.Text.ToString() + "', Straße = '" + textBox10.Text.ToString() + "', Land = '" + textBox9.Text.ToString() + "',  IsActive = " + checkBox3.Checked + " where Nr = " + Convert.ToInt64(textBox18.Text) + "", con);

                cmd.ExecuteNonQuery();

                con.Close();
            }
            else
            {

            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string kundeNr = textBox17.Text;
            if (Kunde == 0)
            {
                if (textBox17.TextLength > 0)
                {
                    try
                    {
                     con.Open();
                    cmd = new OleDbCommand("Insert into Kunde (Nr, Bez, Telefon, Email, Fax, PLZ, Ort, Straße, Land, IsActive) values ('" + textBox17.Text + "', '" + textBox1.Text + "', '" + textBox2.Text + "','" + textBox4.Text + "','" + textBox3.Text + "', '" + textBox5.Text + "', '" + textBox6.Text + "','" + textBox7.Text + "' , '" + textBox8.Text + "'," + checkBox2.Checked + ")", con);

                    cmd.ExecuteNonQuery();
                    con.Close();
                    }
                    catch 
                    {
                        MessageBox.Show("Geben sie richtige Daten ein und füllen sie alles aus");
                    }
                if (checkBox1.Checked == false)
                {

                    con.Open();
                    cmd = new OleDbCommand("Insert into KundeLieferort (Nr, Kunde, Bez, Telefon, Email, Fax, PLZ, Ort, Straße, Land, IsActive) values ('" + textBox18.Text + "', '" + textBox17.Text + "', '" + textBox16.Text + "', '" + textBox15.Text + "','" + textBox14.Text + "','" + textBox13.Text + "', '" + textBox12.Text + "', '" + textBox11.Text + "','" + textBox10.Text + "' , '" + textBox9.Text + "'," + checkBox3.Checked + ")", con);

                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                DialogResult result = MessageBox.Show("Wollen sie zu ihrem Kunden einen Ansprechpartner Hinzufügen?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                        TabPage ansprechpartnerPage = new TabPage();
                        Ansprechpartner ansprechpartner = new Ansprechpartner(kundeNr, TC, ansprechpartnerPage);
                   
                    ansprechpartnerPage.Controls.Clear();

                    ansprechpartnerPage.Text = "Ansprechpartner hinzufügen";
                    TC.TabPages.Add(ansprechpartnerPage);
                    LoadForm.OpenTab(ansprechpartner, ansprechpartnerPage);
                    TabPage selectedpage = TC.SelectedTab;

                    TC.TabPages.Remove(selectedpage);
                    TC.SelectedTab = ansprechpartnerPage;

                    TC.Height = 808;
                }
                else
                {
                    MessageBox.Show("Neuer Kunde wurde erstellt!");

                    TabPage selectedpage = TC.SelectedTab;

                    TC.TabPages.Remove(selectedpage);

                }
            } else
            {
                MessageBox.Show("Geben sie eine Nummer ein");
            }
            }
           
            con.Close();
            if (Kunde > 0)
            {
                
            con.Open();
            cmd = new OleDbCommand("update Kunde set Bez = '" + textBox1.Text.ToString() + "', Telefon = '" + textBox2.Text.ToString() + "', Email = '" + textBox4.Text.ToString() + "', Fax = '" + textBox3.Text.ToString() + "', PLZ = '" + textBox5.Text.ToString() + "', Ort = '" + textBox6.Text.ToString() + "', Straße = '" + textBox7.Text.ToString() + "', Land = '" + textBox8.Text.ToString() + "',  IsActive = " + checkBox2.Checked + " where Nr = " + Convert.ToInt64(textBox17.Text) + "", con);

            cmd.ExecuteNonQuery();
               
            con.Close();

                if (lieferdaten.Visible==true)
                {
                    if (textBox18.TextLength == 0)
                {
                MessageBox.Show("Geben sie eine Nummer ein!");
                textBox18.Focus();
                }
                else
                {
                        

                }

                }
                else
                {
                    updateLieferadresse();

                    MessageBox.Show("Update erfolgreich");

                    TabPage selectedpage = TC.SelectedTab;

                    TC.TabPages.Remove(selectedpage);
                }
                
            }
            
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new OleDbCommand("Insert into KundeLieferort (Nr, Kunde, Bez, Telefon, Email, Fax, PLZ, Ort, Straße, Land, IsActive) values ('" + textBox18.Text + "', '" + textBox17.Text + "', '" + textBox16.Text + "', '" + textBox15.Text + "','" + textBox14.Text + "','" + textBox13.Text + "', '" + textBox12.Text + "', '" + textBox11.Text + "','" + textBox10.Text + "' , '" + textBox9.Text + "'," + checkBox3.Checked + ")", con);

            cmd.ExecuteNonQuery();
            con.Close();

           con.Close();
           
            adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "", con);
            con.Open();
            ds.Clear();

            adap.Fill(ds, "adresse");

            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "adresse";
            con.Close();
            lieferdaten.Visible = false;
            panel1.Visible = true;
            if (panel2.Visible==true)
            {
                TC.Height= 808;
                button1.Location = new Point(777, 727);
            }
            position();
        }
        
        private void iconButton1_Click(object sender, EventArgs e)
        {
            lieferdaten.Visible = true;
            textBox18.Clear();
            textBox16.Clear();
            textBox15.Clear();
            textBox14.Clear();
            textBox13.Clear();
            textBox12.Clear();
            textBox11.Clear();
            textBox10.Clear();
            textBox9.Clear();
            checkBox1.Checked = false;
            hochzaehlen("Nr", "KundeLieferort", textBox18, lieferdaten);
        }
       
        private void iconButton6_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();
            DialogResult result = MessageBox.Show("Sind Sie sicher das Sie die ausgewählte Lieferadresse löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                con.Open();
               cmd = new OleDbCommand("Update KundeLieferort set where Nr = " + Ausgewähltezelle + "", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                con.Close();


                MessageBox.Show("Gelöscht.");

            }
            adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "", con);
            con.Open();
            ds.Clear();

            adap.Fill(ds, "adresse");

            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "adresse";
            con.Close();

            adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "", con);
            con.Open();
            DataTable dt = new DataTable();
            DataRow d = dt.NewRow();
            adap.Fill(dt);
            
            con.Close();

            if (dt.Rows.Count<1)
            {
                panel1.Visible = false;
                checkBox1.Checked = true;
            }
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                
                if (Enumerable.SequenceEqual(dt.Rows[i].ItemArray, d.ItemArray))
                {
                   
                }
                else
                {
                   
                    if (dt.Rows.Count < 1)
                    {
                       
                    }
                    else
                    {
                        panel1.Visible = true;
                        adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "", con);
                        con.Open();
                        ds.Clear();

                        adap.Fill(ds, "adresse");

                        dataGridView1.DataSource = ds;
                        dataGridView1.DataMember = "adresse";
                        con.Close();

                    }
                }
            }
            if (panel1.Visible == false)
            {
                TC.Height = 647;
                button1.Location = new Point(777 , 727);
            }
            position();
        }

        private void iconButton7_Click(object sender, EventArgs e)
        {
            iconButton3.Visible = false;
            lieferdaten.Visible = true;

            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();

            cmd = new OleDbCommand("select * from KundeLieferort where Nr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            textBox18.Text = Convert.ToString(dr.GetInt32(0));
            textBox16.Text = dr.GetString(2);
            textBox15.Text = dr.GetString(3);
            textBox14.Text = dr.GetString(4);
            textBox13.Text = dr.GetString(5);
            textBox12.Text = Convert.ToString(dr.GetInt32(6));
            textBox11.Text = dr.GetString(7);
            textBox10.Text = dr.GetString(8);
            textBox9.Text = dr.GetString(9);
            checkBox3.Checked = dr.GetBoolean(10);
            con.Close();

        }
      
        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            string kundeNr = textBox17.Text;
            if (checkBox4.Checked==true&panel2.Visible==false)
            {
                DialogResult result = MessageBox.Show("Wollen sie zu ihrem Kunden einen Ansprechpartner Hinzufügen?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                      TabPage ansprechpartnerPage = new TabPage();
                        Ansprechpartner ansprechpartner = new Ansprechpartner(kundeNr,TC,ansprechpartnerPage);
                        
                    ansprechpartnerPage.Controls.Clear();
                    
                    ansprechpartnerPage.Text = "Ansprechpartner hinzufügen";
                    TC.TabPages.Add(ansprechpartnerPage);
                   LoadForm.OpenTab(ansprechpartner,ansprechpartnerPage);
                    TC.SelectedTab=ansprechpartnerPage;
                    
                }

            }
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            string kundeNr = textBox17.Text;
            TabPage ansprechpartnerhinzufuegen = new TabPage();
            Ansprechpartner ansprechpartner = new Ansprechpartner(kundeNr,TC,ansprechpartnerhinzufuegen);
            
            ansprechpartnerhinzufuegen.Controls.Clear();

            ansprechpartnerhinzufuegen.Text = "Ansprechpartner hinzufügen";
            TC.TabPages.Add(ansprechpartnerhinzufuegen);
            LoadForm.OpenTab(ansprechpartner, ansprechpartnerhinzufuegen);
            TC.SelectedTab = ansprechpartnerhinzufuegen;
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = Ansprechpartner.CurrentRow.Cells["Nr"].Value.ToString();

            con.Open();
            cmd = new OleDbCommand("SELECT Ansprechpartner.* from Ansprechpartner where Ansprechpartner.Nr = " + Ausgewähltezelle + "", con);

            dr = cmd.ExecuteReader();
            dr.Read();
            string aNr = Convert.ToString(dr.GetInt32(0));
          
            con.Close();
            TabPage ansprechpartnerBearbeiten = new TabPage();
            Ansprechpartner ansprechpartner = new Ansprechpartner(aNr, TC, ansprechpartnerBearbeiten);
           
            ansprechpartnerBearbeiten.Controls.Clear();

            ansprechpartnerBearbeiten.Text = "Ansprechpartner bearbeiten";
            TC.TabPages.Add(ansprechpartnerBearbeiten);
            LoadForm.OpenTab(ansprechpartner, ansprechpartnerBearbeiten);
            TC.SelectedTab = ansprechpartnerBearbeiten;
            
        }
        private void textBox17_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            textBox17.ReadOnly = false;
        }

        private void textBox18_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            textBox18.ReadOnly = false;
        }
    }
}
