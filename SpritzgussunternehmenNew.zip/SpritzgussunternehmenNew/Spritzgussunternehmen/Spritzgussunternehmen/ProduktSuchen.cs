﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class ProduktSuchen : Form
    {
        Helfer Manni = new Helfer();

        TabPage TPage = new TabPage();
        TabControl TC;
        public ProduktSuchen(TabControl TC)
        {
            InitializeComponent();
            this.TC = TC;
        }

        private void ProduktSuchen_Load(object sender, EventArgs e)
        {
            Produkt.SuchenDataGridFuellen(Produkte);
            txtnr.Text = Manni.LetzteNummer("Produktart").ToString();
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            if (Produkte.SelectedRows != null)
            {
                if (btnActive.Visible)
                {
                    Produktart.LoescheProduktart(Produkte);
                }
                else
                {
                    Produkt.LoescheProdukt(Produkte);
                }
            }
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            TPage.Text = "Produkt hinzufügen";
            TC.TabPages.Add(TPage);
            LoadForm.OpenTab(new ProduktAdd(TC), TPage);
            TC.SelectedTab = TPage;

            if (btnActive.Visible)
            {
                ArtInactive();
            }
        }

        private void iconButton7_Click(object sender, EventArgs e)
        {
            TPage.Text = "Produktionsschritte";
            TC.TabPages.Add(TPage);
            LoadForm.OpenTab(new ProdSchrittSuchen(TC), TPage);
            TC.SelectedTab = TPage;

            if (btnActive.Visible)
            {
                ArtInactive();
            }
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            if(iconButton6.BackColor == Color.White)
            {
                ArtActice();
            }
            else
            {
                ArtInactive();
            }
        }

        private void iconButton9_Click(object sender, EventArgs e)
        {
            if (btnehadd.Text == "Produktart hinzufügen")
            {
                txtnr.Text = Manni.LetzteNummer("Produktart").ToString();
                txtbez.Clear();
                checknr.Checked = false;
                txtnr.Enabled = false;
            }
            else
            {
                txtnr.Text = Manni.LetzteNummer("Produktart").ToString();
                txtbez.Clear();
                Produkte.ClearSelection();
                btnehadd.Text = "Produktart hinzufügen";

                checknr.Enabled = true;
                checknr.Checked = false;

                txtnr.Enabled = false;
            }
        }

        private void Produkte_SelectionChanged(object sender, EventArgs e)
        {
            if(btnActive.Visible)
            {
                try
                {
                    if (Produkte.SelectedRows.Count > 0)
                    {
                        int PArtNr = Convert.ToInt32(Produkte.SelectedRows[0].Cells[0].Value);
                        string Bez = Produkte.SelectedRows[0].Cells[1].Value.ToString();

                        txtnr.Text = PArtNr.ToString();
                        txtbez.Text = Bez;

                        btnehadd.Text = "Produktart bearbeiten";
                        checknr.Enabled = false;
                        checknr.Checked = false;
                        txtnr.Enabled = false;
                    }
                }
                catch (Exception){}
            }
        }

        private void btnehadd_Click(object sender, EventArgs e)
        {
            List<string> DataToFill = new List<string>();
            DataToFill.Add(txtnr.Text);
            DataToFill.Add(txtbez.Text);

            switch (btnehadd.Text)
            {
                case "Produktart hinzufügen":
                    Produktart.ErstelleProduktart(DataToFill);
                    txtnr.Text = Manni.LetzteNummer("Produktart").ToString();
                    break;
                case "Produktart bearbeiten":
                    Produktart.BearbeiteProduktart(DataToFill);
                    break;
            }

            Produkte.DataSource = null;
            Produktart.SuchenDataGridFuellen(Produkte);
        }

        private void checknr_CheckedChanged(object sender, EventArgs e)
        {
            if (!txtnr.Enabled)
            {
                txtnr.Enabled = true;
                txtnr.Clear();
            }
            else
            {
                txtnr.Enabled = false;
                txtnr.Text = Manni.LetzteNummer("Produktart").ToString();
            }
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            if (btnActive.Visible)
            {
                Produktart.SucheProduktart(textBox1.Text, Produkte);
            }
            else
            {
                Produkt.SucheProdukt(textBox1.Text, Produkte);
            }
        }

        private void iconButton8_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            if (btnActive.Visible)
            {
                Produktart.SuchenDataGridFuellen(Produkte);
            }
            else
            {
                Produkt.SuchenDataGridFuellen(Produkte);
            }
        }

        private void Produkte_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            Produkte.Rows[e.RowIndex].Selected = true;
        }

        private void ArtActice()
        {
            iconButton6.Size = new Size(284, 34);
            iconButton6.Location = new Point(706, 70);
            iconButton6.TextImageRelation = TextImageRelation.TextBeforeImage;
            iconButton6.BackColor = Color.Gainsboro;
            btnActive.Visible = true;

            artenPanel.Visible = true;
            btnFilter.Visible = false;

            Produktart.SuchenDataGridFuellen(Produkte);
        }
        private void ArtInactive()
        {
            iconButton6.Size = new Size(293, 34);
            iconButton6.Location = new Point(696, 70);
            iconButton6.TextImageRelation = TextImageRelation.ImageBeforeText;
            iconButton6.BackColor = Color.White;
            btnActive.Visible = false;

            artenPanel.Visible = false;
            btnFilter.Visible = true;

            Produkt.SuchenDataGridFuellen(Produkte);
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            if (btnActive.Visible)
            {
                ArtInactive();
            }
            if(Produkte.SelectedRows != null)
            {
                DataGridViewRow row = Produkte.SelectedRows[0];

                Produkt.txtart = Produktart.GetProdArtBez(Convert.ToInt32(row.Cells[1].Value)).ToString();
                Produkt.txtbez = row.Cells[2].Value.ToString();
                Produkt.txthoehe = row.Cells[3].Value.ToString();
                Produkt.txtlaenge = row.Cells[5].Value.ToString();
                Produkt.txtbreite = row.Cells[4].Value.ToString();
                Produkt.txtgewicht = row.Cells[6].Value.ToString();
                Produkt.txteinheit = Mengeneinheit.GetMengenBez(Convert.ToInt32(row.Cells[12].Value)).ToString();
                Produkt.txtbeschreibung = row.Cells[7].Value.ToString();
                Produkt.txthpreis = row.Cells[10].Value.ToString();
                Produkt.txtpreis = row.Cells[8].Value.ToString();
                Produkt.txtaktbestand = Convert.ToInt32(row.Cells[9].Value);

                TPage.Text = "Produkt bearbeiten";
                TC.TabPages.Add(TPage);
                LoadForm.OpenTab(new ProduktAdd(TC, Convert.ToInt32(row.Cells[0].Value)), TPage);
                TC.SelectedTab = TPage;
            }
        }

        private void ProduktSuchen_Shown(object sender, EventArgs e)
        {
            
        }
    }
}
