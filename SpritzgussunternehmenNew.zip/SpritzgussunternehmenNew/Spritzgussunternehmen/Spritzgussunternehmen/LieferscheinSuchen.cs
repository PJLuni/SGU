﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class LieferscheinSuchen : Form
    {
        Helfer Manni = new Helfer();
        public LieferscheinSuchen()
        {
            InitializeComponent();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {

        }

        private void LieferscheinSuchen_Load(object sender, EventArgs e)
        {
            date.MinDate = DateTime.Today;
            txtnr.Text = Manni.LetzteNummer("Lieferschein").ToString();
            
            Lieferschein.SuchenDataGridFuellen(Lieferscheine);
            Mengeneinheit.LoadMengeneinheiten(txteinheit);
            Lieferscheine.ClearSelection();
        }

        private void checknr_CheckedChanged(object sender, EventArgs e)
        {
            if (txtnr.Enabled == false)
            {
                txtnr.Enabled = true;
                txtnr.Clear();
            }
            else
            {
                txtnr.Enabled = false;
                try
                {
                    txtnr.Text = Manni.LetzteNummer("Lieferschein").ToString();
                }
                catch (Exception)
                {
                    txtnr.Text = 1.ToString();
                }
                
            }
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            if (btnrohadd.Text == "Lieferschein hinzufügen")
            {
                txtnr.Text = Manni.LetzteNummer("Lieferschein").ToString();
                txtgewicht.Value = 0;
                txteinheit.SelectedItem = null;
                comboKunde.SelectedItem = null;
                checknr.Checked = false;
                txtnr.Enabled = false;
            }
            else
            {
                txtnr.Text = Manni.LetzteNummer("Lieferschein").ToString();
                txtgewicht.Value = 0;
                txteinheit.SelectedItem = null;
                comboKunde.SelectedItem = null;
                Lieferscheine.ClearSelection();
                btnrohadd.Text = "Lieferschein hinzufügen";
                checknr.Enabled = true;
                checknr.Checked = false;
                txtnr.Enabled = false;
            }
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            Lieferschein.LoescheLieferschein(Lieferscheine);
        }

        private void btnrohadd_Click(object sender, EventArgs e)
        {
            bool DataFilled = true;
            foreach(Control CON in this.Controls)
            {
                if(CON is TextBox)
                {
                    if(CON.Text == "")
                    {
                        DataFilled = false;
                    }
                }
                if(CON is ComboBox)
                {
                    if (CON.Text == "")
                    {
                        DataFilled = false;
                    }
                }
            }
            if (DataFilled)
            {
                Lieferschein.Nr = Convert.ToInt32(txtnr.Text);
                Lieferschein.EinheitBez = txteinheit.Text;
                Lieferschein.AuftragLieferung = Convert.ToInt32(comboLieferung.Text);
                Lieferschein.Kunde = Convert.ToInt32(comboKunde.Text);
                Lieferschein.Zustellung = date.Value.ToShortDateString();
                Lieferschein.Gewicht = txtgewicht.Value.ToString();
                
                if (btnrohadd.Text == "Lieferschein hinzufügen")
                {
                    Lieferschein.ErstelleLieferschein();
                }
                else
                {
                    //Lieferschein.BearbeiteLieferschein();
                }
            }
        }

        private void Lieferscheine_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (Lieferscheine.SelectedRows.Count > 0)
                {
                    //int Nr = Convert.ToInt32(Lieferscheine.SelectedRows[0].Cells[0].Value);
                    //int Kunde = Convert.ToInt32(Lieferscheine.SelectedRows[0].Cells[4].Value);
                    //string Gewicht = Lieferscheine.SelectedRows[0].Cells[1].Value.ToString();
                    //int Lieferung = Convert.ToInt32(Lieferscheine.SelectedRows[0].Cells[2].Value);
                    //DateTime Date = Convert.ToDateTime(Lieferscheine.SelectedRows[0].Cells[2].Value);

                    //int EinheitNr = Convert.ToInt32(Lieferscheine.SelectedRows[0].Cells[3].Value);
                    //string EinheitBez = Manni.getMengenBez(EinheitNr);

                    //txtnr.Text = Nr.ToString();
                    //comboKunde.SelectedItem = Kunde.ToString();
                    //txtgewicht.Value = Convert.ToDecimal(Gewicht);
                    //comboLieferung.SelectedItem = Lieferung.ToString();
                    //txt.Text = Bestand.ToString();
                    //txteinheit.SelectedItem = EinheitBez;

                    //btnrohadd.Text = "Rohstoff bearbeiten";
                    //checknr.Enabled = false;
                    //checknr.Checked = false;
                    //txtnr.Enabled = false;
                }
            }
            catch (Exception err)
            {
                throw err;
            }
        }
    }
}
