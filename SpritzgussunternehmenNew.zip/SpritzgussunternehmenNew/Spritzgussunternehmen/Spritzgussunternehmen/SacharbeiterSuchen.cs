﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace Spritzgussunternehmen
{
    public partial class SacharbeiterSuchen : Form
    {
        Helfer Manni = new Helfer();
        public SacharbeiterSuchen()
        {
            InitializeComponent();
        }

        private void Mitarbeiter_Load(object sender, EventArgs e)
        {
            if (AuftragAdd.sachbearbeiterAnzeigen == 1)
            {
                txtnr.Text = Manni.LetzteNummer("Benutzerkonto").ToString();
                Sacharbeiter.SuchenDataGridFuellen(MitarbeiterList);
                MitarbeiterList.Columns["Passwort"].Visible = false;
                panel1.Visible = false;
                iconButton6.Visible = false;
                btnehadd.Visible = false;
                iconButton5.Visible = false;
            }
            else
            {
                txtnr.Text = Manni.LetzteNummer("Benutzerkonto").ToString();
                Sacharbeiter.SuchenDataGridFuellen(MitarbeiterList);
                MitarbeiterList.Columns["Passwort"].Visible = false;
            }
        }

        private void MitarbeiterList_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (MitarbeiterList.SelectedRows.Count > 0)
                {
                    int SachNr = Convert.ToInt32(MitarbeiterList.SelectedRows[0].Cells[0].Value);
                    string Name = MitarbeiterList.SelectedRows[0].Cells[1].Value.ToString();
                    string Vorname = MitarbeiterList.SelectedRows[0].Cells[2].Value.ToString();
                    string BenutzName = MitarbeiterList.SelectedRows[0].Cells[3].Value.ToString();

                    txtnr.Text = SachNr.ToString();
                    txtname.Text = Name;
                    txtvorname.Text = Vorname;
                    txtbenutzername.Text = BenutzName;

                    lblpassword.Text = "Passwort Bestätigung";
                    txtpassword.Size = new Size(358, txtpassword.Size.Height);
                    txtpassword.Clear();
                    pw2label.Visible = false;

                    btnehadd.Text = "Mitarbeiter bearbeiten";
                    checknr.Enabled = false;
                    checknr.Checked = false;
                    txtnr.Enabled = false;
                }
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        private void txtname_Leave(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtvorname.Text))
            {
                txtbenutzername.Text = txtvorname.Text.ToLower() + "." + txtname.Text.ToLower();
            }
        }

        private void txtvorname_Leave(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtname.Text))
            {
                txtbenutzername.Text = txtvorname.Text.ToLower() +"."+ txtname.Text.ToLower();
            }
        }

        private void checknr_CheckedChanged(object sender, EventArgs e)
        {
            if (txtnr.Enabled == false)
            {
                txtnr.Enabled = true;
                txtnr.Clear();
                txtnr.Select();
            }
            else
            {
                txtnr.Enabled = false;
                txtnr.Text = Manni.LetzteNummer("Benutzerkonto").ToString();
            }
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            Sacharbeiter.LoescheSacharbeiter(MitarbeiterList);
        }

        private void btnehadd_Click(object sender, EventArgs e)
        {
            List<string> DataToFill = new List<string>();
            DataToFill.Add(txtnr.Text);
            DataToFill.Add(txtname.Text);
            DataToFill.Add(txtvorname.Text);
            DataToFill.Add(txtbenutzername.Text);
            DataToFill.Add(txtpassword.Text);

            switch (btnehadd.Text)
            {
                case "Mitarbeiter hinzufügen":
                    if(txtpassword.Text == txtpasswordaga.Text)
                    {
                        Sacharbeiter.ErstelleSacharbeiter(DataToFill);
                        txtnr.Text = Manni.LetzteNummer("Benutzerkonto").ToString();
                    }
                    else
                    {
                        Info.Error("Passwörter stimmen nicht überein");
                    }
                    break;
                case "Mitarbeiter bearbeiten":
                    DB.cmd = DB.createCmd($"SELECT Passwort FROM Benutzerkonto WHERE Nr = {txtnr.Text}");
                    DB.getCon().Open();
                    string dbpw = DB.cmd.ExecuteScalar().ToString();
                    DB.getCon().Close();

                    string Hash = Manni.HashPassword(txtpassword.Text, new SHA256CryptoServiceProvider());
                    if(Hash == dbpw)
                    {
                        Sacharbeiter.BearbeiteSacharbeiter(DataToFill);
                    }
                    else
                    {
                        Info.Error("Falsches Passwort");
                    }
                    break;
            }

            MitarbeiterList.DataSource = null;
            Sacharbeiter.SuchenDataGridFuellen(MitarbeiterList);
            MitarbeiterList.Columns["Passwort"].Visible = false;
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            if (btnehadd.Text == "Mitarbeiter hinzufügen")
            {
                txtnr.Text = Manni.LetzteNummer("Benutzerkonto").ToString();
                txtname.Clear();
                txtvorname.Clear();
                txtbenutzername.Clear();
                txtpassword.Clear();
                txtpasswordaga.Clear();
                checknr.Checked = false;
                txtnr.Enabled = false;
                chBPwShow.Checked = false;
            }
            else
            {
                txtnr.Text = Manni.LetzteNummer("Benutzerkonto").ToString();
                txtname.Clear();
                txtvorname.Clear();
                txtbenutzername.Clear();
                txtpassword.Clear();
                txtpasswordaga.Clear();
                MitarbeiterList.ClearSelection();
                btnehadd.Text = "Mitarbeiter hinzufügen";
                checknr.Enabled = true;
                checknr.Checked = false;
                txtnr.Enabled = false;
                chBPwShow.Checked = false;
                pw2label.Visible = true;

                lblpassword.Text = "Passwort";
                txtpassword.Size = new Size(176, txtpassword.Size.Height);
            }
        }

        private void chBPwShow_CheckedChanged(object sender, EventArgs e)
        {
            if(chBPwShow.Checked)
            {
                txtpassword.PasswordChar = '\0';
                txtpasswordaga.PasswordChar = '\0';
            }
            else
            {
                txtpassword.PasswordChar = '*';
                txtpasswordaga.PasswordChar = '*';
            }
        }

        private void iconButton7_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            Sacharbeiter.SuchenDataGridFuellen(MitarbeiterList);
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            Sacharbeiter.SucheSacharbeiter(textBox1.Text, MitarbeiterList);
        }

        private void MitarbeiterList_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (AuftragAdd.sachbearbeiterAnzeigen == 1)
            {
                string Ausgewähltezelle = MitarbeiterList.CurrentRow.Cells["Nr"].Value.ToString();
                Sacharbeiter.SachbearbeiterAuftrag(Ausgewähltezelle);
                Close();
            }
        }
    }
}
