﻿namespace Spritzgussunternehmen
{
    partial class ProdSchrittSuchen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rohstoffmenge = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.rohstoffeinheit = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.prodschrittcombo = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dgvlabel = new System.Windows.Forms.Label();
            this.prodschritte = new System.Windows.Forms.DataGridView();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.label17 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.produktcombo = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtbez = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rohstoffcombo = new System.Windows.Forms.ComboBox();
            this.prodschrittedetail = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.checknr = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.DetailsPanel2 = new System.Windows.Forms.Panel();
            this.DetailsPanel1 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.produktcombodetails = new System.Windows.Forms.ComboBox();
            this.iconButton4 = new FontAwesome.Sharp.IconButton();
            this.txtschritt = new System.Windows.Forms.NumericUpDown();
            this.iconButton3 = new FontAwesome.Sharp.IconButton();
            this.iconButton5 = new FontAwesome.Sharp.IconButton();
            this.iconButton6 = new FontAwesome.Sharp.IconButton();
            this.iconButton7 = new FontAwesome.Sharp.IconButton();
            ((System.ComponentModel.ISupportInitialize)(this.prodschritte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodschrittedetail)).BeginInit();
            this.DetailsPanel2.SuspendLayout();
            this.DetailsPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtschritt)).BeginInit();
            this.SuspendLayout();
            // 
            // rohstoffmenge
            // 
            this.rohstoffmenge.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rohstoffmenge.Location = new System.Drawing.Point(0, 101);
            this.rohstoffmenge.Name = "rohstoffmenge";
            this.rohstoffmenge.Size = new System.Drawing.Size(150, 26);
            this.rohstoffmenge.TabIndex = 192;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Chocolate;
            this.label5.Location = new System.Drawing.Point(153, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 18);
            this.label5.TabIndex = 195;
            this.label5.Text = "Einheit";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Chocolate;
            this.label8.Location = new System.Drawing.Point(-2, 81);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 18);
            this.label8.TabIndex = 194;
            this.label8.Text = "Menge";
            // 
            // rohstoffeinheit
            // 
            this.rohstoffeinheit.BackColor = System.Drawing.Color.White;
            this.rohstoffeinheit.DropDownHeight = 150;
            this.rohstoffeinheit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.rohstoffeinheit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rohstoffeinheit.FormattingEnabled = true;
            this.rohstoffeinheit.IntegralHeight = false;
            this.rohstoffeinheit.Location = new System.Drawing.Point(156, 101);
            this.rohstoffeinheit.Name = "rohstoffeinheit";
            this.rohstoffeinheit.Size = new System.Drawing.Size(153, 26);
            this.rohstoffeinheit.TabIndex = 193;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Chocolate;
            this.label4.Location = new System.Drawing.Point(-5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(314, 32);
            this.label4.TabIndex = 191;
            this.label4.Text = "Verbrauchte Rohstoffe";
            // 
            // prodschrittcombo
            // 
            this.prodschrittcombo.BackColor = System.Drawing.Color.White;
            this.prodschrittcombo.DropDownHeight = 150;
            this.prodschrittcombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.prodschrittcombo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prodschrittcombo.FormattingEnabled = true;
            this.prodschrittcombo.IntegralHeight = false;
            this.prodschrittcombo.Location = new System.Drawing.Point(1, 21);
            this.prodschrittcombo.Name = "prodschrittcombo";
            this.prodschrittcombo.Size = new System.Drawing.Size(308, 26);
            this.prodschrittcombo.Sorted = true;
            this.prodschrittcombo.TabIndex = 189;
            this.prodschrittcombo.SelectedIndexChanged += new System.EventHandler(this.prodschrittcombo_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Chocolate;
            this.label3.Location = new System.Drawing.Point(680, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 40);
            this.label3.TabIndex = 188;
            this.label3.Text = "Details";
            // 
            // dgvlabel
            // 
            this.dgvlabel.AutoSize = true;
            this.dgvlabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvlabel.ForeColor = System.Drawing.Color.Chocolate;
            this.dgvlabel.Location = new System.Drawing.Point(8, 332);
            this.dgvlabel.Name = "dgvlabel";
            this.dgvlabel.Size = new System.Drawing.Size(408, 22);
            this.dgvlabel.TabIndex = 187;
            this.dgvlabel.Text = "Bereits existierende Produktionsschritte für";
            // 
            // prodschritte
            // 
            this.prodschritte.AllowUserToAddRows = false;
            this.prodschritte.AllowUserToDeleteRows = false;
            this.prodschritte.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.prodschritte.BackgroundColor = System.Drawing.Color.White;
            this.prodschritte.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.prodschritte.Location = new System.Drawing.Point(12, 379);
            this.prodschritte.Name = "prodschritte";
            this.prodschritte.ReadOnly = true;
            this.prodschritte.Size = new System.Drawing.Size(669, 205);
            this.prodschritte.TabIndex = 186;
            this.prodschritte.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.prodschritte_CellEnter);
            this.prodschritte.SelectionChanged += new System.EventHandler(this.prodschritte_SelectionChanged);
            // 
            // iconButton1
            // 
            this.iconButton1.BackColor = System.Drawing.Color.White;
            this.iconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.FolderPlus;
            this.iconButton1.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 26;
            this.iconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton1.Location = new System.Drawing.Point(12, 590);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(134, 35);
            this.iconButton1.TabIndex = 185;
            this.iconButton1.Text = "Hinzufügen";
            this.iconButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton1.UseVisualStyleBackColor = false;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Chocolate;
            this.label17.Location = new System.Drawing.Point(5, 9);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(330, 40);
            this.label17.TabIndex = 178;
            this.label17.Text = "Produktionsschritt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Chocolate;
            this.label1.Location = new System.Drawing.Point(9, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 18);
            this.label1.TabIndex = 177;
            this.label1.Text = "Bezeichnung";
            // 
            // produktcombo
            // 
            this.produktcombo.BackColor = System.Drawing.Color.White;
            this.produktcombo.DropDownHeight = 150;
            this.produktcombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.produktcombo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.produktcombo.FormattingEnabled = true;
            this.produktcombo.IntegralHeight = false;
            this.produktcombo.Location = new System.Drawing.Point(85, 70);
            this.produktcombo.Name = "produktcombo";
            this.produktcombo.Size = new System.Drawing.Size(238, 26);
            this.produktcombo.Sorted = true;
            this.produktcombo.TabIndex = 179;
            this.produktcombo.SelectedIndexChanged += new System.EventHandler(this.produktcombo_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Chocolate;
            this.label7.Location = new System.Drawing.Point(-2, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 18);
            this.label7.TabIndex = 184;
            this.label7.Text = "Rohstoff";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Chocolate;
            this.label6.Location = new System.Drawing.Point(-2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 18);
            this.label6.TabIndex = 183;
            this.label6.Text = "Produktionsschritt";
            // 
            // txtbez
            // 
            this.txtbez.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbez.Location = new System.Drawing.Point(12, 141);
            this.txtbez.Name = "txtbez";
            this.txtbez.Size = new System.Drawing.Size(312, 26);
            this.txtbez.TabIndex = 180;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Chocolate;
            this.label2.Location = new System.Drawing.Point(82, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 18);
            this.label2.TabIndex = 182;
            this.label2.Text = "Produkt";
            // 
            // rohstoffcombo
            // 
            this.rohstoffcombo.BackColor = System.Drawing.Color.White;
            this.rohstoffcombo.DropDownHeight = 150;
            this.rohstoffcombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.rohstoffcombo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rohstoffcombo.FormattingEnabled = true;
            this.rohstoffcombo.IntegralHeight = false;
            this.rohstoffcombo.Location = new System.Drawing.Point(0, 53);
            this.rohstoffcombo.Name = "rohstoffcombo";
            this.rohstoffcombo.Size = new System.Drawing.Size(309, 26);
            this.rohstoffcombo.Sorted = true;
            this.rohstoffcombo.TabIndex = 181;
            // 
            // prodschrittedetail
            // 
            this.prodschrittedetail.AllowUserToAddRows = false;
            this.prodschrittedetail.AllowUserToDeleteRows = false;
            this.prodschrittedetail.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.prodschrittedetail.BackgroundColor = System.Drawing.Color.White;
            this.prodschrittedetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.prodschrittedetail.Location = new System.Drawing.Point(687, 379);
            this.prodschrittedetail.Name = "prodschrittedetail";
            this.prodschrittedetail.ReadOnly = true;
            this.prodschrittedetail.Size = new System.Drawing.Size(311, 205);
            this.prodschrittedetail.TabIndex = 196;
            this.prodschrittedetail.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.prodschrittedetail_CellEnter);
            this.prodschrittedetail.SelectionChanged += new System.EventHandler(this.prodschrittedetail_SelectionChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Chocolate;
            this.label9.Location = new System.Drawing.Point(684, 354);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(290, 22);
            this.label9.TabIndex = 197;
            this.label9.Text = "Produktionsschritt Positionen: ";
            // 
            // iconButton2
            // 
            this.iconButton2.BackColor = System.Drawing.Color.White;
            this.iconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.FolderPlus;
            this.iconButton2.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.IconSize = 26;
            this.iconButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton2.Location = new System.Drawing.Point(865, 590);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Size = new System.Drawing.Size(133, 35);
            this.iconButton2.TabIndex = 198;
            this.iconButton2.Text = "Hinzufügen";
            this.iconButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton2.UseVisualStyleBackColor = false;
            this.iconButton2.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // checknr
            // 
            this.checknr.AutoSize = true;
            this.checknr.ForeColor = System.Drawing.Color.White;
            this.checknr.Location = new System.Drawing.Point(12, 102);
            this.checknr.Name = "checknr";
            this.checknr.Size = new System.Drawing.Size(140, 16);
            this.checknr.TabIndex = 323;
            this.checknr.Text = "Schritt selbst wählen";
            this.checknr.UseVisualStyleBackColor = true;
            this.checknr.CheckedChanged += new System.EventHandler(this.checknr_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Chocolate;
            this.label11.Location = new System.Drawing.Point(8, 49);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 18);
            this.label11.TabIndex = 322;
            this.label11.Text = "Nr";
            // 
            // DetailsPanel2
            // 
            this.DetailsPanel2.Controls.Add(this.label4);
            this.DetailsPanel2.Controls.Add(this.rohstoffcombo);
            this.DetailsPanel2.Controls.Add(this.label7);
            this.DetailsPanel2.Controls.Add(this.rohstoffeinheit);
            this.DetailsPanel2.Controls.Add(this.label8);
            this.DetailsPanel2.Controls.Add(this.label5);
            this.DetailsPanel2.Controls.Add(this.rohstoffmenge);
            this.DetailsPanel2.Enabled = false;
            this.DetailsPanel2.Location = new System.Drawing.Point(687, 179);
            this.DetailsPanel2.Name = "DetailsPanel2";
            this.DetailsPanel2.Size = new System.Drawing.Size(325, 138);
            this.DetailsPanel2.TabIndex = 324;
            // 
            // DetailsPanel1
            // 
            this.DetailsPanel1.Controls.Add(this.label6);
            this.DetailsPanel1.Controls.Add(this.prodschrittcombo);
            this.DetailsPanel1.Enabled = false;
            this.DetailsPanel1.Location = new System.Drawing.Point(687, 102);
            this.DetailsPanel1.Name = "DetailsPanel1";
            this.DetailsPanel1.Size = new System.Drawing.Size(325, 65);
            this.DetailsPanel1.TabIndex = 325;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Chocolate;
            this.label10.Location = new System.Drawing.Point(685, 49);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 18);
            this.label10.TabIndex = 191;
            this.label10.Text = "Produkt";
            // 
            // produktcombodetails
            // 
            this.produktcombodetails.BackColor = System.Drawing.Color.White;
            this.produktcombodetails.DropDownHeight = 150;
            this.produktcombodetails.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.produktcombodetails.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.produktcombodetails.FormattingEnabled = true;
            this.produktcombodetails.IntegralHeight = false;
            this.produktcombodetails.Location = new System.Drawing.Point(688, 70);
            this.produktcombodetails.Name = "produktcombodetails";
            this.produktcombodetails.Size = new System.Drawing.Size(308, 26);
            this.produktcombodetails.Sorted = true;
            this.produktcombodetails.TabIndex = 192;
            this.produktcombodetails.SelectedIndexChanged += new System.EventHandler(this.produktcombodetails_SelectedIndexChanged);
            // 
            // iconButton4
            // 
            this.iconButton4.BackColor = System.Drawing.Color.White;
            this.iconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton4.IconChar = FontAwesome.Sharp.IconChar.HandPaper;
            this.iconButton4.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton4.IconSize = 26;
            this.iconButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton4.Location = new System.Drawing.Point(507, 590);
            this.iconButton4.Name = "iconButton4";
            this.iconButton4.Size = new System.Drawing.Size(133, 35);
            this.iconButton4.TabIndex = 326;
            this.iconButton4.Text = "Abbrechen";
            this.iconButton4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconButton4.UseVisualStyleBackColor = false;
            this.iconButton4.Click += new System.EventHandler(this.iconButton4_Click);
            // 
            // txtschritt
            // 
            this.txtschritt.Enabled = false;
            this.txtschritt.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtschritt.Location = new System.Drawing.Point(12, 70);
            this.txtschritt.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtschritt.Name = "txtschritt";
            this.txtschritt.Size = new System.Drawing.Size(67, 26);
            this.txtschritt.TabIndex = 326;
            // 
            // iconButton3
            // 
            this.iconButton3.BackColor = System.Drawing.Color.White;
            this.iconButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton3.IconChar = FontAwesome.Sharp.IconChar.Trash;
            this.iconButton3.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton3.IconSize = 26;
            this.iconButton3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton3.Location = new System.Drawing.Point(687, 590);
            this.iconButton3.Name = "iconButton3";
            this.iconButton3.Size = new System.Drawing.Size(35, 35);
            this.iconButton3.TabIndex = 327;
            this.iconButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconButton3.UseVisualStyleBackColor = false;
            this.iconButton3.Click += new System.EventHandler(this.iconButton3_Click);
            // 
            // iconButton5
            // 
            this.iconButton5.BackColor = System.Drawing.Color.White;
            this.iconButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton5.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.iconButton5.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton5.IconSize = 26;
            this.iconButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton5.Location = new System.Drawing.Point(725, 590);
            this.iconButton5.Name = "iconButton5";
            this.iconButton5.Size = new System.Drawing.Size(35, 35);
            this.iconButton5.TabIndex = 328;
            this.iconButton5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconButton5.UseVisualStyleBackColor = false;
            this.iconButton5.Click += new System.EventHandler(this.iconButton5_Click);
            // 
            // iconButton6
            // 
            this.iconButton6.BackColor = System.Drawing.Color.White;
            this.iconButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton6.IconChar = FontAwesome.Sharp.IconChar.Trash;
            this.iconButton6.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton6.IconSize = 26;
            this.iconButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton6.Location = new System.Drawing.Point(646, 590);
            this.iconButton6.Name = "iconButton6";
            this.iconButton6.Size = new System.Drawing.Size(35, 35);
            this.iconButton6.TabIndex = 329;
            this.iconButton6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton6.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconButton6.UseVisualStyleBackColor = false;
            this.iconButton6.Click += new System.EventHandler(this.iconButton6_Click);
            // 
            // iconButton7
            // 
            this.iconButton7.BackColor = System.Drawing.Color.White;
            this.iconButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton7.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.iconButton7.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton7.IconSize = 26;
            this.iconButton7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton7.Location = new System.Drawing.Point(152, 590);
            this.iconButton7.Name = "iconButton7";
            this.iconButton7.Size = new System.Drawing.Size(35, 35);
            this.iconButton7.TabIndex = 330;
            this.iconButton7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton7.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconButton7.UseVisualStyleBackColor = false;
            this.iconButton7.Click += new System.EventHandler(this.iconButton7_Click);
            // 
            // ProdSchrittSuchen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1000, 635);
            this.Controls.Add(this.iconButton7);
            this.Controls.Add(this.iconButton6);
            this.Controls.Add(this.iconButton5);
            this.Controls.Add(this.iconButton3);
            this.Controls.Add(this.txtschritt);
            this.Controls.Add(this.iconButton4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.DetailsPanel2);
            this.Controls.Add(this.produktcombodetails);
            this.Controls.Add(this.iconButton2);
            this.Controls.Add(this.checknr);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.prodschrittedetail);
            this.Controls.Add(this.dgvlabel);
            this.Controls.Add(this.prodschritte);
            this.Controls.Add(this.iconButton1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.produktcombo);
            this.Controls.Add(this.txtbez);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DetailsPanel1);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ProdSchrittSuchen";
            this.Text = "ProdSchritt";
            this.Load += new System.EventHandler(this.ProdSchritt_Load);
            ((System.ComponentModel.ISupportInitialize)(this.prodschritte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodschrittedetail)).EndInit();
            this.DetailsPanel2.ResumeLayout(false);
            this.DetailsPanel2.PerformLayout();
            this.DetailsPanel1.ResumeLayout(false);
            this.DetailsPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtschritt)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox rohstoffmenge;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox rohstoffeinheit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox prodschrittcombo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label dgvlabel;
        private System.Windows.Forms.DataGridView prodschritte;
        private FontAwesome.Sharp.IconButton iconButton1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox produktcombo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtbez;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox rohstoffcombo;
        private System.Windows.Forms.DataGridView prodschrittedetail;
        private System.Windows.Forms.Label label9;
        private FontAwesome.Sharp.IconButton iconButton2;
        private System.Windows.Forms.CheckBox checknr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel DetailsPanel2;
        private System.Windows.Forms.Panel DetailsPanel1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox produktcombodetails;
        private FontAwesome.Sharp.IconButton iconButton4;
        private System.Windows.Forms.NumericUpDown txtschritt;
        private FontAwesome.Sharp.IconButton iconButton3;
        private FontAwesome.Sharp.IconButton iconButton5;
        private FontAwesome.Sharp.IconButton iconButton6;
        private FontAwesome.Sharp.IconButton iconButton7;
    }
}