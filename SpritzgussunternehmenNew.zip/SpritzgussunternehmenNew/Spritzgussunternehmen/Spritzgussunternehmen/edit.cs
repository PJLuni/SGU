﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.ComponentModel;

namespace Spritzgussunternehmen
{
    class edit
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = new OleDbCommand(); 
       
        public static void ClearTextBoxes(Control parent)
        {
            foreach (Control child in parent.Controls)
            {
                TextBox textBox = child as TextBox;
                if (textBox == null)
                    ClearTextBoxes(child);
                else
                    textBox.Text = "";
            }
        }

        public static void pageswitch(TabPage tabPage,TabControl TC)
        {
            if (TC.TabPages.Contains(tabPage))
            {
                MessageBox.Show("Sie können die Seite nicht zwei mal aufrufen");
            }
            else
            {

            }
        }

        public static void DataGridFuellen(string Nr,OleDbDataAdapter adap,DataGridView dataGridView)
        {
            
            DataSet ds = new DataSet();
            OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
            if (adap == null)
            {
                adap = new OleDbDataAdapter();
            }
            else
            {

            }

            ds.Clear();

            adap.Fill(ds, "filter");

            dataGridView.DataSource = ds;
            dataGridView.DataMember = "filter";

            dataGridView.Sort(dataGridView.Columns[Nr], ListSortDirection.Ascending);
        }

        public static void IstAktiv(OleDbDataAdapter adapter, DataGridView dataGridView, int zeile)
        {

            for (int i = dataGridView.Rows.Count-1; i >= 0; i--)
            {


                bool test = (bool)(dataGridView.Rows[i].Cells[zeile].Value);
           
            if (test == false)
            {
                    DataGridViewRow rowToRemove = dataGridView.Rows[i];
                    dataGridView.Rows.Remove(rowToRemove);
            }
            else
            {

            }
        }
        }
        public static void nrHochZaehlen(string tabelle,TextBox textBox)
        {
             OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
            OleDbCommand cmd = new OleDbCommand();
            OleDbDataReader dr = null;
            cmd = new OleDbCommand("SELECT count(Nr) FROM "+ tabelle +"", con);

            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();

            int Anzahl = dr.GetInt32(0);
            con.Close();

            if (Anzahl > 0)
            {
                cmd = new OleDbCommand("SELECT Max(Nr) FROM "+tabelle+"", con);

                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox.Text = Convert.ToString(dr.GetInt32(0) + 1);

                con.Close();
            }
            else
            {
                textBox.Text = "1";
            }
        }
        public static void colorChange(TextBox textBox)
        {
            textBox.ReadOnly = false;
            textBox.BackColor = Color.White;
        }

        public static void nummer(object sender, KeyPressEventArgs e,TextBox textBox)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
                && e.KeyChar != '0'
                && e.KeyChar != '1'
                && e.KeyChar != '2'
                && e.KeyChar != '3'
                && e.KeyChar != '4'
                && e.KeyChar != '5'
                && e.KeyChar != '6'
                && e.KeyChar != '7'
                && e.KeyChar != '8'
                && e.KeyChar != '9'
                && e.KeyChar != ',')
                {
                    e.Handled = true;
                    return;
                }
                e.Handled = false;
                return;
        }
       
    }
}
