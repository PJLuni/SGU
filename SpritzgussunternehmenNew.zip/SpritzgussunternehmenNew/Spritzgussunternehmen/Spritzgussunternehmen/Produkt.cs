﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Produkt
    {
        public static int txtnr;
        public static string txtbez;
        public static string txtart;
        public static string txthoehe;
        public static string txtlaenge;
        public static string txtbreite;
        public static string txtgewicht;
        public static string txtbeschreibung;
        public static string txteinheit;
        public static string txthpreis;
        public static string txtpreis;
        public static int txtaktbestand;

        private static DataSet ds = new DataSet();
        private static DataSet dsVerp = new DataSet();

        private static Helfer Manni = new Helfer();
        public static void LoadProdukte(ComboBox comboBox)
        {
            DB.cmd = DB.createCmd("SELECT Nr FROM Produkt WHERE IsActive = true");
            DB.getCon().Open();
            DB.dr = DB.cmd.ExecuteReader();

            while (DB.dr.Read())
            {
                comboBox.Items.Add(DB.dr.GetInt32(0));
            }
            DB.getCon().Close();
        }

        public static void LoadProdSchritt(ComboBox comboBox, int ProdNr)
        {
            DB.cmd = DB.createCmd($"SELECT count(*) FROM Produktionsschritt WHERE Produkt = {ProdNr}");
            DB.getCon().Open();
            int ProdCount = Convert.ToInt32(DB.cmd.ExecuteScalar());
            DB.getCon().Close();
            if (ProdCount > 0)
            {
                DB.cmd = DB.createCmd($"SELECT Nr FROM Produktionsschritt WHERE Produkt = {ProdNr}");
                DB.getCon().Open();
                DB.dr = DB.cmd.ExecuteReader();

                while (DB.dr.Read())
                {
                    comboBox.Items.Add(DB.dr.GetInt32(0));
                }
                DB.getCon().Close();
            }
        }

        public static string ProdBezForProdSchritt(int ProdNr)
        {
            DB.cmd = DB.createCmd($"SELECT Bez FROM Produkt WHERE Nr = {ProdNr}");
            DB.getCon().Open();
            DB.dr = DB.cmd.ExecuteReader();
            DB.dr.Read();
            string Bez = DB.dr.GetString(0);
            DB.getCon().Close();
            return Bez;
        }

        public static void LoadArten(ComboBox comboBox)
        {
            DB.cmd = DB.createCmd("SELECT Bez FROM Produktart");
            DB.getCon().Open();
            DB.dr = DB.cmd.ExecuteReader();

            while (DB.dr.Read())
            {
                comboBox.Items.Add(DB.dr.GetString(0));
            }
            DB.getCon().Close();
        }

        public static void SuchenDataGridFuellen(DataGridView DataGrid)
        {
            DB.adap = new OleDbDataAdapter("SELECT * FROM Produkt WHERE IsActive = true", DB.getCon());

            ds.Clear();

            DB.adap.Fill(ds, "Produkte");

            DataGrid.DataSource = ds;
            DataGrid.DataMember = "Produkte";
        }

        public static void VerpackungsDataGridFuellen(DataGridView DataGrid)
        {
            DB.adap = new OleDbDataAdapter($"SELECT Bez as Verpackung FROM Verpackungseinheit WHERE IsActive = true", DB.getCon());
            dsVerp.Clear();

            DB.adap.Fill(dsVerp, "Einheiten");

            DataGrid.DataSource = dsVerp;
            DataGrid.DataMember = "Einheiten";
            DataGrid.Columns[1].ReadOnly = true;
            DataGrid.Columns[1].DisplayIndex = 0;

            foreach (DataGridViewRow Row in DataGrid.Rows)
            {
                if (Row.Cells[1].Value.ToString() == "Stück")
                {
                    DataGrid.Rows.Remove(Row);
                }
            }
        }

        public static void ErstelleProdukt(DataGridView DGV)
        {
            try
            {
                DB.cmd = DB.createCmd($"SELECT Nr FROM Produktart WHERE Bez = '{txtart}'");
                DB.getCon().Open();
                int Produktart = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                DB.cmd = DB.createCmd($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{txteinheit}'");
                DB.getCon().Open();
                int Produkteinheit = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                DB.cmd = DB.createCmd($"SELECT * FROM Produkt WHERE Nr = {txtnr}");
                DB.getCon().Open();
                int prodexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();
                
                if(prodexist <= 0)
                {
                    try
                    {
                        DB.cmd = DB.createCmd($"INSERT INTO Produkt (Nr, Art, Bez, Hoehe, Breite, Laenge, Gewicht, Produktbeschreibung, Preis, Lagerbestand, Herstellungskosten, Gewichtseinheit, IsActive) " +
                                         $"VALUES ({txtnr}, {Produktart}, '{txtbez}', {txthoehe}, {txtbreite}, {txtlaenge}, {txtgewicht}, '{txtbeschreibung}' ,{txtpreis}, {txtaktbestand}, {txthpreis}, {Produkteinheit}, true)");
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        for (int rowcounter = 0; rowcounter < (DGV.RowCount); rowcounter++)
                        {
                            DB.cmd = DB.createCmd($"SELECT Nr FROM Verpackungseinheit WHERE Bez = '{DGV.Rows[rowcounter].Cells[1].Value}'");
                            DB.getCon().Open();
                            int Verpackung = Convert.ToInt32(DB.cmd.ExecuteScalar());
                            DB.getCon().Close();

                            int Menge = Convert.ToInt32(DGV.Rows[rowcounter].Cells[0].Value);
                            int VENr = Convert.ToInt32(Manni.LetzteNummer("Produktverpackungseinheit"));

                            DB.cmd = DB.createCmd($"INSERT INTO ProduktVerpackungseinheit (Nr, Produkt, Verpackungseinheit, Menge, IsActive) values ({VENr}, {txtnr}, {Verpackung}, {Menge}, true)");
                            DB.getCon().Open();
                            DB.cmd.ExecuteNonQuery();
                            DB.getCon().Close();
                        }

                        Info.Success("Produkt erfolgreich hinzugefügt!");
                    }
                    catch (Exception)
                    {
                        Info.Error("Fehler beim erstellen!");
                    }
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
            
        }

        public static void BearbeiteProdukt()
        {
            try
            {
                DB.cmd = DB.createCmd($"SELECT Nr FROM Produktart WHERE Bez = '{txtart}'");
                DB.getCon().Open();
                int Produktart = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                DB.cmd = DB.createCmd($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{txteinheit}'");
                DB.getCon().Open();
                int Produkteinheit = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                DB.cmd = DB.createCmd($"SELECT * FROM Produkt WHERE Nr = {txtnr}");
                DB.getCon().Open();
                int prodexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                if (prodexist > 0)
                {
                    DB.cmd = DB.createCmd($"UPDATE Produkt SET Art = {Produktart}, Bez = '{txtbez}', Hoehe = {txthoehe}, Breite = {txtbreite}, Laenge = {txtlaenge}, Gewicht = {txtgewicht}, Produktbeschreibung = '{txtbeschreibung}', Preis = {txtpreis}, Lagerbestand = {txtaktbestand}, Herstellungskosten = {txthpreis}, Gewichtseinheit = {Produkteinheit} WHERE Nr = {txtnr}");
                    DB.getCon().Open();
                    DB.cmd.ExecuteNonQuery();
                    DB.getCon().Close();

                    Info.Success("Produkt wurde erfolgreich bearbeitet!");
                }
                else
                {
                    Info.Error("Produkt existiert nicht!");
                }

            }
            catch (Exception Error)
            {
                Info.Error("Fehler beim bearbeiten!");
            }
        }

        public static void LoescheProdukt(DataGridView DataGrid)
        {
            try
            {
                DialogResult result = MessageBox.Show("Sind Sie sicher das Sie das ausgewählte Produkt löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    DataGridViewRow row = DataGrid.SelectedRows[0];
                    string ZuLoeschen = row.Cells[0].Value.ToString();

                    DB.cmd = DB.createCmd($"UPDATE Produkt SET IsActive = false WHERE Nr = {ZuLoeschen}");
                    DB.getCon().Open();
                    DB.cmd.ExecuteNonQuery();
                    DB.getCon().Close();

                    DataGrid.Rows.Remove(row);
                }
            }
            catch (Exception)
            {
                Info.Error("Fehler beim löschen!");
            }
        }

        public static void SucheProdukt(string Search, DataGridView DataGrid)
        {
            try
            {
                bool check = int.TryParse(Search, out _);

                if (check)
                {
                    DB.adap = new OleDbDataAdapter($"SELECT * FROM Produkt WHERE Nr LIKE '%{Search}%' AND IsActive = true", DB.getCon());

                    ds.Clear();

                    DB.adap.Fill(ds, "Produktart");

                    DataGrid.DataSource = ds;
                    DataGrid.DataMember = "Produktart";
                }
                else
                {
                    DB.adap = new OleDbDataAdapter($"SELECT * FROM Produkt WHERE Bez LIKE '%{Search}%' AND IsActive = true", DB.getCon());

                    ds.Clear();

                    DB.adap.Fill(ds, "Produkt");

                    DataGrid.DataSource = ds;
                    DataGrid.DataMember = "Produkt";
                }
            }
            catch (Exception)
            {
                Info.Error("Fehler beim Suchen!");
            }
        }
    }
}
