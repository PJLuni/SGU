﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class Paletteadd : Form
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        TabControl TC;
        long pNr;
        public Paletteadd(long pNr, TabControl TC)
        {
            this.TC = TC;
            this.pNr = pNr;
            InitializeComponent();
        }
        public void paletteBearbeitenLoad()
        {
            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand("Select * from Palette where Nr = " + pNr + "", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox17.Text = Convert.ToString(dr.GetInt32(0));
                textBox1.Text = dr.GetString(1);
                textBox2.Text = Convert.ToString(dr.GetInt32(2));
                textBox3.Text = Convert.ToString(dr.GetInt32(3));
                textBox4.Text = Convert.ToString(dr.GetInt32(4));
                textBox5.Text = Convert.ToString(dr.GetInt32(5));
                textBox6.Text = Convert.ToString(dr.GetValue(6)) + " €";
                checkBox2.Checked = dr.GetBoolean(7);
                con.Close();
            }
            catch { }
        }
        public void paletteHinzufuegenLoad()
        {
            edit.nrHochZaehlen("Palette", textBox17);
        }
        public void paletteHinzufuegen()
        {
            try {
                if (pNr == 0)
                {
                    if (textBox17.TextLength > 0)
                    {
                        con.Open();
                        cmd = new OleDbCommand("Insert into Palette (Nr, Bez, Lagerbestand, Laenge, Hoehe, Breite, Kosten, IsActive) values ('" + textBox17.Text + "', '" + textBox1.Text + "', '" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "', '" + textBox5.Text + "', '" + textBox6.Text + "'," + checkBox2.Checked + ")", con);

                        cmd.ExecuteNonQuery();
                        con.Close();

                    } else
                    {
                        MessageBox.Show("Geben sie eine Nummer ein");
                    }
                }
            }
            catch { }
        }

        private void Paletteadd_Load(object sender, EventArgs e)
        {
            if (pNr>0)
            {
                label17.Text = "Palette bearbeiten";
                paletteBearbeitenLoad();
            }
            else
            {
                label17.Text= "Palette hinzufügen";
                paletteHinzufuegenLoad();

            }
           Info.Information("Alle Maße in millimeter");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox17.TextLength > 0)
                {
                    if (textBox1.TextLength > 0)
                    {
                        if (textBox2.TextLength > 0)
                        {
                            if (textBox3.TextLength > 0)
                            {
                                if (textBox4.TextLength > 0)
                                {
                                    if (textBox5.TextLength > 0)
                                    {
                                        if (textBox6.TextLength > 0)
                                        {

                                            if (pNr > 0)
                                            {
                                                if (!checkBox2.Checked)
                                                {

                                                    adap = new OleDbDataAdapter("SELECT DISTINCT AuftragLieferungPalette.Palette FROM AuftragLieferungPalette,Auftrag, Kunde, Auftragsstatus, AuftragLieferung, Palette" +
                                                    " WHERE Palette.Nr = AuftragLieferungPalette.Palette and AuftragLieferungPalette.Palette = " + pNr + " and AuftragLieferung.Nr = AuftragLieferungPalette.AuftragLieferung and " +
                                                    "AuftragLieferung.Auftrag = Auftrag.Nr and Auftrag.Status = Auftragsstatus.Nr and Auftrag.Status = 2 and Palette.IsActive = true;", con);
                                                    con.Open();
                                                    DataTable dt = new DataTable();
                                                    DataRow d = dt.NewRow();
                                                    adap.Fill(dt);
                                                    con.Close();

                                                    if (dt.Rows.Count >= 1)
                                                    {
                                                        MessageBox.Show("Sie Können die Palette nicht löschen, da sie in einem Auftrag vorkommt der noch in Bearbeitung ist.");
                                                    }
                                                    else
                                                    {
                                                        DialogResult result = MessageBox.Show("Sind Sie sicher das Sie die ausgewählte Palette auf unaktiv setzen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                                        if (result == DialogResult.Yes)
                                                        {

                                                            con.Open();
                                                            cmd = new OleDbCommand("update Palette set Bez = '" + textBox1.Text.ToString() + "', Lagerbestand = '" + textBox2.Text.ToString() + "', Laenge = '" + textBox3.Text.ToString() + "', Hoehe = '" + textBox4.Text.ToString() + "', Breite = '" + textBox5.Text.ToString() + "', Kosten = '" + textBox6.Text.ToString() + "', IsActive = " + checkBox2.Checked + " where Nr = " + Convert.ToInt64(textBox17.Text) + "", con);

                                                            cmd.ExecuteNonQuery();

                                                            con.Close();

                                                            MessageBox.Show("Update erfolgreich");

                                                            TabPage selectedpage = TC.SelectedTab;

                                                            TC.TabPages.Remove(selectedpage);
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    con.Open();
                                                    cmd = new OleDbCommand("update Palette set Bez = '" + textBox1.Text.ToString() + "', Lagerbestand = '" + textBox2.Text.ToString() + "', Laenge = '" + textBox3.Text.ToString() + "', Hoehe = '" + textBox4.Text.ToString() + "', Breite = '" + textBox5.Text.ToString() + "', Kosten = '" + textBox6.Text.ToString() + "', IsActive = " + checkBox2.Checked + " where Nr = " + Convert.ToInt64(textBox17.Text) + "", con);

                                                    cmd.ExecuteNonQuery();

                                                    con.Close();

                                                    MessageBox.Show("Update erfolgreich");

                                                    TabPage selectedpage = TC.SelectedTab;

                                                    TC.TabPages.Remove(selectedpage);
                                                }

                                            }
                                            else
                                            {
                                                paletteHinzufuegen();

                                                MessageBox.Show("Neue Palette wurde erstellt!");

                                                TabPage selectedpage = TC.SelectedTab;

                                                TC.TabPages.Remove(selectedpage);
                                            }

                                        }
                                        else
                                        {
                                            MessageBox.Show("Geben sie die Kosten für die Palette ein !");
                                            textBox6.Focus();
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Geben sie eine Breite ein!");
                                        textBox5.Focus();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Geben sie eine Höhe ein!");
                                    textBox4.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Geben sie eine Länge ein!");
                                textBox3.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Geben sie ein Lagerbestand ein!");
                            textBox2.Focus();
                        }

                    }
                    else
                    {
                        MessageBox.Show("Geben sie eine Bezeichnung ein!");
                        textBox1.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Geben sie eine Nummer ein!");
                    textBox17.Focus();
                }

            }
            catch { }



            }
        private void textBox17_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            edit.colorChange(textBox17);
        }

        private void textBox17_Leave(object sender, EventArgs e)
        {
            try {
                if (textBox17.TextLength <= 0)
                {
                    if (pNr > 0)
                    {
                        textBox17.Text = Convert.ToString(pNr);
                    }
                    else
                    {
                        edit.nrHochZaehlen("Kunde", textBox17);
                    }
                    textBox17.ReadOnly = true;
                    textBox17.BackColor = Color.FromArgb(224, 224, 224);
                }
                else
                {
                    if (pNr > 0)
                    {
                        if (textBox17.Text == Convert.ToString(pNr))
                        {
                            textBox17.ReadOnly = true;
                            textBox17.BackColor = Color.FromArgb(224, 224, 224);
                        }
                        else
                        {
                            MessageBox.Show("Sie können die Nummer nicht ändern, da sie eine Palette Bearbeiten");
                            textBox17.Text = Convert.ToString(pNr);
                            textBox17.ReadOnly = true;
                            textBox17.BackColor = Color.FromArgb(224, 224, 224);
                        }
                    }
                    else
                    {
                        adap = new OleDbDataAdapter("SELECT Palette.Nr from Palette where Palette.Nr = " + textBox17.Text + "", con);

                        DataTable dt = new DataTable();
                        DataRow d = dt.NewRow();
                        adap.Fill(dt);

                        if (dt.Rows.Count < 1)
                        {
                            textBox17.ReadOnly = true;
                            textBox17.BackColor = Color.FromArgb(224, 224, 224);
                        }
                        else
                        {

                            MessageBox.Show("Diese Palettennummer ist bereits von vorhanden");
                            textBox17.Clear();
                            textBox17.Focus();

                        }
                    }
                }
            }
            catch { }
        }

        private void textBox17_KeyPress(object sender, KeyPressEventArgs e)
        {
            edit.nummer(sender, e, textBox17);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            edit.nummer(sender, e, textBox2);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            edit.nummer(sender, e, textBox3);
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            edit.nummer(sender, e, textBox4);
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            edit.nummer(sender, e, textBox6);
        }
        
        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            edit.nummer(sender, e, textBox6);
        }

        }
    }

