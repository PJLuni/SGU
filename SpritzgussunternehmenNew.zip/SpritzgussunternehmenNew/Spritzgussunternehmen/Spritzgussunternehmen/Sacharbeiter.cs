﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace Spritzgussunternehmen
{
    class Sacharbeiter
    {
        private static DataSet ds = new DataSet();
        private static Helfer Manni = new Helfer();
        public static void LoadSacharbeiter(ComboBox comboBox)
        {
            DB.cmd = DB.createCmd("SELECT Nr FROM Benutzerkonto WHERE IsActive = true");
            DB.getCon().Open();
            DB.dr = DB.cmd.ExecuteReader();

            while (DB.dr.Read())
            {
                comboBox.Items.Add(DB.dr.GetInt32(0));
            }
            DB.getCon().Close();
        }
        public static void SuchenDataGridFuellen(DataGridView DataGrid)
        {
            DB.adap = new OleDbDataAdapter("SELECT * FROM Benutzerkonto WHERE IsActive = true", DB.getCon());

            ds.Clear();

            DB.adap.Fill(ds, "Sacharbeiter");

            DataGrid.DataSource = ds;
            DataGrid.DataMember = "Sacharbeiter";
        }
        public static void ErstelleSacharbeiter(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Name = Data[1];
                    string Vorname = Data[2];
                    string Benutzername = Data[3];
                    string Passwort = Data[4];

                    DB.cmd = new OleDbCommand($"SELECT count(*) FROM Benutzerkonto WHERE Nr = {Nr} OR Benutzername = '{Benutzername}'", DB.getCon());
                    DB.getCon().Open();
                    int saexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (saexist <= 0)
                    {
                        string Hash = Manni.HashPassword(Passwort, new SHA256CryptoServiceProvider());
                        DB.cmd = DB.createCmd($"INSERT INTO Benutzerkonto (Nr, Nachname, Vorname, Benutzername, Passwort, IsActive) " +
                                              $"VALUES ({Nr}, '{Name}', '{Vorname}', '{Benutzername}', '{Hash}', true)");
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        Info.Success("Sacharbeiter wurde erfolgreich hinzugefügt!");
                    }
                    else
                    {
                        Info.Error("Sacharbeiter existiert bereits!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
        public static void BearbeiteSacharbeiter(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Name = Data[1];
                    string Vorname = Data[2];
                    string Benutzername = Data[3];

                    DB.cmd = DB.createCmd($"SELECT count(*) FROM Benutzerkonto WHERE Nr = {Nr}");
                    DB.getCon().Open();
                    int saexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (saexist > 0)
                    {
                        DB.cmd = new OleDbCommand($"SELECT count(*) FROM Benutzerkonto WHERE Benutzername = '{Benutzername}'", DB.getCon());
                        DB.getCon().Open();
                        int saexistbname = Convert.ToInt32(DB.cmd.ExecuteScalar());
                        DB.getCon().Close();

                        if (saexistbname <= 0)
                        {
                            DB.cmd = DB.createCmd($"UPDATE Benutzerkonto SET Nachname = '{Name}', Vorname = '{Vorname}', Benutzername = '{Benutzername}', IsActive = true WHERE Nr = {Nr}");
                            DB.getCon().Open();
                            DB.cmd.ExecuteNonQuery();
                            DB.getCon().Close();

                            Info.Success("Sacharbeiter wurde erfolgreich bearbeitet!");
                        }
                        else
                        {
                            Info.Error("Benutzername existiert bereits!");
                        }
                    }
                    else
                    {
                        Info.Error("Sacharbeiter existiert nicht!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }
        public static void LoescheSacharbeiter(DataGridView DataGrid)
        {
            DialogResult result = MessageBox.Show("Sind Sie sicher das Sie den ausgewählten Sacharbeiter löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                if (DataGrid.SelectedRows.Count != 0)
                {
                    DataGridViewRow row = DataGrid.SelectedRows[0];
                    string ZuLoeschen = row.Cells[0].Value.ToString();

                    DB.cmd = DB.createCmd($"SELECT count(*) FROM Benutzerkonto WHERE Nr = {ZuLoeschen}");
                    DB.getCon().Open();
                    int saexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (saexist > 0)
                    {
                        DB.cmd = DB.createCmd($"UPDATE Benutzerkonto SET IsActive = false WHERE Nr = {ZuLoeschen}");
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        DataGrid.Rows.Remove(row);

                        Info.Success("Sacharbeiter wurde erfolgreich gelöscht!");
                    }
                    else
                    {
                        Info.Error("Sacharbeiter existiert nicht!");
                    }
                }
                else
                {
                    Info.Error("Bitte wählen Sie einen Sacharbeiter aus!");
                }
            }
        }
        public static void SucheSacharbeiter(string Search, DataGridView DataGrid)
        {
            try
            {
                bool check = int.TryParse(Search, out _);

                if (check)
                {
                    DB.adap = new OleDbDataAdapter($"SELECT * FROM Benutzerkonto WHERE Nr LIKE '%{Search}%' AND IsActive = true", DB.getCon());

                    ds.Clear();

                    DB.adap.Fill(ds, "Sacharbeiter");

                    DataGrid.DataSource = ds;
                    DataGrid.DataMember = "Sacharbeiter";
                }
                else
                {
                    DB.adap = new OleDbDataAdapter($"SELECT * FROM Benutzerkonto WHERE Name LIKE '%{Search}%' AND IsActive = true", DB.getCon());

                    ds.Clear();

                    DB.adap.Fill(ds, "Sacharbeiter");

                    DataGrid.DataSource = ds;
                    DataGrid.DataMember = "Sacharbeiter";
                }
            }
            catch (Exception)
            {
                Info.Error("Fehler beim Suchen!");
            }
        }
        public static void SachbearbeiterAuftrag(string ausgewählteZeile)
        {
            DB.createCmd("select Benutzerkonto.Nr from Benutzerkonto where Nr = " + System.Convert.ToInt64(ausgewählteZeile) + "");

            DB.getCon().Open();
            AuftragAdd.sachbearbeiter = Convert.ToInt32(DB.cmd.ExecuteScalar());
            DB.getCon().Close();

            AuftragAdd.sachbearbeiterAnzeigen = 0;

        }
    }
}
