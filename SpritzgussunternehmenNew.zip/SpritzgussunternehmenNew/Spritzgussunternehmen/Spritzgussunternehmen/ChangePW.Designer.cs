﻿namespace Spritzgussunternehmen
{
    partial class ChangePW
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.newpwagain = new System.Windows.Forms.TextBox();
            this.newpw = new System.Windows.Forms.TextBox();
            this.iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            this.oldpw = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(377, 251);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(293, 22);
            this.label1.TabIndex = 52;
            this.label1.Text = "Firmenname - Passwort ändern";
            // 
            // iconPictureBox3
            // 
            this.iconPictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.iconPictureBox3.ForeColor = System.Drawing.Color.Chocolate;
            this.iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.UserLock;
            this.iconPictureBox3.IconColor = System.Drawing.Color.Chocolate;
            this.iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox3.IconSize = 96;
            this.iconPictureBox3.Location = new System.Drawing.Point(473, 152);
            this.iconPictureBox3.Name = "iconPictureBox3";
            this.iconPictureBox3.Size = new System.Drawing.Size(103, 96);
            this.iconPictureBox3.TabIndex = 51;
            this.iconPictureBox3.TabStop = false;
            // 
            // iconPictureBox2
            // 
            this.iconPictureBox2.BackColor = System.Drawing.Color.White;
            this.iconPictureBox2.ForeColor = System.Drawing.Color.Chocolate;
            this.iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.RedoAlt;
            this.iconPictureBox2.IconColor = System.Drawing.Color.Chocolate;
            this.iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox2.IconSize = 29;
            this.iconPictureBox2.Location = new System.Drawing.Point(371, 378);
            this.iconPictureBox2.Name = "iconPictureBox2";
            this.iconPictureBox2.Padding = new System.Windows.Forms.Padding(3, 2, 0, 0);
            this.iconPictureBox2.Size = new System.Drawing.Size(32, 29);
            this.iconPictureBox2.TabIndex = 50;
            this.iconPictureBox2.TabStop = false;
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.BackColor = System.Drawing.Color.White;
            this.iconPictureBox1.ForeColor = System.Drawing.Color.Chocolate;
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Key;
            this.iconPictureBox1.IconColor = System.Drawing.Color.Chocolate;
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.IconSize = 29;
            this.iconPictureBox1.Location = new System.Drawing.Point(371, 335);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 0);
            this.iconPictureBox1.Size = new System.Drawing.Size(32, 29);
            this.iconPictureBox1.TabIndex = 49;
            this.iconPictureBox1.TabStop = false;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.Color.White;
            this.checkBox1.Location = new System.Drawing.Point(371, 425);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(129, 16);
            this.checkBox1.TabIndex = 48;
            this.checkBox1.Text = "Passwort anzeigen";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Coral;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Chocolate;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(371, 447);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(308, 33);
            this.button1.TabIndex = 47;
            this.button1.Text = "Passwort ändern";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // newpwagain
            // 
            this.newpwagain.BackColor = System.Drawing.Color.White;
            this.newpwagain.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newpwagain.ForeColor = System.Drawing.Color.Gray;
            this.newpwagain.Location = new System.Drawing.Point(403, 378);
            this.newpwagain.Name = "newpwagain";
            this.newpwagain.Size = new System.Drawing.Size(276, 29);
            this.newpwagain.TabIndex = 46;
            this.newpwagain.Text = "Neues Passwort wiederholen";
            this.newpwagain.Enter += new System.EventHandler(this.newpwagain_Enter);
            this.newpwagain.Leave += new System.EventHandler(this.newpwagain_Leave);
            // 
            // newpw
            // 
            this.newpw.BackColor = System.Drawing.Color.White;
            this.newpw.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newpw.ForeColor = System.Drawing.Color.Gray;
            this.newpw.Location = new System.Drawing.Point(403, 335);
            this.newpw.Name = "newpw";
            this.newpw.Size = new System.Drawing.Size(276, 29);
            this.newpw.TabIndex = 45;
            this.newpw.Text = "Neues Passwort";
            this.newpw.Enter += new System.EventHandler(this.newpw_Enter);
            this.newpw.Leave += new System.EventHandler(this.newpw_Leave);
            // 
            // iconPictureBox4
            // 
            this.iconPictureBox4.BackColor = System.Drawing.Color.White;
            this.iconPictureBox4.ForeColor = System.Drawing.Color.Chocolate;
            this.iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.Key;
            this.iconPictureBox4.IconColor = System.Drawing.Color.Chocolate;
            this.iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox4.IconSize = 29;
            this.iconPictureBox4.Location = new System.Drawing.Point(371, 291);
            this.iconPictureBox4.Name = "iconPictureBox4";
            this.iconPictureBox4.Padding = new System.Windows.Forms.Padding(4, 2, 0, 0);
            this.iconPictureBox4.Size = new System.Drawing.Size(32, 29);
            this.iconPictureBox4.TabIndex = 54;
            this.iconPictureBox4.TabStop = false;
            // 
            // oldpw
            // 
            this.oldpw.BackColor = System.Drawing.Color.White;
            this.oldpw.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oldpw.ForeColor = System.Drawing.Color.Gray;
            this.oldpw.Location = new System.Drawing.Point(403, 291);
            this.oldpw.Name = "oldpw";
            this.oldpw.Size = new System.Drawing.Size(276, 29);
            this.oldpw.TabIndex = 53;
            this.oldpw.Text = "Altes Passwort";
            this.oldpw.Enter += new System.EventHandler(this.oldpw_Enter);
            this.oldpw.Leave += new System.EventHandler(this.oldpw_Leave);
            // 
            // ChangePW
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1048, 676);
            this.Controls.Add(this.iconPictureBox4);
            this.Controls.Add(this.oldpw);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.iconPictureBox3);
            this.Controls.Add(this.iconPictureBox2);
            this.Controls.Add(this.iconPictureBox1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.newpwagain);
            this.Controls.Add(this.newpw);
            this.Name = "ChangePW";
            this.Text = "ChangePW";
            this.Load += new System.EventHandler(this.ChangePW_Load);
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox newpwagain;
        private System.Windows.Forms.TextBox newpw;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private System.Windows.Forms.TextBox oldpw;
    }
}