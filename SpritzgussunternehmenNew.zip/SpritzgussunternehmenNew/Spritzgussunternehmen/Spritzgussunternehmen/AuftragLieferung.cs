﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    public partial class AuftragLieferung : Form
    {
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        public AuftragLieferung()
        {
            InitializeComponent();
        }
       
        public static int auftragLieferung = 0;
        public void lieferbdingungen()
        {
            try
            {
                comboBox2.Text = "";
                comboBox2.Items.Clear();
                con.Open();
                cmd = new OleDbCommand("SELECT Lieferbedingungen.Bez FROM Lieferbedingungen " +
                    "where Lieferbedingungen.IsActive = true", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    comboBox2.Items.Add(dr.GetString(0));
                }
                con.Close();
            }
            catch { }
        }
        public void kundeLieferort()
        {
            try
            {
                comboBox3.Text = "";
                comboBox3.Items.Clear();
                con.Open();
                cmd = new OleDbCommand("SELECT KundeLieferort.Bez FROM KundeLieferort,Kunde " +
                    "where KundeLieferort.IsActive = true and KundeLieferort.Kunde = Kunde.Nr and Kunde.Nr = " + AuftragAdd.kundenNummer + "", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    comboBox3.Items.Add(dr.GetString(0));
                }
                con.Close();
            }
            catch { }
        }
        private void iconButton3_Click(object sender, EventArgs e)
        {
            try
            {
                auftragLieferung = 1;
                String[] row = { textBox18.Text, Convert.ToString(comboBox2.Text), Convert.ToString(comboBox3.Text), Convert.ToString(dateTimePicker3.Value), textBox3.Text };
                AuftragAdd.rows = row;



                int hochzählen = Convert.ToInt32(textBox18.Text);
                int hochgezaehlt = hochzählen + 1;
                textBox18.Text = Convert.ToString(hochgezaehlt);
                comboBox2.Items.Clear();
                comboBox2.Text = "";
                comboBox3.Items.Clear();
                comboBox3.Text = "";
                textBox3.Text = "";
            }
            catch { }
        }

        private void AuftragLieferung_Load(object sender, EventArgs e)
        {
            try {
                textBox18.Text = "";
                comboBox2.Items.Clear();
                comboBox2.Text = "";

                comboBox3.Text = "";
                comboBox3.Items.Clear();
                comboBox3.Text = "";
                textBox3.Text = "";

                if (AuftragAdd.nummerLieferung == 0)
                {
                    edit.nrHochZaehlen("AuftragLieferung", textBox18);
                }
                else
                {
                    textBox18.Text = Convert.ToString(AuftragAdd.nummerLieferung);
                }
                lieferbdingungen();
                kundeLieferort();
            }
            catch { }


             }
        private void AuftragLieferung_Enter(object sender, EventArgs e)
        {
            try
            {
                lieferbdingungen();
                kundeLieferort();
            }
            catch { }
        }
    }
}
