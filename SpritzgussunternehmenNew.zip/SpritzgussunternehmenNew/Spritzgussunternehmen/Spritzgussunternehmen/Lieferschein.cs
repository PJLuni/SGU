﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Lieferschein
    {
        public static int Nr;
        public static string EinheitBez;
        public static int AuftragLieferung;
        public static int Kunde;
        public static string Zustellung;
        public static string Gewicht;


        private static DataSet ds = new DataSet();
        public static void LoadLieferscheine(ComboBox comboBox)
        {
            DB.cmd = DB.createCmd("SELECT Nr FROM Lieferschein");
            DB.getCon().Open();
            DB.dr = DB.cmd.ExecuteReader();

            while (DB.dr.Read())
            {
                comboBox.Items.Add(DB.dr.GetInt32(0));
            }
            DB.getCon().Close();
        }

        public static void SuchenDataGridFuellen(DataGridView DataGrid)
        {
            DB.adap = new OleDbDataAdapter("SELECT * FROM Lieferschein", DB.getCon());

            ds.Clear();

            DB.adap.Fill(ds, "Lieferscheine");

            DataGrid.DataSource = ds;
            DataGrid.DataMember = "Lieferscheine";
        }

        public static void ErstelleLieferschein()
        {
            try
            {
                DB.cmd = new OleDbCommand($"SELECT count(*) FROM Lieferschein WHERE Nr = {Nr} OR AuftragLieferung = {AuftragLieferung}", DB.getCon());
                DB.getCon().Open();
                int liefexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                DB.getCon().Close();

                if (liefexist <= 0)
                {
                    DB.cmd = new OleDbCommand($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{EinheitBez}'", DB.getCon());
                    DB.getCon().Open();
                    int Einheit = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    DB.cmd = new OleDbCommand($"INSERT INTO Lieferschein (Nr, Gewichteinheit, AuftragLieferung, Kunde, Zustellung, Gewicht) " +
                                              $"VALUES ({Nr}, {Einheit}, {AuftragLieferung}, {Kunde}, '{Zustellung}', {Gewicht})", DB.getCon());
                    DB.getCon().Open();
                    DB.cmd.ExecuteNonQuery();
                    DB.getCon().Close();

                    Info.Success("Lieferschein erfolgreich hinzugefügt!");
                }
                else
                {
                    Info.Error("Lieferschein existiert bereits!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }

        public static void BearbeiteRohstoff()
        {
            try
            {
                //DB.cmd = new OleDbCommand($"SELECT count(*) FROM Rohstoff WHERE Nr = {Nr}", DB.getCon());
                //DB.getCon().Open();
                //int rohexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                //DB.getCon().Close();

                //if (rohexist > 0)
                //{
                //    DB.cmd = new OleDbCommand($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{Data[3]}'", DB.getCon());
                //    DB.getCon().Open();
                //    int Einheit = Convert.ToInt32(DB.cmd.ExecuteScalar());
                //    DB.getCon().Close();

                //    DB.cmd = new OleDbCommand($"UPDATE Rohstoff SET Bez = '{Bez}', Lagerbestand = {Menge}, Mengeneinheit = {Einheit}, Kosten = {Preis}, IsActive = true WHERE Nr = {Nr}", DB.getCon());
                //    DB.getCon().Open();
                //    DB.cmd.ExecuteNonQuery();
                //    DB.getCon().Close();

                //    Info.Success("Rohstoff wurde erfolgreich bearbeitet!");
                //}
                //else
                //{
                //    Info.Error("Rohstoff existiert nicht!");
                //}
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }

        public static void LoescheLieferschein(DataGridView DataGrid)
        {
            DialogResult result = MessageBox.Show("Sind Sie sicher das Sie den ausgewählten Lieferschein löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                if (DataGrid.SelectedRows.Count != 0)
                {
                    DataGridViewRow row = DataGrid.SelectedRows[0];
                    string ZuLoeschen = row.Cells[0].Value.ToString();

                    DB.cmd = new OleDbCommand($"SELECT count(*) FROM Lieferschein WHERE Nr = {ZuLoeschen}", DB.getCon());
                    DB.getCon().Open();
                    int liefexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (liefexist > 0)
                    {
                        DB.cmd = new OleDbCommand($"REMOVE Lieferschein WHERE Nr = {ZuLoeschen}", DB.getCon());
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        DataGrid.Rows.Remove(row);

                        Info.Success("Lieferschein rfolgreich gelöscht!");
                    }
                    else
                    {
                        Info.Error("Lieferschein existiert nicht!");
                    }
                }
                else
                {
                    Info.Error("Bitte wählen Sie einen Lieferschein aus!");
                }
            }
        }
    
    }
}
