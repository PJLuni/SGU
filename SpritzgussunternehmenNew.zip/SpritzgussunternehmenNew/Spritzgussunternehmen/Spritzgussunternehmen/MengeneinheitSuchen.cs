﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class MengeneinheitSuchen : Form
    {
        TabControl TC;
        Helfer Manni = new Helfer();
        public MengeneinheitSuchen(TabControl TC)
        {
            InitializeComponent();
            this.TC = TC;
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            TabPage TPEh = new TabPage();
            TPEh.Text = "Verpackungseinheit";
            TC.TabPages.Add(TPEh);
            LoadForm.OpenTab(new VerpackungseinheitSuchen(TC), TPEh);
            TC.TabPages.RemoveAt(0);
        }

        private void MengeneinheitSuchen_Load(object sender, EventArgs e)
        {
            Mengeneinheit.SuchenDataGridFuellen(Mengeneinheiten);
            txtnr.Text = Manni.LetzteNummer("Mengeneinheit").ToString();
            Mengeneinheiten.ClearSelection();
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            Mengeneinheit.LoescheMengeneinheit(Mengeneinheiten);
        }

        private void checknr_CheckedChanged(object sender, EventArgs e)
        {
            if (txtnr.Enabled == false)
            {
                txtnr.Enabled = true;
                txtnr.Clear();
            }
            else
            {
                txtnr.Enabled = false;
                txtnr.Text = Manni.LetzteNummer("Mengeneinheit").ToString();
            }
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            if (btnehadd.Text == "Einheit hinzufügen")
            {
                txtnr.Text = Manni.LetzteNummer("Mengeneinheit").ToString();
                txtbez.Clear();
                checknr.Checked = false;
                txtnr.Enabled = false;
            }
            else
            {
                txtnr.Text = Manni.LetzteNummer("Mengeneinheit").ToString();
                txtbez.Clear();
                Mengeneinheiten.ClearSelection();
                btnehadd.Text = "Einheit hinzufügen";
                checknr.Enabled = true;
                checknr.Checked = false;
                txtnr.Enabled = false;
            }
        }

        private void Mengeneinheiten_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (Mengeneinheiten.SelectedRows.Count > 0)
                {
                    int MengNr = Convert.ToInt32(Mengeneinheiten.SelectedRows[0].Cells[0].Value);
                    string Bez = Mengeneinheiten.SelectedRows[0].Cells[1].Value.ToString();

                    txtnr.Text = MengNr.ToString();
                    txtbez.Text = Bez;

                    btnehadd.Text = "Einheit bearbeiten";
                    checknr.Enabled = false;
                    checknr.Checked = false;
                    txtnr.Enabled = false;
                }
            }
            catch (Exception err)
            {
                throw err;
            }
        }

        private void btnehadd_Click(object sender, EventArgs e)
        {
            List<string> DataToFill = new List<string>();
            DataToFill.Add(txtnr.Text);
            DataToFill.Add(txtbez.Text);

            switch (btnehadd.Text)
            {
                case "Einheit hinzufügen":
                    Mengeneinheit.ErstelleMengeneinheit(DataToFill);
                    txtnr.Text = Manni.LetzteNummer("Mengeneinheit").ToString();
                    break;
                case "Einheit bearbeiten":
                    Mengeneinheit.BearbeiteMengeneinheit(DataToFill);
                    break;
            }

            Mengeneinheiten.DataSource = null;
            Mengeneinheit.SuchenDataGridFuellen(Mengeneinheiten);
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            Mengeneinheit.SucheMengeneinheit(textBox1.Text, Mengeneinheiten);
        }

        private void iconButton7_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            Mengeneinheit.SuchenDataGridFuellen(Mengeneinheiten);
        }
    }
}
