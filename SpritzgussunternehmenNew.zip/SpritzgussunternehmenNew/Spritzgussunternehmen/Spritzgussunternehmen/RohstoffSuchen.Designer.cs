﻿namespace Spritzgussunternehmen
{
    partial class RohstoffSuchen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.iconButton5 = new FontAwesome.Sharp.IconButton();
            this.btnrohadd = new FontAwesome.Sharp.IconButton();
            this.iconButton3 = new FontAwesome.Sharp.IconButton();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Rohstoffe = new System.Windows.Forms.DataGridView();
            this.label11 = new System.Windows.Forms.Label();
            this.txtbez = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtmenge = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtpreis = new System.Windows.Forms.TextBox();
            this.txtnr = new System.Windows.Forms.TextBox();
            this.txteinheit = new System.Windows.Forms.ComboBox();
            this.checknr = new System.Windows.Forms.CheckBox();
            this.iconButton6 = new FontAwesome.Sharp.IconButton();
            ((System.ComponentModel.ISupportInitialize)(this.Rohstoffe)).BeginInit();
            this.SuspendLayout();
            // 
            // iconButton5
            // 
            this.iconButton5.BackColor = System.Drawing.Color.White;
            this.iconButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton5.IconChar = FontAwesome.Sharp.IconChar.Trash;
            this.iconButton5.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton5.IconSize = 26;
            this.iconButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton5.Location = new System.Drawing.Point(12, 594);
            this.iconButton5.Name = "iconButton5";
            this.iconButton5.Size = new System.Drawing.Size(176, 29);
            this.iconButton5.TabIndex = 257;
            this.iconButton5.Text = "Rohstoff löschen";
            this.iconButton5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton5.UseVisualStyleBackColor = false;
            this.iconButton5.Click += new System.EventHandler(this.iconButton5_Click);
            // 
            // btnrohadd
            // 
            this.btnrohadd.BackColor = System.Drawing.Color.White;
            this.btnrohadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrohadd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrohadd.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.btnrohadd.IconColor = System.Drawing.Color.Chocolate;
            this.btnrohadd.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnrohadd.IconSize = 26;
            this.btnrohadd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrohadd.Location = new System.Drawing.Point(12, 223);
            this.btnrohadd.Name = "btnrohadd";
            this.btnrohadd.Size = new System.Drawing.Size(248, 34);
            this.btnrohadd.TabIndex = 255;
            this.btnrohadd.Text = "Rohstoff hinzufügen";
            this.btnrohadd.UseVisualStyleBackColor = false;
            this.btnrohadd.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // iconButton3
            // 
            this.iconButton3.BackColor = System.Drawing.Color.White;
            this.iconButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton3.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.iconButton3.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton3.IconSize = 26;
            this.iconButton3.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.iconButton3.Location = new System.Drawing.Point(881, 263);
            this.iconButton3.Name = "iconButton3";
            this.iconButton3.Size = new System.Drawing.Size(107, 27);
            this.iconButton3.TabIndex = 254;
            this.iconButton3.Text = "Suchen";
            this.iconButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton3.UseVisualStyleBackColor = false;
            // 
            // iconButton2
            // 
            this.iconButton2.BackColor = System.Drawing.Color.White;
            this.iconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconButton2.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.IconSize = 26;
            this.iconButton2.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.iconButton2.Location = new System.Drawing.Point(12, 263);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Size = new System.Drawing.Size(88, 27);
            this.iconButton2.TabIndex = 253;
            this.iconButton2.Text = "Filter";
            this.iconButton2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton2.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(695, 264);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(180, 26);
            this.textBox1.TabIndex = 252;
            // 
            // Rohstoffe
            // 
            this.Rohstoffe.AllowUserToAddRows = false;
            this.Rohstoffe.AllowUserToDeleteRows = false;
            this.Rohstoffe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Rohstoffe.BackgroundColor = System.Drawing.Color.White;
            this.Rohstoffe.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.Rohstoffe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.NullValue = "--";
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Chocolate;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Rohstoffe.DefaultCellStyle = dataGridViewCellStyle5;
            this.Rohstoffe.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Rohstoffe.Location = new System.Drawing.Point(12, 296);
            this.Rohstoffe.Name = "Rohstoffe";
            this.Rohstoffe.ReadOnly = true;
            this.Rohstoffe.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Chocolate;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Rohstoffe.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.Rohstoffe.Size = new System.Drawing.Size(976, 292);
            this.Rohstoffe.TabIndex = 251;
            this.Rohstoffe.SelectionChanged += new System.EventHandler(this.Rohstoffe_SelectionChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Chocolate;
            this.label11.Location = new System.Drawing.Point(9, 121);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 18);
            this.label11.TabIndex = 268;
            this.label11.Text = "Bezeichnung";
            // 
            // txtbez
            // 
            this.txtbez.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbez.Location = new System.Drawing.Point(11, 142);
            this.txtbez.Name = "txtbez";
            this.txtbez.Size = new System.Drawing.Size(291, 26);
            this.txtbez.TabIndex = 267;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Chocolate;
            this.label17.Location = new System.Drawing.Point(5, 9);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(269, 40);
            this.label17.TabIndex = 259;
            this.label17.Text = "Rohstofftdaten";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Chocolate;
            this.label1.Location = new System.Drawing.Point(9, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 18);
            this.label1.TabIndex = 258;
            this.label1.Text = "Nr";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Chocolate;
            this.label8.Location = new System.Drawing.Point(158, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 18);
            this.label8.TabIndex = 266;
            this.label8.Text = "Preis";
            // 
            // txtmenge
            // 
            this.txtmenge.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmenge.Location = new System.Drawing.Point(11, 191);
            this.txtmenge.Name = "txtmenge";
            this.txtmenge.Size = new System.Drawing.Size(142, 26);
            this.txtmenge.TabIndex = 260;
            this.txtmenge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmenge_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Chocolate;
            this.label7.Location = new System.Drawing.Point(157, 171);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 18);
            this.label7.TabIndex = 265;
            this.label7.Text = "Einheit";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Chocolate;
            this.label6.Location = new System.Drawing.Point(8, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 18);
            this.label6.TabIndex = 264;
            this.label6.Text = "Menge";
            // 
            // txtpreis
            // 
            this.txtpreis.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpreis.Location = new System.Drawing.Point(160, 70);
            this.txtpreis.Name = "txtpreis";
            this.txtpreis.Size = new System.Drawing.Size(142, 26);
            this.txtpreis.TabIndex = 261;
            this.txtpreis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpreis_KeyPress);
            // 
            // txtnr
            // 
            this.txtnr.Enabled = false;
            this.txtnr.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnr.Location = new System.Drawing.Point(12, 70);
            this.txtnr.Name = "txtnr";
            this.txtnr.Size = new System.Drawing.Size(141, 26);
            this.txtnr.TabIndex = 262;
            this.txtnr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnr_KeyPress);
            // 
            // txteinheit
            // 
            this.txteinheit.BackColor = System.Drawing.Color.White;
            this.txteinheit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txteinheit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txteinheit.FormattingEnabled = true;
            this.txteinheit.Location = new System.Drawing.Point(161, 191);
            this.txteinheit.Name = "txteinheit";
            this.txteinheit.Size = new System.Drawing.Size(141, 26);
            this.txteinheit.TabIndex = 263;
            // 
            // checknr
            // 
            this.checknr.AutoSize = true;
            this.checknr.ForeColor = System.Drawing.Color.White;
            this.checknr.Location = new System.Drawing.Point(12, 102);
            this.checknr.Name = "checknr";
            this.checknr.Size = new System.Drawing.Size(150, 16);
            this.checknr.TabIndex = 270;
            this.checknr.Text = "Nummer selbst wählen";
            this.checknr.UseVisualStyleBackColor = true;
            this.checknr.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // iconButton6
            // 
            this.iconButton6.BackColor = System.Drawing.Color.White;
            this.iconButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton6.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.iconButton6.IconColor = System.Drawing.Color.DarkRed;
            this.iconButton6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton6.IconSize = 26;
            this.iconButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton6.Location = new System.Drawing.Point(266, 223);
            this.iconButton6.Name = "iconButton6";
            this.iconButton6.Size = new System.Drawing.Size(36, 34);
            this.iconButton6.TabIndex = 271;
            this.iconButton6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton6.UseVisualStyleBackColor = false;
            this.iconButton6.Click += new System.EventHandler(this.iconButton6_Click);
            // 
            // RohstoffSuchen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1000, 635);
            this.Controls.Add(this.iconButton6);
            this.Controls.Add(this.checknr);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtbez);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtmenge);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtpreis);
            this.Controls.Add(this.txtnr);
            this.Controls.Add(this.txteinheit);
            this.Controls.Add(this.iconButton5);
            this.Controls.Add(this.btnrohadd);
            this.Controls.Add(this.iconButton3);
            this.Controls.Add(this.iconButton2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Rohstoffe);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "RohstoffSuchen";
            this.Text = "RoshtoffSuchen";
            this.Load += new System.EventHandler(this.RohstoffSuchen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Rohstoffe)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private FontAwesome.Sharp.IconButton iconButton5;
        private FontAwesome.Sharp.IconButton btnrohadd;
        private FontAwesome.Sharp.IconButton iconButton3;
        private FontAwesome.Sharp.IconButton iconButton2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView Rohstoffe;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtbez;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtmenge;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtpreis;
        private System.Windows.Forms.TextBox txtnr;
        private System.Windows.Forms.ComboBox txteinheit;
        private System.Windows.Forms.CheckBox checknr;
        private FontAwesome.Sharp.IconButton iconButton6;
    }
}