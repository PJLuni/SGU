﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    public partial class ProdSchrittSuchen : Form
    {
        Helfer Manni = new Helfer();
        TabControl TC;
        private int SelProdNr;

        private bool prodposcolremoved = false;
        public ProdSchrittSuchen(TabControl TC, int SelProdNr = 0)
        {
            InitializeComponent();
            this.TC = TC;
            this.SelProdNr = SelProdNr;
        }

        private void ProdSchritt_Load(object sender, EventArgs e)
        {
            Mengeneinheit.LoadMengeneinheiten(rohstoffeinheit);
            Produkt.LoadProdukte(produktcombo);
            Produkt.LoadProdukte(produktcombodetails);
            Rohstoff.LoadRohstoffe(rohstoffcombo);

            txtschritt.Value = Manni.LetzteNummer("Produktionsschritt");
            if (SelProdNr != 0)
            {
                produktcombo.SelectedItem = SelProdNr;
            }
            
        }
        private void produktcombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                dgvlabel.Text = $"Bereits existierende Produktionsschritte für \n{Produkt.ProdBezForProdSchritt(Convert.ToInt32(produktcombo.Text))}";
            }
            catch (Exception){}
            
            Helfer.ClearDGV(prodschritte);
            ProdSchritt.SuchenDataGridFuellen(prodschritte, Convert.ToInt32(produktcombo.SelectedItem));
        }

        private void checkprodschritt_CheckedChanged(object sender, EventArgs e)
        {
            if(!prodschrittcombo.Enabled)
            {
                prodschrittcombo.Enabled = true;
            }
            else
            {
                prodschrittcombo.Enabled = false;
            }
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            if(iconButton1.Text == "Hinzufügen")
            {
                ProdSchritt.ProdSchrittNr = Convert.ToInt32(txtschritt.Value);
                ProdSchritt.ProdNr = Convert.ToInt32(produktcombo.SelectedItem);
                ProdSchritt.Bez = txtbez.Text;

                ProdSchritt.ErstelleProdSchritt();
                Helfer.ClearDGV(prodschritte);
                ProdSchritt.SuchenDataGridFuellen(prodschritte, Convert.ToInt32(produktcombo.SelectedItem));

                txtschritt.Value = Manni.LetzteNummer("Produktionsschritt");
            }
            else
            {
                ProdSchritt.ProdSchrittNr = Convert.ToInt32(txtschritt.Value);
                ProdSchritt.ProdNr = Convert.ToInt32(produktcombo.SelectedItem);
                ProdSchritt.Bez = txtbez.Text;

                ProdSchritt.BearbeiteProdSchritt();
                Helfer.ClearDGV(prodschritte);
                ProdSchritt.SuchenDataGridFuellen(prodschritte, Convert.ToInt32(produktcombo.SelectedItem));

                txtschritt.Value = Manni.LetzteNummer("Produktionsschritt");
            }
        }

        private void checknr_CheckedChanged(object sender, EventArgs e)
        {
            if (txtschritt.Enabled == true)
            {
                txtschritt.Enabled = true;
                txtschritt.Value = 0;
            }
            else
            {
                txtschritt.Enabled = false;
                txtschritt.Value = Manni.LetzteNummer("Produktionsschritt");
            }
        }
        private void produktcombodetails_SelectedIndexChanged(object sender, EventArgs e)
        {
            DetailsPanel1.Enabled = true;

            ProdSchritt.SuchenDataGridFuellen(prodschritte, Convert.ToInt32(produktcombodetails.SelectedItem));
            ProdSchritt.LoadProdSchritt(prodschrittcombo, Convert.ToInt32(produktcombodetails.SelectedItem));
        }

        private void prodschrittcombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            DetailsPanel2.Enabled = true;
            ProdSchritt.ProdPositionenDGVFuellen(prodschrittedetail, Convert.ToInt32(prodschrittcombo.SelectedItem));
            if (!prodposcolremoved)
            {
                prodschrittedetail.Columns.Remove("Nr");
                prodschrittedetail.Columns.Remove("Produktionsschritt");
                prodposcolremoved = true;
            }

            rohstoffcombo.SelectedItem = null;
            rohstoffmenge.Text = "";
            rohstoffeinheit.SelectedItem = null;

            prodschrittedetail.ClearSelection();
            iconButton2.Text = "Hinzufügen";
            rohstoffcombo.Enabled = true;
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            if(iconButton2.Text == "Hinzufügen")
            {
                ProdSchritt.ProdSchrittPosNr = Convert.ToInt32(prodschrittcombo.SelectedItem);
                ProdSchritt.RohstoffNr = Convert.ToInt32(rohstoffcombo.SelectedItem);
                ProdSchritt.Rohstoffmenge = Convert.ToInt32(rohstoffmenge.Text);
                ProdSchritt.MengeneinheitBez = rohstoffeinheit.SelectedItem.ToString();

                ProdSchritt.ErstelleProdSchrittDetails();
                ProdSchritt.ProdPositionenDGVFuellen(prodschrittedetail, Convert.ToInt32(prodschrittcombo.SelectedItem));
            }
            else
            {
                ProdSchritt.ProdSchrittNr = Convert.ToInt32(prodschrittcombo.SelectedItem);
                ProdSchritt.RohstoffNr = Convert.ToInt32(rohstoffcombo.SelectedItem);
                ProdSchritt.Rohstoffmenge = Convert.ToInt32(rohstoffmenge.Text);
                ProdSchritt.MengeneinheitBez = rohstoffeinheit.SelectedItem.ToString();

                int oldmengeneinheit = Convert.ToInt32(prodschrittedetail.SelectedRows[0].Cells[2].Value);
                int oldrohstoffmenge = Convert.ToInt32(prodschrittedetail.SelectedRows[0].Cells[1].Value);
                int oldrohstoffnr = Convert.ToInt32(prodschrittedetail.SelectedRows[0].Cells[0].Value);
                ProdSchritt.BearbeiteProdSchrittDetails(oldrohstoffnr, oldrohstoffmenge, oldmengeneinheit);
                ProdSchritt.ProdPositionenDGVFuellen(prodschrittedetail, Convert.ToInt32(prodschrittcombo.SelectedItem));
            }
            
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            TC.TabPages.Remove(TC.SelectedTab);
        }

        private void prodschrittedetail_SelectionChanged(object sender, EventArgs e)
        {
            if(prodschrittedetail.SelectedRows != null)
            {
                try
                {
                    rohstoffcombo.SelectedItem = prodschrittedetail.SelectedRows[0].Cells[0].Value;
                    rohstoffmenge.Text = prodschrittedetail.SelectedRows[0].Cells[1].Value.ToString();
                    rohstoffeinheit.SelectedItem = Mengeneinheit.GetMengenBez(Convert.ToInt32(prodschrittedetail.SelectedRows[0].Cells[2].Value));
                }
                catch (Exception){}

                iconButton2.Text = "Bearbeiten";
                rohstoffcombo.Enabled = false;
            }
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            rohstoffcombo.SelectedItem = null;
            rohstoffmenge.Text = "";
            rohstoffeinheit.SelectedItem = null;

            prodschrittedetail.ClearSelection();
            iconButton2.Text = "Hinzufügen";
            rohstoffcombo.Enabled = true;
        }

        private void prodschrittedetail_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            prodschrittedetail.Rows[e.RowIndex].Selected = true;
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            if (prodschrittedetail.SelectedRows != null)
            {
                ProdSchritt.ProdSchrittNr = Convert.ToInt32(prodschrittcombo.SelectedItem);
                ProdSchritt.RohstoffNr = Convert.ToInt32(prodschrittedetail.SelectedRows[0].Cells[0].Value);
                ProdSchritt.Rohstoffmenge = Convert.ToInt32(prodschrittedetail.SelectedRows[0].Cells[1].Value);
                ProdSchritt.Mengeneinheit = Convert.ToInt32(prodschrittedetail.SelectedRows[0].Cells[2].Value);

                ProdSchritt.LoescheProdSchrittPosition();
                ProdSchritt.ProdPositionenDGVFuellen(prodschrittedetail, Convert.ToInt32(prodschrittcombo.SelectedItem));
            }
            else
            {
                Info.Information("Bitte Position wählen!");
            }
        }

        private void prodschritte_SelectionChanged(object sender, EventArgs e)
        {
            if (prodschrittedetail.SelectedRows != null)
            {
                try
                {
                    txtschritt.Value = Convert.ToInt32(prodschritte.SelectedRows[0].Cells[0].Value);
                    produktcombo.SelectedItem = prodschritte.SelectedRows[0].Cells[1].Value.ToString();
                    txtbez.Text = prodschritte.SelectedRows[0].Cells[2].Value.ToString();
                }
                catch (Exception) { }

                iconButton1.Text = "Bearbeiten";
                produktcombo.Enabled = false;
            }
        }

        private void iconButton7_Click(object sender, EventArgs e)
        {
            txtschritt.Value = Manni.LetzteNummer("Produktionsschritt");
            txtbez.Text = "";

            prodschrittedetail.ClearSelection();
            iconButton1.Text = "Hinzufügen";
            produktcombo.Enabled = true;
        }

        private void prodschritte_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            prodschritte.Rows[e.RowIndex].Selected = true;
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            ProdSchritt.ProdSchrittNr = Convert.ToInt32(prodschritte.SelectedRows[0].Cells[0].Value);
            ProdSchritt.LoescheProdSchritt();
        }
    }
}
