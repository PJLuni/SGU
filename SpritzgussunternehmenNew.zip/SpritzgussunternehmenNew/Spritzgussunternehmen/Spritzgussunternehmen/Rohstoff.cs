﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Spritzgussunternehmen
{
    class Rohstoff
    {
        private static DataSet ds = new DataSet();
        public static void LoadRohstoffe(ComboBox comboBox)
        {
            DB.cmd = DB.createCmd("SELECT Nr FROM Rohstoff WHERE IsActive = true");
            DB.getCon().Open();
            DB.dr = DB.cmd.ExecuteReader();

            while (DB.dr.Read())
            {
                comboBox.Items.Add(DB.dr.GetInt32(0));
            }
            DB.getCon().Close();
        }

        public static void SuchenDataGridFuellen(DataGridView DataGrid)
        {
            DB.adap = new OleDbDataAdapter("SELECT * FROM Rohstoff WHERE IsActive = true", DB.getCon());

            ds.Clear();

            DB.adap.Fill(ds, "Rohstoffe");

            DataGrid.DataSource = ds;
            DataGrid.DataMember = "Rohstoffe";
        }

        public static void LoadEinheiten(ComboBox comboBox)
        {
            DB.cmd = new OleDbCommand("SELECT Bez FROM Mengeneinheit", DB.getCon());
            DB.getCon().Open();
            DB.dr = DB.cmd.ExecuteReader();

            while (DB.dr.Read())
            {
                comboBox.Items.Add(DB.dr.GetString(0));
            }
            DB.getCon().Close();
        }
        public static void ErstelleRohstoff(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Bez = Data[1];
                    int Menge = Int32.Parse(Data[2]);
                    string Preis = Data[4].Replace(",", ".");

                    DB.cmd = new OleDbCommand($"SELECT count(*) FROM Rohstoff WHERE Nr = {Nr}", DB.getCon());
                    DB.getCon().Open();
                    int rohexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (rohexist <= 0)
                    {
                        DB.cmd = new OleDbCommand($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{Data[3]}'", DB.getCon());
                        DB.getCon().Open();
                        int Einheit = Convert.ToInt32(DB.cmd.ExecuteScalar());
                        DB.getCon().Close();

                        DB.cmd = new OleDbCommand($"INSERT INTO Rohstoff (Nr, Bez, Lagerbestand, Mengeneinheit, Kosten, IsActive) " +
                                               $"VALUES ({Nr}, '{Bez}', {Menge}, {Einheit}, {Preis}, true)", DB.getCon());
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        Info.Success("Rohstoff wurde erfolgreich hinzugefügt!");
                    }
                    else
                    {
                        Info.Error("Rohstoff existiert bereits!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }

        public static void BearbeiteRohstoff(List<string> Data)
        {
            try
            {
                if (Helfer.TBFilled(Data))
                {
                    int Nr = Int32.Parse(Data[0]);
                    string Bez = Data[1];
                    int Menge = Int32.Parse(Data[2]);
                    string Preis = Data[4].Replace(",", ".");

                    DB.cmd = new OleDbCommand($"SELECT count(*) FROM Rohstoff WHERE Nr = {Nr}", DB.getCon());
                    DB.getCon().Open();
                    int rohexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (rohexist > 0)
                    {
                        DB.cmd = new OleDbCommand($"SELECT Nr FROM Mengeneinheit WHERE Bez = '{Data[3]}'", DB.getCon());
                        DB.getCon().Open();
                        int Einheit = Convert.ToInt32(DB.cmd.ExecuteScalar());
                        DB.getCon().Close();

                        DB.cmd = new OleDbCommand($"UPDATE Rohstoff SET Bez = '{Bez}', Lagerbestand = {Menge}, Mengeneinheit = {Einheit}, Kosten = {Preis}, IsActive = true WHERE Nr = {Nr}", DB.getCon());
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        Info.Success("Rohstoff wurde erfolgreich bearbeitet!");
                    }
                    else
                    {
                        Info.Error("Rohstoff existiert nicht!");
                    }
                }
                else
                {
                    Info.Information("Bitte füllen Sie alle Felder aus!");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show("Fehler \n\n" + Error);
            }
        }

        public static void LoescheRohstoff(DataGridView DataGrid)
        {
            DialogResult result = MessageBox.Show("Sind Sie sicher das Sie den ausgewählten Rohstoff löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                if (DataGrid.SelectedRows.Count != 0)
                {
                    DataGridViewRow row = DataGrid.SelectedRows[0];
                    string ZuLoeschen = row.Cells[0].Value.ToString();

                    DB.cmd = new OleDbCommand($"SELECT count(*) FROM Rohstoff WHERE Nr = {ZuLoeschen}", DB.getCon());
                    DB.getCon().Open();
                    int rohexist = Convert.ToInt32(DB.cmd.ExecuteScalar());
                    DB.getCon().Close();

                    if (rohexist > 0)
                    {
                        DB.cmd = new OleDbCommand($"UPDATE Rohstoff SET IsActive = false WHERE Nr = {ZuLoeschen}", DB.getCon());
                        DB.getCon().Open();
                        DB.cmd.ExecuteNonQuery();
                        DB.getCon().Close();

                        DataGrid.Rows.Remove(row);

                        Info.Success("Rohstoff wurde erfolgreich gelöscht!");
                    }
                    else
                    {
                        Info.Error("Rohstoff existiert nicht!");
                    }
                }
                else
                {
                    Info.Error("Bitte wählen Sie einen Rohstoff aus!");
                }
            }
        }
    }
}
