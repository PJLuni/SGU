﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    public partial class MwStSuchen : Form
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        TabControl TC;
        
        public MwStSuchen(TabControl TC)
        {
            this.TC = TC;
            InitializeComponent();
        }
        TabPage MwStHinzufuegen = new TabPage();
        private void iconButton6_Click(object sender, EventArgs e)
        {
            if (TC.TabPages.Contains(MwStHinzufuegen))
            {
                edit.pageswitch(MwStHinzufuegen, TC);
            }
            else
            {
                long MwStNr = 0;
                MwStHinzufuegen.Controls.Clear();
                MwStHinzufuegen.Text = "MwSt hinzufügen";
                TC.TabPages.Add(MwStHinzufuegen);
                LoadForm.OpenPanel(new MwStAdd(MwStNr, TC), MwStHinzufuegen);
                TC.SelectedTab = MwStHinzufuegen;
            }
        }
        TabPage MwStBearbeiten = new TabPage();
        private void iconButton3_Click(object sender, EventArgs e)
        {
            if (TC.TabPages.Contains(MwStBearbeiten))
            {
                edit.pageswitch(MwStBearbeiten, TC);
            }
            else
            {
                string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();

                cmd = new OleDbCommand("select * from MwSt where Nr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);


                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                long MwSt = dr.GetInt32(0);
                con.Close();


                MwStBearbeiten.Controls.Clear();
                MwStBearbeiten.Text = "MwSt bearbeiten";
                TC.TabPages.Add(MwStBearbeiten);
                LoadForm.OpenPanel(new MwStAdd(MwSt, TC), MwStBearbeiten);
                TC.SelectedTab = MwStBearbeiten;
            }
        }

        private void MwStSuchen_Load(object sender, EventArgs e)
        {
            adap = new OleDbDataAdapter("Select * from MwSt where not (MwSt.Nr=1)", con);
            edit.DataGridFuellen("Nr", adap, dataGridView1);
           checkBox1_CheckedChanged(sender, e);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                edit.IstAktiv(adap, dataGridView1, 2);
            }
            else
            {
                edit.DataGridFuellen("Nr", adap, dataGridView1);
            }
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();
            adap = new OleDbDataAdapter("SELECT DISTINCT Auftrag.MwSt FROM Auftrag, MwSt, Auftragsstatus WHERE MwSt.Nr = Auftrag.MwSt and Auftrag.MwSt = " + Ausgewähltezelle + "" +
                "and Auftrag.Status = Auftragsstatus.Nr and Auftrag.Status = 1 and MwSt.IsActive = true;", con);
            con.Open();
            DataTable dt = new DataTable();
            DataRow d = dt.NewRow();
            adap.Fill(dt);
            con.Close();

            if (dt.Rows.Count >= 1)
            {
                MessageBox.Show("Sie Können die MwSt nicht löschen, da sie in einem Auftrag vorkommt der noch in Bearbeitung ist.");
            }
            else
            {
                DialogResult result = MessageBox.Show("Sind Sie sicher das Sie die ausgewählte MwSt löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    con.Open();
                    cmd = new OleDbCommand("Update MwSt set IsActive = false where Nr = " + Ausgewähltezelle + "", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    con.Close();

                    MessageBox.Show("Gelöscht.");
                    MwStSuchen_Load(sender, e);
                }
            }
        }

        private void MwStSuchen_Enter(object sender, EventArgs e)
        {
            MwStSuchen_Load(sender, e);
            checkBox1.Checked = true;
        }
    }
}
