﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    public partial class AuftragAdd : Form
    {
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        Panel panel;
        String[] row;
        public AuftragAdd(String[] row,Panel panel)
        {
            this.row = row;
            this.panel = panel;
            InitializeComponent();
        }
        public void status()
        {
            con.Open();
            cmd = new OleDbCommand("SELECT Auftragsstatus.Bez From Auftragsstatus where Auftragsstatus.IsActive = true", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr.GetString(0));
            }
            con.Close();
            comboBox1.SelectedText = "In Bearbeitung";
        }
        public void mwSt()
        {
            if (checkBox7.Checked)
            {
                textBox2.Text = "";

                con.Open();
                cmd = new OleDbCommand("SELECT distinct MwSt.Prozentsatz from MwSt Where MwSt.Nr = 1 and MwSt.IsActive = true", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox2.Text = Convert.ToString(dr.GetInt32(0));

                con.Close();
            }
            else
            {
                checkBox7.Checked = false;
                textBox2.Text = "";

                con.Open();
                cmd = new OleDbCommand("Select MwSt.Prozentsatz from MwSt where IsActive = True and not (MwSt.Nr=1)", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox2.Text = Convert.ToString(dr.GetInt32(0)+" %");

                con.Close();

            }
        }
        private void AuftragAdd_Load(object sender, EventArgs e)
        {
            mwSt();
            status();
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            mwSt();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                LoadForm.OpenPanel(new AuftragLieferung(), loadPanel);
                checkBox2.Checked = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                LoadForm.OpenPanel(new AuftragPosition(), loadPanel);
                checkBox3.Checked = false;
            }
        }
        
        public static String[] rows= {};
        private void AuftragAdd_MouseClick(object sender, MouseEventArgs e)
        {
            if (AuftragPosition.auftragPosition == 1)
            {
                dataGridView1.Rows.Add(rows);
                panel1.Visible = true;
                AuftragPosition.auftragPosition = 0;
            }
            if (AuftragLieferung.auftragLieferung == 1)
            {
                datagridviewLieferung.Rows.Add(rows);
                panel2.Visible = true;
                AuftragLieferung.auftragLieferung = 0;
            }
        }
    }
}
