﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    public partial class AuftragPosition : Form
    {
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        public AuftragPosition()
        {
            InitializeComponent();
        }
        public static int auftragPosition = 0;
        public void auftragLieferung()
        {
            comboBox2.DataSource=AuftragAdd.lieferungNr;
        }
        public void mengeneinheit()
        {
            con.Open();
            cmd = new OleDbCommand("Select [Mengeneinheit].[Bez] from Produkt,Mengeneinheit where [Produkt].[Gewichtseinheit] = [Mengeneinheit].[Nr] and Produkt.Bez = '"+comboBox4.SelectedItem+"' and [Mengeneinheit].[IsActive] = True ", con);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox1.Items.Add(dr.GetString(0));
            }
            con.Close();
        }
        public void produkt()
        {
            comboBox4.Text = "";
            comboBox4.Items.Clear();
            con.Open();
            cmd = new OleDbCommand("SELECT Produkt.Bez from Produkt where Produkt.IsActive", con);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox4.Items.Add(dr.GetString(0));
            }
            con.Close();
        }
        public void verpackungseinheit()
        {
            comboBox3.Items.Clear();
            comboBox3.Text = "";
            con.Open();
            cmd = new OleDbCommand("Select Distinct Verpackungseinheit.Bez from Produkt,Verpackungseinheit,ProduktVerpackungseinheit " +
                "Where Verpackungseinheit.IsActive = true and ProduktVerpackungseinheit.Produkt = Produkt.Nr " +
                "and ProduktVerpackungseinheit.Verpackungseinheit = Verpackungseinheit.Nr and Produkt.Bez = '"+comboBox4.SelectedItem+"'", con);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox3.Items.Add(dr.GetString(0));
            }
            con.Close();
        }
        private void iconButton3_Click(object sender, EventArgs e)
        {
            int menge = Convert.ToInt32(textBox2.Text);
            double preis = Convert.ToDouble(textBox1.Text);
            double gesamtPreis= menge*preis;
            auftragPosition = 1;
            String[] row = { textBox18.Text, Convert.ToString(comboBox2.Text), Convert.ToString(comboBox4.Text), Convert.ToString(comboBox1.Text), Convert.ToString(comboBox3.Text), Convert.ToString(ProduktVerpackungseinheitNr) ,textBox2.Text,textBox1.Text,Convert.ToString(gesamtPreis) };
            AuftragAdd.rows = row;
            

            textBox18.Text = "";
            comboBox1.Items.Clear();
            comboBox1.Text = "";
            
            comboBox2.Text = "";
            comboBox3.Items.Clear();
            comboBox3.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            AuftragPosition_Load(sender, e);
        }

        private void AuftragPosition_Load(object sender, EventArgs e)
        {
            textBox18.Text = "";
            comboBox1.Items.Clear();
            comboBox1.Text = "";

            comboBox2.Text = "";
            comboBox3.Items.Clear();
            comboBox3.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            if (AuftragAdd.nummerPosition == 0)
            {
                edit.nrHochZaehlen("AuftragPosition", textBox18);
            }
            else
            {
                textBox18.Text = Convert.ToString(AuftragAdd.nummerPosition);
            }
            produkt();
            
            auftragLieferung();
        }

        private void AuftragPosition_MouseClick(object sender, MouseEventArgs e)
        {
            AuftragPosition_Load(sender,e); 
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            cmd = new OleDbCommand("SELECT Produkt.Preis from Produkt where Produkt.Bez = '" + comboBox4.SelectedItem + "'", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            textBox1.Text = Convert.ToString(dr.GetValue(0));
            con.Close();

            verpackungseinheit();
            mengeneinheit();
        }
        public static int ProduktVerpackungseinheitNr = 0;
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            cmd = new OleDbCommand("SELECT ProduktVerpackungseinheit.Nr from ProduktVerpackungseinheit,Produkt,Verpackungseinheit where ProduktVerpackungseinheit.Produkt = Produkt.Nr and ProduktVerpackungseinheit.Verpackungseinheit = Verpackungseinheit.Nr and Produkt.Bez = '" + comboBox4.SelectedItem + "' and Verpackungseinheit.Bez = '" + comboBox3.SelectedItem+ "'", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            ProduktVerpackungseinheitNr = dr.GetInt32(0);
            con.Close();
        }

        private void AuftragPosition_Enter(object sender, EventArgs e)
        {
            produkt();
            auftragLieferung();
        }
    }
}
