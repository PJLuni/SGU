﻿namespace Spritzgussunternehmen
{
    partial class SacharbeiterSuchen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblpassword = new System.Windows.Forms.Label();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.pw2label = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.txtpasswordaga = new System.Windows.Forms.TextBox();
            this.chBPwShow = new System.Windows.Forms.CheckBox();
            this.iconButton6 = new FontAwesome.Sharp.IconButton();
            this.btnehadd = new FontAwesome.Sharp.IconButton();
            this.label4 = new System.Windows.Forms.Label();
            this.txtbenutzername = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtvorname = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.iconButton7 = new FontAwesome.Sharp.IconButton();
            this.iconButton5 = new FontAwesome.Sharp.IconButton();
            this.iconButton3 = new FontAwesome.Sharp.IconButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.MitarbeiterList = new System.Windows.Forms.DataGridView();
            this.label17 = new System.Windows.Forms.Label();
            this.checknr = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtnr = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pw2label.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MitarbeiterList)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassword.ForeColor = System.Drawing.Color.Chocolate;
            this.lblpassword.Location = new System.Drawing.Point(2, 193);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(83, 18);
            this.lblpassword.TabIndex = 362;
            this.lblpassword.Text = "Passwort";
            // 
            // txtpassword
            // 
            this.txtpassword.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.Location = new System.Drawing.Point(5, 214);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.PasswordChar = '*';
            this.txtpassword.Size = new System.Drawing.Size(176, 26);
            this.txtpassword.TabIndex = 360;
            // 
            // pw2label
            // 
            this.pw2label.Controls.Add(this.label6);
            this.pw2label.Controls.Add(this.iconPictureBox1);
            this.pw2label.Controls.Add(this.txtpasswordaga);
            this.pw2label.Location = new System.Drawing.Point(187, 193);
            this.pw2label.Name = "pw2label";
            this.pw2label.Size = new System.Drawing.Size(176, 47);
            this.pw2label.TabIndex = 364;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Chocolate;
            this.label6.Location = new System.Drawing.Point(22, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 18);
            this.label6.TabIndex = 338;
            this.label6.Text = "Passwort";
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.iconPictureBox1.ForeColor = System.Drawing.Color.Chocolate;
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Redo;
            this.iconPictureBox1.IconColor = System.Drawing.Color.Chocolate;
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.IconSize = 21;
            this.iconPictureBox1.Location = new System.Drawing.Point(2, 0);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(21, 21);
            this.iconPictureBox1.TabIndex = 339;
            this.iconPictureBox1.TabStop = false;
            // 
            // txtpasswordaga
            // 
            this.txtpasswordaga.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpasswordaga.Location = new System.Drawing.Point(0, 21);
            this.txtpasswordaga.Name = "txtpasswordaga";
            this.txtpasswordaga.PasswordChar = '*';
            this.txtpasswordaga.Size = new System.Drawing.Size(176, 26);
            this.txtpasswordaga.TabIndex = 336;
            // 
            // chBPwShow
            // 
            this.chBPwShow.AutoSize = true;
            this.chBPwShow.ForeColor = System.Drawing.Color.White;
            this.chBPwShow.Location = new System.Drawing.Point(5, 246);
            this.chBPwShow.Name = "chBPwShow";
            this.chBPwShow.Size = new System.Drawing.Size(115, 17);
            this.chBPwShow.TabIndex = 363;
            this.chBPwShow.Text = "Passwort anzeigen";
            this.chBPwShow.UseVisualStyleBackColor = true;
            // 
            // iconButton6
            // 
            this.iconButton6.BackColor = System.Drawing.Color.White;
            this.iconButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton6.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.iconButton6.IconColor = System.Drawing.Color.DarkRed;
            this.iconButton6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton6.IconSize = 26;
            this.iconButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton6.Location = new System.Drawing.Point(339, 320);
            this.iconButton6.Name = "iconButton6";
            this.iconButton6.Size = new System.Drawing.Size(36, 34);
            this.iconButton6.TabIndex = 361;
            this.iconButton6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton6.UseVisualStyleBackColor = false;
            // 
            // btnehadd
            // 
            this.btnehadd.BackColor = System.Drawing.Color.White;
            this.btnehadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnehadd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnehadd.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.btnehadd.IconColor = System.Drawing.Color.Chocolate;
            this.btnehadd.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnehadd.IconSize = 26;
            this.btnehadd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnehadd.Location = new System.Drawing.Point(17, 320);
            this.btnehadd.Name = "btnehadd";
            this.btnehadd.Size = new System.Drawing.Size(223, 34);
            this.btnehadd.TabIndex = 359;
            this.btnehadd.Text = "Mitarbeiter hinzufügen";
            this.btnehadd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnehadd.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Chocolate;
            this.label4.Location = new System.Drawing.Point(2, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 18);
            this.label4.TabIndex = 358;
            this.label4.Text = "Benutzername";
            // 
            // txtbenutzername
            // 
            this.txtbenutzername.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbenutzername.Location = new System.Drawing.Point(5, 155);
            this.txtbenutzername.Name = "txtbenutzername";
            this.txtbenutzername.Size = new System.Drawing.Size(358, 26);
            this.txtbenutzername.TabIndex = 357;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Chocolate;
            this.label3.Location = new System.Drawing.Point(184, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 356;
            this.label3.Text = "Vorname";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Chocolate;
            this.label2.Location = new System.Drawing.Point(2, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 18);
            this.label2.TabIndex = 355;
            this.label2.Text = "Name";
            // 
            // txtvorname
            // 
            this.txtvorname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvorname.Location = new System.Drawing.Point(187, 96);
            this.txtvorname.Name = "txtvorname";
            this.txtvorname.Size = new System.Drawing.Size(176, 26);
            this.txtvorname.TabIndex = 354;
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(5, 96);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(176, 26);
            this.txtname.TabIndex = 353;
            // 
            // iconButton7
            // 
            this.iconButton7.BackColor = System.Drawing.Color.White;
            this.iconButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton7.IconChar = FontAwesome.Sharp.IconChar.RedoAlt;
            this.iconButton7.IconColor = System.Drawing.Color.DarkRed;
            this.iconButton7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton7.IconSize = 22;
            this.iconButton7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton7.Location = new System.Drawing.Point(703, 328);
            this.iconButton7.Name = "iconButton7";
            this.iconButton7.Size = new System.Drawing.Size(36, 26);
            this.iconButton7.TabIndex = 352;
            this.iconButton7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton7.UseVisualStyleBackColor = false;
            // 
            // iconButton5
            // 
            this.iconButton5.BackColor = System.Drawing.Color.White;
            this.iconButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton5.IconChar = FontAwesome.Sharp.IconChar.Trash;
            this.iconButton5.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton5.IconSize = 26;
            this.iconButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton5.Location = new System.Drawing.Point(17, 707);
            this.iconButton5.Name = "iconButton5";
            this.iconButton5.Size = new System.Drawing.Size(200, 29);
            this.iconButton5.TabIndex = 351;
            this.iconButton5.Text = "Mitarbeiter löschen";
            this.iconButton5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton5.UseVisualStyleBackColor = false;
            // 
            // iconButton3
            // 
            this.iconButton3.BackColor = System.Drawing.Color.White;
            this.iconButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton3.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.iconButton3.IconColor = System.Drawing.Color.Chocolate;
            this.iconButton3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton3.IconSize = 26;
            this.iconButton3.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.iconButton3.Location = new System.Drawing.Point(931, 327);
            this.iconButton3.Name = "iconButton3";
            this.iconButton3.Size = new System.Drawing.Size(107, 27);
            this.iconButton3.TabIndex = 350;
            this.iconButton3.Text = "Suchen";
            this.iconButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton3.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(745, 328);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(180, 26);
            this.textBox1.TabIndex = 349;
            // 
            // MitarbeiterList
            // 
            this.MitarbeiterList.AllowUserToAddRows = false;
            this.MitarbeiterList.AllowUserToDeleteRows = false;
            this.MitarbeiterList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.MitarbeiterList.BackgroundColor = System.Drawing.Color.White;
            this.MitarbeiterList.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.MitarbeiterList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.NullValue = "--";
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Chocolate;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.MitarbeiterList.DefaultCellStyle = dataGridViewCellStyle1;
            this.MitarbeiterList.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.MitarbeiterList.Location = new System.Drawing.Point(17, 360);
            this.MitarbeiterList.Name = "MitarbeiterList";
            this.MitarbeiterList.ReadOnly = true;
            this.MitarbeiterList.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Chocolate;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MitarbeiterList.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.MitarbeiterList.Size = new System.Drawing.Size(1021, 341);
            this.MitarbeiterList.TabIndex = 348;
            this.MitarbeiterList.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MitarbeiterList_RowHeaderMouseDoubleClick);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Chocolate;
            this.label17.Location = new System.Drawing.Point(12, 2);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(282, 40);
            this.label17.TabIndex = 347;
            this.label17.Text = "Sachbearbeiter";
            // 
            // checknr
            // 
            this.checknr.AutoSize = true;
            this.checknr.ForeColor = System.Drawing.Color.White;
            this.checknr.Location = new System.Drawing.Point(5, 55);
            this.checknr.Name = "checknr";
            this.checknr.Size = new System.Drawing.Size(132, 17);
            this.checknr.TabIndex = 346;
            this.checknr.Text = "Nummer selbst wählen";
            this.checknr.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Chocolate;
            this.label1.Location = new System.Drawing.Point(2, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 18);
            this.label1.TabIndex = 344;
            this.label1.Text = "Nr";
            // 
            // txtnr
            // 
            this.txtnr.Enabled = false;
            this.txtnr.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnr.Location = new System.Drawing.Point(5, 23);
            this.txtnr.Name = "txtnr";
            this.txtnr.Size = new System.Drawing.Size(141, 26);
            this.txtnr.TabIndex = 345;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtvorname);
            this.panel1.Controls.Add(this.lblpassword);
            this.panel1.Controls.Add(this.txtnr);
            this.panel1.Controls.Add(this.txtpassword);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pw2label);
            this.panel1.Controls.Add(this.checknr);
            this.panel1.Controls.Add(this.chBPwShow);
            this.panel1.Controls.Add(this.txtname);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtbenutzername);
            this.panel1.Location = new System.Drawing.Point(12, 45);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(392, 269);
            this.panel1.TabIndex = 365;
            // 
            // SacharbeiterSuchen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1048, 746);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.iconButton6);
            this.Controls.Add(this.btnehadd);
            this.Controls.Add(this.iconButton7);
            this.Controls.Add(this.iconButton5);
            this.Controls.Add(this.iconButton3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.MitarbeiterList);
            this.Controls.Add(this.label17);
            this.Name = "SacharbeiterSuchen";
            this.Text = "Mitarbeiter";
            this.Load += new System.EventHandler(Mitarbeiter_Load);
            this.pw2label.ResumeLayout(false);
            this.pw2label.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MitarbeiterList)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.Panel pw2label;
        private System.Windows.Forms.Label label6;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private System.Windows.Forms.TextBox txtpasswordaga;
        private System.Windows.Forms.CheckBox chBPwShow;
        private FontAwesome.Sharp.IconButton iconButton6;
        private FontAwesome.Sharp.IconButton btnehadd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtbenutzername;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtvorname;
        private System.Windows.Forms.TextBox txtname;
        private FontAwesome.Sharp.IconButton iconButton7;
        private FontAwesome.Sharp.IconButton iconButton5;
        private FontAwesome.Sharp.IconButton iconButton3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView MitarbeiterList;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox checknr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtnr;
        private System.Windows.Forms.Panel panel1;
    }
}