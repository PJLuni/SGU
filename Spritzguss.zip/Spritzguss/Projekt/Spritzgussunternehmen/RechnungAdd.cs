﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    public partial class RechnungAdd : Form
    {
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        DataGridViewTextBoxColumn textBox = new DataGridViewTextBoxColumn();
        
        long rechNr;
        Panel panel;
        public RechnungAdd(long rechNr,Panel panel)
        {
            this.panel = panel;
            this.rechNr = rechNr;
            InitializeComponent();
        }
        //public void produkt()
        //{
        //        if (comboBox3.SelectedIndex >= 0)
        //        {
        //            comboBox4.Items.Clear();

        //            con.Open();
        //            cmd = new OleDbCommand("SELECT Produkt.Nr from Produkt where Produkt.Bez  = '" + comboBox3.SelectedItem + "'", con);
        //            dr = cmd.ExecuteReader();
        //            dr.Read();
        //            int produktNummer = dr.GetInt32(0);
        //            con.Close();

        //            con.Open();
        //            cmd = new OleDbCommand("SELECT Produkt.Art from Produkt where Produkt.Nr  = " + produktNummer + "", con);
        //            dr = cmd.ExecuteReader();
        //            dr.Read();
        //            int produktArtNummer = dr.GetInt32(0);
        //            con.Close();


        //            cmd = new OleDbCommand("Select Distinct Mengeneinheit.Bez from Mengeneinheit,Produkt,Produktart where  Produkt.Gewichtseinheit = Mengeneinheit.Nr and Produkt.Art = Produktart.Nr and Produkt.Art = " + produktArtNummer + " and Produkt.IsActive=true", con);
        //            con.Open();
        //            dr = cmd.ExecuteReader();
        //            while (dr.Read())
        //            {
        //                comboBox4.Items.Add(dr.GetString(0));
        //            }
        //            con.Close();

        //            con.Open();
        //            cmd = new OleDbCommand("SELECT Produkt.Preis from Produkt where Produkt.Nr  = " + produktNummer + "", con);
        //            dr = cmd.ExecuteReader();
        //            dr.Read();
        //            textBox13.Text = Convert.ToString(dr.GetValue(0)) + " €";
        //            con.Close();
        //        }
            
        //}
        public void produktPositionLoad()
        {
            panel2.Visible = true;
                adap = new OleDbDataAdapter("SELECT [Produkt].[Bez], [Mengeneinheit].[Bez], [AuftragPosition].[Menge], [AuftragPosition].[Preis], [AuftragPosition].[Menge] * [AuftragPosition].[Preis] AS Gesamtpreis FROM Produktart, Mengeneinheit, Produkt, ProduktVerpackungseinheit, Kunde, Auftrag, AuftragPosition,AuftragLieferung WHERE[ProduktVerpackungseinheit].[Produkt] = [Produkt.Nr] and[Produkt.IsActive] = True and[AuftragPosition].[Auftrag] = [Auftrag].[Nr] and[AuftragPosition].[ProduktVerpackungseinheit] = [ProduktVerpackungseinheit].[Nr] and[Auftrag].[Kunde] =[Kunde].[Nr] and[Produkt].[Gewichtseinheit] = [Mengeneinheit].[Nr] and[Produkt].[Art] = [Produktart].[Nr] and [Auftrag].[Nr] = "+comboBox2.SelectedItem+" and [AuftragLieferung].[Auftrag]=[Auftrag].[Nr] and [AuftragLieferung].[Nr] = "+comboBox1.SelectedItem+" and [AuftragPosition].[AuftragLieferung] = [AuftragLieferung].[Nr] GROUP BY[Produkt].[Bez], [Mengeneinheit].[Bez], [AuftragPosition].[Menge], [AuftragPosition].[Preis]", con);

                ds.Clear();

                adap.Fill(ds, "filter");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "filter";
        }
        public void lieferscheinPalettenMengeLoad()
        {
            con.Open();
            cmd = new OleDbCommand("SELECT Palette.Nr from Palette where Palette.Bez  = '" + comboBox6.SelectedItem + "'", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            int paletteNummer = dr.GetInt32(0);
            con.Close();


            con.Open();
            cmd = new OleDbCommand("SELECT LieferscheinPalette.Menge FROM LieferscheinPalette, Lieferschein, Auftrag, AuftragLieferung,Palette where LieferscheinPalette.Lieferschein = Lieferschein.Nr and Lieferschein.AuftragLieferung = AuftragLieferung.Nr and LieferscheinPalette.Palette = Palette.Nr and AuftragLieferung.Auftrag = Auftrag.Nr and Lieferschein.Nr = "+comboBox3.SelectedItem+" and LieferscheinPalette.Palette = "+paletteNummer+"",con);
            dr = cmd.ExecuteReader();
            dr.Read();
            textBox13.Text = Convert.ToString(dr.GetInt32(0));
            con.Close();
        }
        //public void produktDatenLoad()
        //{
        //    //comboBox3.Items.Clear();

        //    con.Open();
        //    cmd = new OleDbCommand("SELECT Kunde.Nr from Kunde where Kunde.Bez  = '" + textBox3.Text + "'", con);
        //    dr = cmd.ExecuteReader();
        //    dr.Read();
        //    int KundeNummer = dr.GetInt32(0);
        //    con.Close();

        //    con.Open();
        //    cmd = new OleDbCommand("SELECT Produkt.Bez from Produkt,ProduktKundeArtNummer,Kunde where ProduktKundeArtNummer.Kunde = Kunde.Nr and ProduktKundeArtNummer.Produkt = Produkt.Nr" +
        //        " and ProduktKundeArtNummer.Kunde = " + KundeNummer + " and Produkt.IsActive = True", con);
        //    dr = cmd.ExecuteReader();

        //    while (dr.Read())
        //    {
        //        comboBox3.Items.Add(dr.GetString(0));
        //    }
        //    con.Close();
        //}
        public void auftragLieferung()
        {
           
            comboBox1.Items.Clear();
            comboBox1.Text = "";
           
            con.Open();
            cmd = new OleDbCommand("SELECT AuftragLieferung.Nr from AuftragLieferung,Auftrag where AuftragLieferung.Auftrag = Auftrag.Nr and Auftrag.Nr = "+comboBox2.SelectedItem+"", con);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                comboBox1.Items.Add(dr.GetInt32(0));
            }
            con.Close();

            

        }
        public void mwSt()
        {
            if (checkBox4.Checked)
            {
                textBox2.Text = "";
               
                con.Open();
                cmd = new OleDbCommand("SELECT distinct MwSt.Prozentsatz from MwSt Where MwSt.Nr = 1 and MwSt.IsActive = true", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox2.Text = Convert.ToString(dr.GetInt32(0));
               
                con.Close();
            }
            else
            {
                checkBox4.Checked = false;
                textBox2.Text = "";
                
                con.Open();
                cmd = new OleDbCommand("SELECT distinct MwSt.Prozentsatz from MwSt,Auftrag Where Auftrag.MwSt=MwSt.Nr and Auftrag.Nr = " + comboBox2.SelectedItem + " and MwSt.IsActive = true", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                textBox2.Text = Convert.ToString(dr.GetInt32(0));
               
                con.Close();

            }
        }
        public void auftrag()
        {
            con.Open();
            cmd = new OleDbCommand("SELECT distinct Auftrag.Nr from Auftrag,Auftragsstatus Where Auftrag.Status=Auftragsstatus.Nr and Auftrag.Status=1 ", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox2.Items.Add(dr.GetInt32(0));
            }
            con.Close();
        }
        //public void lagerBestand()
        //{
        //    con.Open();
        //    cmd = new OleDbCommand("SELECT Produkt.Nr from Produkt where Produkt.Bez  = '" + comboBox3.SelectedItem + "'", con);
        //    dr = cmd.ExecuteReader();
        //    dr.Read();
        //    int produktNummer = dr.GetInt32(0);
        //    con.Close();

        //    con.Open();
        //    cmd = new OleDbCommand("SELECT Produkt.Lagerbestand from Produkt where Produkt.Nr  = " + produktNummer + "", con);
        //    dr = cmd.ExecuteReader();
        //    dr.Read();

        //}
        public void auftragProdukt()
        {

        }
        //private void textBox14_TextChanged(object sender, EventArgs e)
        //{
        //    if (comboBox3.SelectedIndex >= 0)
        //    {
        //        if (textBox14.TextLength > 0)
        //        {
        //            lagerBestand();
        //            int getlagermenge = dr.GetInt32(0);
        //            con.Close();
        //            long i;

        //            i = long.Parse(textBox14.Text);

        //            if (i > getlagermenge)
        //            {

        //                MessageBox.Show("Die gewünchte Menge ist für dieses Produkt im Lager nicht vorhanden nicht vorhanden!");

        //                textBox14.Text = "";

        //                textBox14.Focus();

        //            }
        //        }
        //        else
        //        {
        //            con.Open();
        //            cmd = new OleDbCommand("SELECT Produkt.Nr from Produkt where Produkt.Bez  = '" + comboBox3.SelectedItem + "'", con);
        //            dr = cmd.ExecuteReader();
        //            dr.Read();
        //            int produktNummer = dr.GetInt32(0);
        //            con.Close();

        //            con.Open();
        //            cmd = new OleDbCommand("SELECT Produkt.Preis from Produkt where Produkt.Nr  = " + produktNummer + "", con);
        //            dr = cmd.ExecuteReader();
        //            dr.Read();
        //            double produktPreis = Convert.ToDouble(dr.GetValue(0));
        //            con.Close();
        //            double menge = Convert.ToDouble(textBox14.Text);
        //            double preis = produktPreis * menge;
        //            textBox13.Text = Convert.ToString(preis) + " €";
        //            Preis();
        //        }
        //    }
        // }

        private void RechnungAdd_Load(object sender, EventArgs e)
        {
            if (rechNr == 0)
            {
                edit.nrHochZaehlen("Rechnung", textBox17);
                auftrag();
                if (comboBox2.SelectedIndex >= 0)
                {
                    mwSt();
                    checkBox4_CheckedChanged(sender, e);

                    //if (panel1.Visible == true)
                    //{
                    //    produkt();
                    //}

                }
                
            }

           
        
       

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            mwSt();
        }
        //private void button7_Click(object sender, EventArgs e)
        //{
        //    panel1.Visible = true;
        //}
        public void paletteDatenLoad()
        {
            comboBox3.Items.Clear();
            comboBox3.Text = "";
            comboBox6.Items.Clear();
            comboBox6.Text = "";
            textBox13.Text = "";
            textBox12.Text = "€";
            edit.nrHochZaehlen("RechnungPositionPalette", textBox11);

            comboBox6.Items.Clear();

            con.Open();
            cmd = new OleDbCommand("SELECT Palette.Bez from Palette,AuftragLieferungPalette,AuftragLieferung " +
                "where Palette.IsActive = true and AuftragLieferungPalette.Palette = Palette.Nr and AuftragLieferungPalette.AuftragLieferung= AuftragLieferung.Nr and AuftragLieferung.Nr = "+comboBox1.SelectedItem+"", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox6.Items.Add(dr.GetString(0));
            }
            con.Close();
            
        }
        public void lieferscheinDatenLoad()
        {
            con.Open();
            cmd = new OleDbCommand("SELECT Lieferschein.Nr FROM Lieferschein, AuftragLieferung " +
                "where Lieferschein.AuftragLieferung = AuftragLieferung.Nr and AuftragLieferung.Nr = "+comboBox1.SelectedItem+"", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox3.Items.Add(dr.GetInt32(0));
            } 
            con.Close();
        }
        public void palette()
        {
            
        }
        public void rechnungSpeichern()
        {
            if (rechNr == 0)
            {
                if (sichbar == 0)
                {

                    adap = new OleDbDataAdapter("SELECT Rechnung.Auftrag from Rechnung,Auftrag Where Rechnung.Auftrag = Auftrag.Nr and Rechnung.Auftrag = " + comboBox2.SelectedItem+"", con);
                    con.Open();
                    DataTable dt = new DataTable();
                    DataRow d = dt.NewRow();
                    adap.Fill(dt);
                    con.Close();

                    if (dt.Rows.Count >= 1)
                    {

                    }
                    else
                    {

                        con.Open();
                        cmd = new OleDbCommand("SELECT MwSt.Nr from MwSt where MwSt.Prozentsatz  = " + textBox2.Text + "", con);
                        dr = cmd.ExecuteReader();
                        dr.Read();
                        int mwStNummer = dr.GetInt32(0);
                        con.Close();

                        con.Open();
                        cmd = new OleDbCommand("SELECT Kunde.Nr from Kunde where Kunde.Bez  = '" + textBox3.Text + "'", con);
                        dr = cmd.ExecuteReader();
                        dr.Read();
                        int KundeNummer = dr.GetInt32(0);
                        con.Close();

                        con.Open();
                        cmd = new OleDbCommand("Insert into Rechnung (Nr, MwSt, Auftrag, Kunde, IstSteuerfrei, Datum, Zahlungsbedingungen) values ('" + textBox17.Text + "', " + mwStNummer + ", " + comboBox2.SelectedItem + "," + KundeNummer + "," + checkBox4.Checked + ", '" + dateTimePicker1.Value + "', '" + textBox1.Text + "')", con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }
        }
        public static int sichbar = 0;
        public static int speichern = 0;
        private void button4_Click(object sender, EventArgs e)
        {
            int produktNummerPrüfen = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                con.Open();
                cmd = new OleDbCommand("SELECT Produkt.Nr from Produkt where Produkt.Bez  = '" + dataGridView1.Rows[i].Cells[1].Value.ToString() + "'", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                     produktNummerPrüfen = dr.GetInt32(0);
                }
                con.Close();

                adap = new OleDbDataAdapter("Select count(RechnungPosition.Produkt) from RechnungPosition,Rechnung,Auftrag " +
                "Where RechnungPosition.Rechnung = Rechnung.Nr and Rechnung.Auftrag = Auftrag.Nr " +
                "and Auftrag.Nr = "+comboBox2.SelectedItem+" and RechnungPosition.Produkt="+ produktNummerPrüfen + "", con);
                con.Open();
                DataTable dt = new DataTable();
                DataRow d = dt.NewRow();
                adap.Fill(dt);
                con.Close();

                if ((int)dt.Rows[0][0] > 0)
                {
                    MessageBox.Show("Sie können keine Rechnung Hinzufügen, da für diese AuftragLieferung schon eine Vorhanden ist,");
                }
                else
                {

                    DialogResult result = MessageBox.Show("Möchten sie diese Rechnung erstellen?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        rechnungSpeichern();

                        for (int x = 0; x < dataGridView1.Rows.Count; x++)
                        {
                            int produktNummer = 0;
                            int mengenEinheit = 0;
                            con.Open();
                            cmd = new OleDbCommand("SELECT Produkt.Nr from Produkt where Produkt.Bez  = '" + dataGridView1.Rows[x].Cells[1].Value.ToString() + "'", con);
                            dr = cmd.ExecuteReader();

                            while (dr.Read())
                            {
                               produktNummer = dr.GetInt32(0);
                            }

                            con.Close();

                            con.Open();
                            cmd = new OleDbCommand("SELECT Mengeneinheit.Nr from Mengeneinheit where Mengeneinheit.Bez  = '" + dataGridView1.Rows[x].Cells[2].Value.ToString() + "'", con);
                            dr = cmd.ExecuteReader();

                            while (dr.Read())
                            {
                                mengenEinheit = dr.GetInt32(0);
                            }
                            con.Close();

                            con.Open();
                            cmd = new OleDbCommand("Insert into RechnungPosition (Nr, Produkt, Rechnung, Mengeneinheit, Menge, Preis) values (" + Convert.ToInt32(dataGridView1.Rows[x].Cells[0].Value.ToString()) + " , " + produktNummer + "," + textBox17.Text + " ," + mengenEinheit + "," + Convert.ToInt32(dataGridView1.Rows[x].Cells[3].Value.ToString()) + ", " + dataGridView1.Rows[x].Cells[4].Value.ToString().Replace(",",".") + ")", con);
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                        if (checkBox3.Checked)
                        {
                            rechnungPositionPaletteSpeichern();
                        }
                        MessageBox.Show("Rechnung wurde erfolgreich gespeichert");
                        Close();
                        LoadForm.OpenPanel(new Rechnung(panel), panel);
                    }
                }

            }
        }
        public void paletteSpeichern()
        {
            con.Open();
            cmd = new OleDbCommand("SELECT Palette.Nr from Palette where Palette.Bez  = '" + comboBox6.SelectedItem + "'", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            int paletteNummer = dr.GetInt32(0);
            con.Close();

           
                String[] row = { textBox11.Text, (string)comboBox6.SelectedItem, textBox13.Text, textBox12.Text };
                dataGridView2.Rows.Add(row);

        }
        public void rechnungPositionPaletteSpeichern()
        {
            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                int paletteNummer = 0;
                
                con.Open();
                cmd = new OleDbCommand("SELECT Palette.Nr from Palette where Palette.Bez  = '" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "'", con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    paletteNummer = dr.GetInt32(0);
                }
                con.Close();

                con.Open();
                cmd = new OleDbCommand("Insert into RechnungPositionPalette (Nr, Rechnung, Palette, Menge, Preis) values (" + Convert.ToInt32(dataGridView2.Rows[i].Cells[0].Value.ToString()) + "," + textBox17.Text + "," + paletteNummer + "," + Convert.ToInt32(dataGridView2.Rows[i].Cells[2].Value.ToString()) + ", " + dataGridView2.Rows[i].Cells[3].Value.ToString().Replace(",",".") + ")", con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        public void kunde()
        {
            textBox3.Text = "";
            con.Open();
            cmd = new OleDbCommand("SELECT distinct Kunde.Bez from Kunde,Auftrag Where Auftrag.Kunde = Kunde.Nr and Auftrag.Nr = " + comboBox2.SelectedItem + " and Kunde.IsActive = true", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            textBox3.Text = dr.GetString(0);
            con.Close();
        }
        public static int isda = 0;
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex >= 0)
            {
                edit.nrHochZaehlen("Rechnung", textBox17);
                kunde();
                mwSt();
                con.Open();
                cmd = new OleDbCommand("SELECT distinct MwSt.Nr from MwSt,Auftrag Where Auftrag.MwSt=MwSt.Nr and Auftrag.Nr = " + comboBox2.SelectedItem + " and MwSt.IsActive = true", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                int mwStNr = dr.GetInt32(0);
                con.Close();
                if (mwStNr == 1)
                {
                    checkBox4.Checked = true;
                }
                else
                {
                    checkBox4.Checked = false;
                }
                //if (panel1.Visible == true)
                //{
                //    produktDatenLoad();
                //    comboBox3.Text = "";
                //    produkt();
                //}
                auftragLieferung();
                if (comboBox2.SelectedText=="")
                {
                    panel2.Visible = false;
                }
                else
                {
                    panel2.Visible = true;
                }
                checkBox3.Checked = false;
                adap = new OleDbDataAdapter("SELECT Rechnung.Nr From Rechnung,Auftrag where Rechnung.Auftrag = Auftrag.Nr and Auftrag= " + comboBox2.SelectedItem + "", con);
                DataTable dt = new DataTable();
                DataRow d = dt.NewRow();
                adap.Fill(dt);
                con.Close();

                if (dt.Rows.Count > 0)
                {
                    con.Open();
                    cmd = new OleDbCommand("SELECT Rechnung.Nr From Rechnung,Auftrag where Rechnung.Auftrag = Auftrag.Nr and Auftrag= " + comboBox2.SelectedItem + "", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    textBox17.Text = Convert.ToString(dr.GetInt32(0));
                    con.Close();
                }
                
            }
        }   

        //private void comboBox3_SelectedIndexChanged_1(object sender, EventArgs e)
        //{
        //    produkt();
        //}

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        //public void Preis()
        //{

        //    con.Open();
        //    cmd = new OleDbCommand("SELECT Produkt.Nr from Produkt where Produkt.Bez  = '" + comboBox3.SelectedItem + "'", con);
        //    dr = cmd.ExecuteReader();
        //    dr.Read();
        //    int produktNummer = dr.GetInt32(0);
        //    con.Close();

        //    con.Open();
        //    cmd = new OleDbCommand("SELECT Produkt.Preis from Produkt where Produkt.Nr  = " + produktNummer + "", con);
        //    dr = cmd.ExecuteReader();
        //    dr.Read();
        //    textBox13.Text = Convert.ToString(dr.GetValue(0)) + " €";
        //    con.Close();
        //}
        //private void textBox14_Leave(object sender, EventArgs e)
        //{
        //    if (textBox14.TextLength > 0)
        //    {
        //        con.Open();
        //        cmd = new OleDbCommand("SELECT Produkt.Nr from Produkt where Produkt.Bez  = '" + comboBox3.SelectedItem + "'", con);
        //        dr = cmd.ExecuteReader();
        //        dr.Read();
        //        int produktNummer = dr.GetInt32(0);
        //        con.Close();

        //        con.Open();
        //        cmd = new OleDbCommand("SELECT Produkt.Preis from Produkt where Produkt.Nr  = " + produktNummer + "", con);
        //        dr = cmd.ExecuteReader();
        //        dr.Read();
        //        double produktPreis = Convert.ToDouble(dr.GetValue(0));
        //        con.Close();
        //        double menge = Convert.ToDouble(textBox14.Text);
        //        double preis = produktPreis * menge;
        //        textBox13.Text = Convert.ToString(preis) + " €";
        //    }
        //}

        private void textBox2_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            edit.colorChange(textBox2);
        }

        private void textBox3_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            edit.colorChange(textBox3);
        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new OleDbCommand("SELECT Palette.Nr from Palette where Palette.Bez  = '" + comboBox6.SelectedItem + "'", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            int paletteNummer = dr.GetInt32(0);
            con.Close();
            paletteSpeichern();
            panel3.Visible = true;

            int hochZaehlen = Convert.ToInt32(textBox11.Text);
            string neuTextBox11= Convert.ToString(hochZaehlen+1);
            textBox11.Text = neuTextBox11;
            comboBox6.Text = "";
            textBox13.Text = "";
            textBox12.Text = "";

        }

        //private void button6_Click(object sender, EventArgs e)
        //{
        //    panel1.Visible = true;

        //    produktDatenLoad();

        //    speichern = 1;
        //}

        private void button7_Click_1(object sender, EventArgs e)
        {
            //paletteDaten.Visible = true;
        }

        private void RechnungAdd_Leave(object sender, EventArgs e)
        {
            isda = 0;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox6.Text = textBox2.Text;
        }
        
        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                panel1.Visible = true;
                palette();
                paletteDatenLoad();
                lieferscheinDatenLoad();
            }
            else
            {
                panel3.Visible = false;
                panel1.Visible = false;
            }
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
            produktPositionLoad();
            if (dataGridView1.Columns.Contains(textBox))
            {
                dataGridView1.Columns.Remove(textBox);
            }
            isda = 0;
            if (checkBox3.Checked)
            {
                palette();
                paletteDatenLoad();
            }
            comboBox1_Validated(sender, e);
            checkBox3.Checked = false;
        }

        private void comboBox1_Validated(object sender, EventArgs e)
        {
            cmd = new OleDbCommand("SELECT count(Nr) FROM RechnungPosition", con);

            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();

            int Anzahl = dr.GetInt32(0);
            con.Close();
            int RechnungPositionNr;
            if (Anzahl > 0)
            {
                cmd = new OleDbCommand("SELECT Max(Nr) FROM RechnungPosition ", con);

                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();

                RechnungPositionNr = dr.GetInt32(0) + 1;

                con.Close();
            }
            else
            {
                RechnungPositionNr = 1;
            }
            if (isda == 1)
            {

            }
            else
            {
                textBox.HeaderText = "Nr";

                textBox.Name = "R_Nr";

                dataGridView1.Columns.Insert(0, textBox);
            }
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                dataGridView1.Rows[i].Cells["R_Nr"].Value = RechnungPositionNr++;
            }

            textBox5.Text = (from DataGridViewRow row in dataGridView1.Rows
                             where row.Cells[5].FormattedValue.ToString() != string.Empty
                             select Convert.ToDouble(row.Cells[5].FormattedValue)).Sum().ToString();
            double prozent = Convert.ToDouble(textBox6.Text) / 100;
            double zwischenmul = Convert.ToDouble(textBox5.Text) * prozent;
            double gesamt = Convert.ToDouble(textBox5.Text) + zwischenmul;
            textBox8.Text = Convert.ToString(gesamt);
            isda = 1;
        }

       
        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            cmd = new OleDbCommand("SELECT Palette.Nr from Palette where Palette.Bez  = '" + comboBox6.SelectedItem + "'", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            int paletteNummer = dr.GetInt32(0);
            con.Close();

            con.Open();
            cmd = new OleDbCommand("SELECT Palette.Kosten from Palette where Palette.Nr  = " + paletteNummer + "", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            textBox12.Text = Convert.ToString(dr.GetValue(0)) + " €";
            con.Close();
            lieferscheinPalettenMengeLoad();
        }

        
    }
}
    

