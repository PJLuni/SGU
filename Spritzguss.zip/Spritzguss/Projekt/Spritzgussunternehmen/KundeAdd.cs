﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class KundeAdd : Form
    {
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        long Kunde;
        TabControl TC;
        TabPage KP;
        public static int hinzuOderBearbeiten = 0;
        public static int ansprechpartnerrr = 0;
        public KundeAdd(long Kunde, TabControl TC, TabPage KP)
        {
            this.KP = KP;
            this.TC = TC;
            this.Kunde = Kunde;
            InitializeComponent();
        }
        public void kundehinzufuegen_load(long Kunde)
        {
            label17.Text = "Kunde-Hinzufügen";
            position();
            edit.nrHochZaehlen("Kunde", textBox17);
        }
        public void position()
        {
            if (panel1.Visible == false)
            {
                TC.Height = 647;
                button1.Location = new Point(777, 564);
            }
            if (panel2.Visible == false)
            {
                // panel1.Location = new Point(21, 374);
                TC.Height = 647;
                button1.Location = new Point(777, 564);
            }

            if (panel1.Visible == true && panel2.Visible == true)
            {
                panel2.Location = new Point(21, 374);
                panel1.Location = new Point(21, 548);
                TC.Height = 808;
                button1.Location = new Point(777, 727);
            }
            if (panel1.Visible == true && panel2.Visible == false)
            {
                panel1.Location = new Point(21, 374);
            }
        }
        public void kundebearbeiten_load(long Kunde)
        {
            panel1.Visible = false;
            label17.Text = "Kunde-Bearbeiten";
            cmd = new OleDbCommand("Select * from Kunde where Nr = " + Kunde + "", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            textBox17.Text = Convert.ToString(dr.GetInt32(0));
            textBox1.Text = dr.GetString(1);
            textBox2.Text = dr.GetString(2);
            textBox4.Text = dr.GetString(3);
            textBox3.Text = dr.GetString(4);
            textBox5.Text = Convert.ToString(dr.GetInt32(5));
            textBox6.Text = dr.GetString(6);
            textBox7.Text = dr.GetString(7);
            textBox8.Text = dr.GetString(8);
            checkBox2.Checked = dr.GetBoolean(9);
            con.Close();
            if (panel2.Visible == true)
            {
                checkBox4.Checked = true;
            }
            else
            {
                checkBox4.Checked = false;
            }

            try
            {
                checkBox4.Visible = true;
                ansprechpartnerBefuelen(Kunde);

                lieferadresseBefuelen(Kunde);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            position();
        }
        public void lieferadresseBefuelen(long Kunde)
        {
            con.Open();
            OleDbDataAdapter adapp = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "and KundeLieferort.IsActive = true", con);

            DataTable dt = new DataTable();
            DataRow d = dt.NewRow();
            adapp.Fill(dt);
            con.Close();


            if (dt.Rows.Count > 0)
            {
                lAdressVorhanden = 1;
                panel1.Visible = true;

                adapp = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "and KundeLieferort.IsActive = true", con);
                edit.DataGridFuellen("Nr", adapp, dataGridView1);

                iconButton3.Visible = true;
                checkBox1.Checked = false;
            }
            else
            {
                panel1.Visible = false;
                lAdressVorhanden = 0;
            }


        }
        public void ansprechpartnerBefuelen(long Kunde)
        {
            con.Open();
            adap = new OleDbDataAdapter("SELECT Ansprechpartner.* from Ansprechpartner, Kunde where Ansprechpartner.Kunde = Kunde.Nr and Ansprechpartner.Kunde = " + Kunde + "and Ansprechpartner.IsActive = true", con);

            DataTable dt = new DataTable();
            DataRow d = dt.NewRow();
            adap.Fill(dt);
            con.Close();

            if (dt.Rows.Count >= 1)
            {
                ansprechpartnerVorhanden = 1;
                panel2.Visible = true;
                adap = new OleDbDataAdapter("SELECT Ansprechpartner.* from Ansprechpartner, Kunde where Ansprechpartner.Kunde = Kunde.Nr and Ansprechpartner.Kunde = " + Kunde + " and Ansprechpartner.IsActive = true", con);
                edit.DataGridFuellen("Nr", adap, Ansprechpartner);
                checkBox6.Checked = true;

            }
            else
            {
                ansprechpartnerVorhanden = 0;
                panel2.Visible = false;
                checkBox6.Checked = true;
            }

        }
        public static void hochzaehlen(string nr, string tabelle, TextBox textBox, Panel panel)
        {
            if (panel.Visible == true)
            {
                edit.nrHochZaehlen(tabelle, textBox);
            }

        }
        private void Kunde_Load(object sender, EventArgs e)
        {
            TC.Height = 808;

            if (Kunde == 0)
            {
                kundehinzufuegen_load(Kunde);
                checkBox5.Visible = false;
                checkBox6.Visible = false;

            }
            else
            {
                kundebearbeiten_load(Kunde);
                if (panel2.Visible == true)
                {
                    checkBox4.Checked = true;
                }
                else
                {
                    checkBox4.Checked = false;
                }
                checknr.Visible = false;
            }

            lieferdaten.Visible = false;


        }

        private void iconButton5_Click(object sender, EventArgs e)
        {

            string Ausgewähltezelle = Ansprechpartner.CurrentRow.Cells["Nr"].Value.ToString();
            adap = new OleDbDataAdapter("SELECT Distinct Auftrag.Ansprechpartner from Auftrag, Ansprechpartner where Ansprechpartner.Nr = Auftrag.Ansprechpartner and Auftrag.Ansprechpartner =" + Ausgewähltezelle + "and Ansprechpartner.IsActive = true", con);
            con.Open();
            DataTable dt = new DataTable();
            DataRow d = dt.NewRow();
            adap.Fill(dt);
            con.Close();

            if (dt.Rows.Count >= 1)
            {
                MessageBox.Show("Sie Können den Ansprechpartner nicht löschen, da er in einem Auftrag vorkommt." +
                "Löschen oder änderen sie ihren Ansprechpartner im Auftrag um zu löschen!");
            }
            else
            {

                DialogResult result = MessageBox.Show("Sind Sie sicher das Sie den ausgewählten Ansprechpartner löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)

                {
                    con.Open();
                    cmd = new OleDbCommand("Update Ansprechpartner set IsActive = false  where Nr = " + Ausgewähltezelle + "", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    con.Close();


                    adap = new OleDbDataAdapter("SELECT Ansprechpartner.* from Ansprechpartner, Kunde where Ansprechpartner.Kunde = Kunde.Nr and Ansprechpartner.Kunde = " + Kunde + "and Ansprechpartner.IsActive = true", con);
                    edit.DataGridFuellen("Nr", adap, Ansprechpartner);
                    ansprechpartnerBefuelen(Kunde);
                    if (checkBox6.Checked && !panel2.Visible)
                    {
                        checkBox4.Checked = false;
                    }
                }
            }
            position();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            hinzuOderBearbeiten = 1;
            if (checkBox1.Checked == true)
            {
                lieferdaten.Visible = false;
            }
            else
            {
                lieferdaten.Visible = true;
                iconButton3.Visible = true;
                if (Kunde == 0)
                {
                    iconButton3.Visible = false;
                }
                hochzaehlen("Nr", "KundeLieferort", textBox18, lieferdaten);

            }
        }
        public bool kIsActive()
        {
            con.Open();
            cmd = new OleDbCommand("Select IsActive from Kunde where Nr =" + textBox17.Text + "", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            bool kundeIsActive = dr.GetBoolean(0);
            con.Close();
            return kundeIsActive;
        }
        public void updateLieferadresse()
        {
            if (lieferdaten.Visible == true)
            {
                con.Open();
                cmd = new OleDbCommand("Select IsActive from Kunde where Nr =" + textBox17.Text + "", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                bool kundeIsActive = dr.GetBoolean(0);
                con.Close();
                if (checkBox3.Checked == true)
                {
                    if (kundeIsActive == false)
                    {
                        MessageBox.Show("Der Angegebene Kunde ist nicht Aktiv!");
                        textBox17.Focus();
                        checkBox3.Checked = false;
                    }
                    else
                    {
                        con.Open();
                        cmd = new OleDbCommand("update KundeLieferort set Bez = '" + textBox16.Text.ToString() + "', Telefon = '" + textBox15.Text.ToString() + "', Email = '" + textBox14.Text.ToString() + "', Fax = '" + textBox13.Text.ToString() + "', PLZ = '" + textBox12.Text.ToString() + "', Ort = '" + textBox11.Text.ToString() + "', Straße = '" + textBox10.Text.ToString() + "', Land = '" + textBox9.Text.ToString() + "',  IsActive = " + checkBox3.Checked + " where Nr = " + Convert.ToInt64(textBox18.Text) + "", con);

                        cmd.ExecuteNonQuery();

                        con.Close();
                        adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "", con);
                        edit.DataGridFuellen("Nr", adap, dataGridView1);

                    }
                }
                else
                {
                    con.Open();
                    cmd = new OleDbCommand("update KundeLieferort set Bez = '" + textBox16.Text.ToString() + "', Telefon = '" + textBox15.Text.ToString() + "', Email = '" + textBox14.Text.ToString() + "', Fax = '" + textBox13.Text.ToString() + "', PLZ = '" + textBox12.Text.ToString() + "', Ort = '" + textBox11.Text.ToString() + "', Straße = '" + textBox10.Text.ToString() + "', Land = '" + textBox9.Text.ToString() + "',  IsActive = " + checkBox3.Checked + " where Nr = " + Convert.ToInt64(textBox18.Text) + "", con);

                    cmd.ExecuteNonQuery();

                    con.Close();
                }
            }

        }
        public static int erstellt = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox17.TextLength > 0)
            {
                if (textBox1.TextLength > 0)
                {
                    if (textBox2.TextLength > 0)
                    {
                        if (textBox3.TextLength > 0)
                        {
                            if (textBox4.TextLength > 0)
                            {
                                if (textBox5.TextLength > 0)
                                {
                                    if (textBox6.TextLength > 0)
                                    {
                                        if (textBox8.TextLength > 0)
                                        {
                                            if (textBox7.TextLength > 0)
                                            {
                                                string kundeNr = textBox17.Text;
                                                if (textBox4.Text.Contains("@"))
                                                {
                                                    if (Kunde == 0)
                                                    {
                                                        if (checkBox1.Checked == false)
                                                        {
                                                            if (textBox16.TextLength > 0)
                                                            {
                                                                if (textBox13.Text.Contains("@"))
                                                                {
                                                                    if (lieferdaten.Visible == true && !checkBox2.Checked & checkBox3.Checked)
                                                                    {
                                                                        MessageBox.Show("Sie können nicht  die Lieferadress mit unterschidlichen IsAktive statusen austatten");
                                                                    }
                                                                    else
                                                                    {
                                                                        con.Open();
                                                                        cmd = new OleDbCommand("Insert into Kunde (Nr, Bez, Telefon, Email, Fax, PLZ, Ort, Straße, Land, IsActive) values ('" + textBox17.Text + "', '" + textBox1.Text + "', '" + textBox2.Text + "','" + textBox4.Text + "','" + textBox3.Text + "', '" + textBox5.Text + "', '" + textBox6.Text + "','" + textBox7.Text + "' , '" + textBox8.Text + "'," + checkBox2.Checked + ")", con);

                                                                        cmd.ExecuteNonQuery();
                                                                        con.Close();

                                                                        con.Open();
                                                                        cmd = new OleDbCommand("Insert into KundeLieferort (Nr, Kunde, Bez, Telefon, Email, Fax, PLZ, Ort, Straße, Land, IsActive) values ('" + textBox18.Text + "', '" + textBox17.Text + "', '" + textBox16.Text + "', '" + textBox15.Text + "','" + textBox14.Text + "','" + textBox13.Text + "', '" + textBox12.Text + "', '" + textBox11.Text + "','" + textBox10.Text + "' , '" + textBox9.Text + "'," + checkBox3.Checked + ")", con);

                                                                        cmd.ExecuteNonQuery();
                                                                        con.Close();

                                                                        DialogResult result = MessageBox.Show("Wollen sie zu ihrem Kunden einen Ansprechpartner Hinzufügen?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                                                        if (result == DialogResult.Yes)
                                                                        {
                                                                            ansprechpartnerrr = 1;
                                                                            TabPage ansprechpartnerPage = new TabPage();
                                                                            Ansprechpartner ansprechpartner = new Ansprechpartner(kundeNr, TC, ansprechpartnerPage);

                                                                            ansprechpartnerPage.Controls.Clear();

                                                                            ansprechpartnerPage.Text = "Ansprechpartner hinzufügen";
                                                                            TC.TabPages.Add(ansprechpartnerPage);
                                                                            LoadForm.OpenTab(ansprechpartner, ansprechpartnerPage);
                                                                            TabPage selectedpage = TC.SelectedTab;

                                                                            TC.TabPages.Remove(selectedpage);
                                                                            TC.SelectedTab = ansprechpartnerPage;

                                                                            TC.Height = 808;

                                                                            erstellt = 1;
                                                                        }
                                                                        else
                                                                        {
                                                                            MessageBox.Show("Neuer Kunde wurde erstellt!");

                                                                            TabPage selectedpage = TC.SelectedTab;

                                                                            TC.TabPages.Remove(selectedpage);

                                                                        }
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    MessageBox.Show("In der Email muss ein @ zeichen stehen!");
                                                                    textBox13.Focus();
                                                                }
                                                            }
                                                            else
                                                            {
                                                                MessageBox.Show("Sie müssen eine Bezeichnung eingeben");
                                                                textBox16.Focus();
                                                                textBox16.BackColor = Color.OrangeRed;

                                                            }

                                                        }
                                                        else
                                                        {
                                                            con.Open();
                                                            cmd = new OleDbCommand("Insert into Kunde (Nr, Bez, Telefon, Email, Fax, PLZ, Ort, Straße, Land, IsActive) values ('" + textBox17.Text + "', '" + textBox1.Text + "', '" + textBox2.Text + "','" + textBox4.Text + "','" + textBox3.Text + "', '" + textBox5.Text + "', '" + textBox6.Text + "','" + textBox7.Text + "' , '" + textBox8.Text + "'," + checkBox2.Checked + ")", con);

                                                            cmd.ExecuteNonQuery();
                                                            con.Close();

                                                            DialogResult result = MessageBox.Show("Wollen sie zu ihrem Kunden einen Ansprechpartner Hinzufügen?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                                            if (result == DialogResult.Yes)
                                                            {
                                                                ansprechpartnerrr++;
                                                                TabPage ansprechpartnerPage = new TabPage();
                                                                Ansprechpartner ansprechpartner = new Ansprechpartner(kundeNr, TC, ansprechpartnerPage);

                                                                ansprechpartnerPage.Controls.Clear();

                                                                ansprechpartnerPage.Text = "Ansprechpartner hinzufügen";
                                                                TC.TabPages.Add(ansprechpartnerPage);
                                                                LoadForm.OpenTab(ansprechpartner, ansprechpartnerPage);
                                                                TabPage selectedpage = TC.SelectedTab;

                                                                TC.TabPages.Remove(selectedpage);
                                                                TC.SelectedTab = ansprechpartnerPage;

                                                                TC.Height = 808;
                                                            }
                                                            else
                                                            {
                                                                MessageBox.Show("Neuer Kunde wurde erstellt!");

                                                                TabPage selectedpage = TC.SelectedTab;

                                                                TC.TabPages.Remove(selectedpage);

                                                            }
                                                        }
                                                        con.Close();
                                                    }
                                                    else if (Kunde > 0)
                                                    {
                                                        if (!checkBox2.Checked)
                                                        {

                                                            adap = new OleDbDataAdapter("SELECT distinct Auftrag.Kunde from Auftrag, Kunde,Auftragsstatus where Kunde.Nr = Auftrag.Kunde and Auftrag.Kunde = " + Kunde + " and Auftrag.Status = Auftragsstatus.Nr and Auftrag.Status = 1" +
                                                                " and Kunde.IsActive = true;", con);
                                                            con.Open();
                                                            DataTable dt = new DataTable();
                                                            DataRow d = dt.NewRow();
                                                            adap.Fill(dt);
                                                            con.Close();

                                                            if (dt.Rows.Count >= 1)
                                                            {
                                                                MessageBox.Show("Sie Können den Kunden nicht löschen, da er in einem Auftrag vorkommt der noch in Bearbeitung ist.");
                                                            }
                                                            else
                                                            {
                                                                DialogResult result = MessageBox.Show("Sind Sie sicher das Sie den ausgewählten Kunden und, wenn angegeben die zusätzlichen Lieferadressen + Ansprechpartner von dem Kunden auf unaktiv setzen  möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                                                if (result == DialogResult.Yes)
                                                                {
                                                                    con.Open();
                                                                    cmd = new OleDbCommand("Update KundeLieferort set IsActive = false where KundeLieferort.Kunde  =" + textBox17.Text + "", con);
                                                                    dr = cmd.ExecuteReader();
                                                                    dr.Read();
                                                                    con.Close();

                                                                    con.Open();
                                                                    cmd = new OleDbCommand(" Update Ansprechpartner set IsActive = false where Ansprechpartner.Kunde = " + textBox17.Text + "", con);
                                                                    dr = cmd.ExecuteReader();
                                                                    dr.Read();
                                                                    con.Close();

                                                                    con.Open();
                                                                    cmd = new OleDbCommand("update Kunde set Bez = '" + textBox1.Text.ToString() + "', Telefon = '" + textBox2.Text.ToString() + "', Email = '" + textBox4.Text.ToString() + "', Fax = '" + textBox3.Text.ToString() + "', PLZ = '" + textBox5.Text.ToString() + "', Ort = '" + textBox6.Text.ToString() + "', Straße = '" + textBox7.Text.ToString() + "', Land = '" + textBox8.Text.ToString() + "',  IsActive = " + checkBox2.Checked + " where Nr = " + Convert.ToInt64(textBox17.Text) + "", con);

                                                                    cmd.ExecuteNonQuery();

                                                                    con.Close();

                                                                    if (lieferdaten.Visible == true)
                                                                    {
                                                                        if (textBox18.TextLength == 0)
                                                                        {
                                                                            MessageBox.Show("Geben sie eine Nummer ein!");
                                                                            textBox18.Focus();
                                                                        }
                                                                        else
                                                                        {
                                                                            TabPage selectedpage = TC.SelectedTab;

                                                                            TC.TabPages.Remove(selectedpage);

                                                                            MessageBox.Show("Update erfolgreich");

                                                                        }

                                                                    }
                                                                    else
                                                                    {
                                                                        updateLieferadresse();

                                                                        MessageBox.Show("Update erfolgreich");

                                                                        TabPage selectedpage = TC.SelectedTab;

                                                                        TC.TabPages.Remove(selectedpage);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        else
                                                        {
                                                            con.Open();
                                                            cmd = new OleDbCommand("update Kunde set Bez = '" + textBox1.Text.ToString() + "', Telefon = '" + textBox2.Text.ToString() + "', Email = '" + textBox4.Text.ToString() + "', Fax = '" + textBox3.Text.ToString() + "', PLZ = '" + textBox5.Text.ToString() + "', Ort = '" + textBox6.Text.ToString() + "', Straße = '" + textBox7.Text.ToString() + "', Land = '" + textBox8.Text.ToString() + "',  IsActive = " + checkBox2.Checked + " where Nr = " + Convert.ToInt64(textBox17.Text) + "", con);

                                                            cmd.ExecuteNonQuery();

                                                            con.Close();

                                                            if (lieferdaten.Visible == true)
                                                            {
                                                                if (textBox18.TextLength == 0)
                                                                {
                                                                    MessageBox.Show("Geben sie eine Nummer ein!");
                                                                    textBox18.Focus();
                                                                }
                                                                else
                                                                {
                                                                    TabPage selectedpage = TC.SelectedTab;

                                                                    TC.TabPages.Remove(selectedpage);

                                                                    MessageBox.Show("Update erfolgreich");

                                                                }

                                                            }
                                                            else
                                                            {
                                                                updateLieferadresse();

                                                                MessageBox.Show("Update erfolgreich");

                                                                TabPage selectedpage = TC.SelectedTab;

                                                                TC.TabPages.Remove(selectedpage);
                                                            }
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    Info.Information("Die Email muss ein @ enthalten!");
                                                    textBox4.Focus();
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Sie müssen eine Straße + Nummer eingeben");
                                                textBox7.Focus();
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Sie müssen ein Land eingeben");
                                            textBox8.Focus();
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Sie müssen einen Ort eingeben");
                                        textBox6.Focus();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Sie müssen eine PLZ eingeben");
                                    textBox5.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Sie müssen eine E-Mail eingeben");
                                textBox4.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Sie müssen ein Fax eingeben");
                            textBox3.Focus();
                        }

                    }
                    else
                    {
                        MessageBox.Show("Sie müssen eine Telefonnummer eingeben");
                        textBox2.Focus();
                    }

                }
                else
                {
                    MessageBox.Show("Sie müssen eine Bezeichnung eingeben");
                    textBox1.Focus();
                    textBox1.BackColor = Color.OrangeRed;
                }
            }
            else
            {
                MessageBox.Show("Sie müssen eine Nummer eingeben");
                textBox17.Focus();
                textBox17.BackColor = Color.OrangeRed;
            }

        }
        public void liefbutton()
        {
            adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "and KundeLieferort.IsActive = true", con);
            con.Open();
            DataTable dt = new DataTable();
            DataRow d = dt.NewRow();
            adap.Fill(dt);

            con.Close();

            if (dt.Rows.Count > 0)
            {
                checkBox1.Checked = false;
            }
            else
            {
                checkBox1.Checked = true;
            }

            textBox18.Text = "";
            textBox16.Text = "";
            textBox15.Text = "";
            textBox14.Text = "";
            textBox13.Text = "";
            textBox12.Text = "";
            textBox11.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            checkBox3.Checked = true;

        }
        private void iconButton3_Click(object sender, EventArgs e)
        {
            if (Kunde == 0)
            {
                if (textBox18.TextLength > 0)
                {
                    if (textBox16.TextLength > 0)
                    {
                        if (textBox13.Text.Contains("@"))
                        {
                            if (textBox15.TextLength > 0)
                            {
                                if (textBox14.TextLength > 0)
                                {
                                    if (textBox13.TextLength > 0)
                                    {
                                        if (textBox12.TextLength > 0)
                                        {
                                            if (textBox11.TextLength > 0)
                                            {
                                                if (textBox9.TextLength > 0)
                                                {
                                                    if (textBox10.TextLength > 0)
                                                    {

                                                        if (hinzuOderBearbeiten > 0)
                                                        {

                                                            con.Open();
                                                            cmd = new OleDbCommand("Insert into KundeLieferort (Nr, Kunde, Bez, Telefon, Email, Fax, PLZ, Ort, Straße, Land, IsActive) values ('" + textBox18.Text + "', '" + textBox17.Text + "', '" + textBox16.Text + "', '" + textBox15.Text + "','" + textBox14.Text + "','" + textBox13.Text + "', '" + textBox12.Text + "', '" + textBox11.Text + "','" + textBox10.Text + "' , '" + textBox9.Text + "'," + checkBox3.Checked + ")", con);

                                                            cmd.ExecuteNonQuery();
                                                            con.Close();
                                                            if (checkBox3.Checked)
                                                            {
                                                                lAdressVorhanden = 1;
                                                                checkBox5.Checked = true;
                                                            }
                                                            else
                                                            {
                                                                lAdressVorhanden = 0;
                                                                checkBox5.Checked = false;
                                                            }

                                                            adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "", con);
                                                            edit.DataGridFuellen("Nr", adap, dataGridView1);
                                                            checkBox5_CheckedChanged(sender, e);


                                                            if (panel2.Visible == true)
                                                            {
                                                                TC.Height = 808;
                                                                button1.Location = new Point(777, 727);
                                                            }
                                                            liefbutton();
                                                            position();
                                                        }
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show("Geben sie eine Straße und Hausnummer ein");
                                                        textBox10.Focus();
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Geben sie ein Land ein");
                                                    textBox9.Focus();
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Geben sie einen Ort ein");
                                                textBox11.Focus();
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Geben sie eine PLZ ein");
                                            textBox12.Focus();
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Geben sie eine E-Mail ein");
                                        textBox13.Focus();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Geben sie ein Fax ein");
                                    textBox14.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Geben sie eine Telefonnummer ein");
                                textBox15.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("In der Email muss ein @ zeichen stehen!");
                            textBox13.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Sie müssen eine Bezeichnung eingeben");
                        textBox16.Focus();
                        textBox16.BackColor = Color.OrangeRed;
                    }
                }
                else
                {
                    MessageBox.Show("Eine Nummer muss angegeben sein");
                    textBox18.Focus();
                }
            }
            else
            {
                if (textBox18.TextLength > 0)
                {
                    if (textBox16.TextLength > 0)
                    {
                        if (textBox13.Text.Contains("@"))
                        {
                            adap = new OleDbDataAdapter("SELECT Kunde.* from Kunde where Kunde.Nr = " + Kunde + "and Kunde.IsActive = true", con);
                            con.Open();
                            DataTable dt = new DataTable();
                            DataRow d = dt.NewRow();
                            adap.Fill(dt);

                            con.Close();
                            if (checkBox3.Checked == true && dt.Rows.Count < 1)
                            {

                                MessageBox.Show("Da der Kunde nicht aktiv ist können sie die Lieferadresse nicht auf aktiv setzen");

                            }
                            else
                            {
                                if (hinzuOderBearbeiten > 0)
                                {

                                    con.Open();
                                    cmd = new OleDbCommand("Insert into KundeLieferort (Nr, Kunde, Bez, Telefon, Email, Fax, PLZ, Ort, Straße, Land, IsActive) values ('" + textBox18.Text + "', '" + textBox17.Text + "', '" + textBox16.Text + "', '" + textBox15.Text + "','" + textBox14.Text + "','" + textBox13.Text + "', '" + textBox12.Text + "', '" + textBox11.Text + "','" + textBox10.Text + "' , '" + textBox9.Text + "'," + checkBox3.Checked + ")", con);

                                    cmd.ExecuteNonQuery();
                                    con.Close();
                                    if (checkBox3.Checked)
                                    {
                                        lAdressVorhanden = 1;
                                        checkBox5.Checked = true;
                                    }
                                    else
                                    {
                                        lAdressVorhanden = 0;
                                        checkBox5.Checked = false;
                                    }

                                    adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "", con);
                                    edit.DataGridFuellen("Nr", adap, dataGridView1);
                                    checkBox5_CheckedChanged(sender, e);


                                    if (panel2.Visible == true)
                                    {
                                        TC.Height = 808;
                                        button1.Location = new Point(777, 727);
                                    }
                                    liefbutton();
                                    position();
                                }
                                else
                                {
                                    updateLieferadresse();
                                    lAdressVorhanden = 0;
                                    checkBox5_CheckedChanged(sender, e);
                                    liefbutton();
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("In der Email muss ein @ zeichen stehen!");
                            textBox13.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Sie müssen eine Bezeichnung eingeben");
                        textBox16.Focus();
                        textBox16.BackColor = Color.OrangeRed;
                    }
                }
                else
                {
                    MessageBox.Show("Eine Nummer muss angegeben sein");
                    textBox18.Focus();
                }
            }
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            hinzuOderBearbeiten++;
            lieferdaten.Visible = true;
            textBox18.Clear();
            textBox16.Clear();
            textBox15.Clear();
            textBox14.Clear();
            textBox13.Clear();
            textBox12.Clear();
            textBox11.Clear();
            textBox10.Clear();
            textBox9.Clear();
            checkBox1.Checked = false;
            hochzaehlen("Nr", "KundeLieferort", textBox18, lieferdaten);
            iconButton3.Visible = true;
        }
        public static int lAdressVorhanden = 0;
        public static int ansprechpartnerVorhanden = 0;
        private void iconButton6_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();
            DialogResult result = MessageBox.Show("Sind Sie sicher das Sie die ausgewählte Lieferadresse löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                con.Open();
                cmd = new OleDbCommand("Update KundeLieferort set IsActive = false where Nr = " + Ausgewähltezelle + "", con);
                dr = cmd.ExecuteReader();
                dr.Read();
                con.Close();


                MessageBox.Show("Gelöscht.");

            }
            adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "and KundeLieferort.IsActive = true", con);
            edit.DataGridFuellen("Nr", adap, dataGridView1);

            adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "and KundeLieferort.IsActive = true", con);
            con.Open();
            DataTable dt = new DataTable();
            DataRow d = dt.NewRow();
            adap.Fill(dt);

            con.Close();

            if (dt.Rows.Count < 1)
            {
                panel1.Visible = false;
                checkBox1.Checked = true;
                lAdressVorhanden = 0;
                position();
            }
            else
            {
                lAdressVorhanden = 1;
                position();


                panel1.Visible = true;
                adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "", con);
                edit.DataGridFuellen("Nr", adap, dataGridView1);


            }
            if (panel1.Visible == false)
            {
                TC.Height = 647;
                button1.Location = new Point(777, 727);
            }
            position();
        }

        private void iconButton7_Click(object sender, EventArgs e)
        {
            hinzuOderBearbeiten = 0;
            iconButton3.Visible = false;
            lieferdaten.Visible = true;

            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();

            cmd = new OleDbCommand("select * from KundeLieferort where Nr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);
            con.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            textBox18.Text = Convert.ToString(dr.GetInt32(0));
            textBox16.Text = dr.GetString(2);
            textBox15.Text = dr.GetString(3);
            textBox14.Text = dr.GetString(4);
            textBox13.Text = dr.GetString(5);
            textBox12.Text = Convert.ToString(dr.GetInt32(6));
            textBox11.Text = dr.GetString(7);
            textBox10.Text = dr.GetString(8);
            textBox9.Text = dr.GetString(9);
            checkBox3.Checked = dr.GetBoolean(10);
            con.Close();
            iconButton3.Visible = true;
        }
        TabPage ansprechpartnerPage = new TabPage();
        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (!TC.Contains(ansprechpartnerPage))
            {
                string kundeNr = textBox17.Text;

                if (checkBox4.Checked == true & panel2.Visible == false)
                {

                    Ansprechpartner ansprechpartner = new Ansprechpartner(kundeNr, TC, ansprechpartnerPage);

                    DialogResult result = MessageBox.Show("Wollen sie zu ihrem Kunden einen Ansprechpartner Hinzufügen?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        ansprechpartnerrr = 1;
                        ansprechpartnerPage.Controls.Clear();

                        ansprechpartnerPage.Text = "Ansprechpartner hinzufügen";
                        TC.TabPages.Add(ansprechpartnerPage);
                        LoadForm.OpenTab(ansprechpartner, ansprechpartnerPage);
                        TC.SelectedTab = ansprechpartnerPage;

                    }
                }

            }
            else
            {
                if (checkBox4.Checked == false)
                {
                    TC.TabPages.Remove(ansprechpartnerPage);
                }
            }

        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            ansprechpartnerrr = 1;
            string kundeNr = textBox17.Text;
            TabPage ansprechpartnerhinzufuegen = new TabPage();
            Ansprechpartner ansprechpartner = new Ansprechpartner(kundeNr, TC, ansprechpartnerhinzufuegen);

            ansprechpartnerhinzufuegen.Controls.Clear();

            ansprechpartnerhinzufuegen.Text = "Ansprechpartner hinzufügen";
            TC.TabPages.Add(ansprechpartnerhinzufuegen);
            LoadForm.OpenTab(ansprechpartner, ansprechpartnerhinzufuegen);
            TC.SelectedTab = ansprechpartnerhinzufuegen;
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            ansprechpartnerrr = 2;
            string Ausgewähltezelle = Ansprechpartner.CurrentRow.Cells["Nr"].Value.ToString();

            con.Open();
            cmd = new OleDbCommand("SELECT Ansprechpartner.* from Ansprechpartner where Ansprechpartner.Nr = " + Ausgewähltezelle + "", con);

            dr = cmd.ExecuteReader();
            dr.Read();
            string aNr = Convert.ToString(dr.GetInt32(0));

            con.Close();
            TabPage ansprechpartnerBearbeiten = new TabPage();
            Ansprechpartner ansprechpartner = new Ansprechpartner(aNr, TC, ansprechpartnerBearbeiten);

            ansprechpartnerBearbeiten.Controls.Clear();

            ansprechpartnerBearbeiten.Text = "Ansprechpartner bearbeiten";
            TC.TabPages.Add(ansprechpartnerBearbeiten);
            LoadForm.OpenTab(ansprechpartner, ansprechpartnerBearbeiten);
            TC.SelectedTab = ansprechpartnerBearbeiten;

        }
        private void textBox17_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (Kunde == 0)
            {
                edit.colorChange(textBox17);
            }
        }
        private void KundeAdd_Enter(object sender, EventArgs e)
        {
            ansprechpartnerBefuelen(Kunde);
            checkBox6_CheckedChanged(sender, e);

            adap = new OleDbDataAdapter("SELECT Ansprechpartner.* from Ansprechpartner, Kunde where Ansprechpartner.Kunde = Kunde.Nr and Ansprechpartner.Kunde = " + Kunde + "and Ansprechpartner.IsActive = true", con);
            DataTable dt = new DataTable();
            DataRow d = dt.NewRow();
            adap.Fill(dt);


            if (dt.Rows.Count >= 1)
            {
                checkBox4.Checked = true;

            }
            else
            {
                checkBox4.Checked = false;
            }

        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
            {
                ansprechpartnerBefuelen(Kunde);
                edit.IstAktiv(adap, Ansprechpartner, 8);
                if (ansprechpartnerVorhanden == 1)
                {
                    panel2.Visible = true;
                }
                else
                {
                    panel2.Visible = false;
                }
            }
            else
            {
                adap = new OleDbDataAdapter("SELECT Ansprechpartner.* from Ansprechpartner, Kunde where Ansprechpartner.Kunde = Kunde.Nr and Ansprechpartner.Kunde = " + Kunde + "", con);
                edit.DataGridFuellen("Nr", adap, Ansprechpartner);
                DataTable dt = new DataTable();
                DataRow d = dt.NewRow();
                adap.Fill(dt);


                if (dt.Rows.Count >= 1)
                {
                    panel2.Visible = true;
                }
                else
                {
                    panel2.Visible = false;
                }
            }
            position();
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                lieferadresseBefuelen(Kunde);
                edit.IstAktiv(adap, dataGridView1, 10);
                if (lAdressVorhanden == 1)
                {
                    panel1.Visible = true;
                }
                else
                {
                    panel1.Visible = false;
                }

            }
            else
            {
                OleDbDataAdapter adap = new OleDbDataAdapter("SELECT KundeLieferort.* from KundeLieferort, Kunde where KundeLieferort.Kunde = Kunde.Nr and KundeLieferort.Kunde = " + Kunde + "", con);
                edit.DataGridFuellen("Nr", adap, dataGridView1);
                DataTable dt = new DataTable();
                DataRow d = dt.NewRow();
                adap.Fill(dt);


                if (dt.Rows.Count > 0)
                {
                    panel1.Visible = true;
                }
                else
                {
                    panel1.Visible = false;
                }
            }
            position();
        }

        private void textBox17_Leave(object sender, EventArgs e)
        {
            if (Kunde == 0)
            {
                if (textBox17.TextLength <= 0)
                {
                    if (Kunde > 0)
                    {
                        textBox17.Text = Convert.ToString(Kunde);
                    }
                    else
                    {
                        edit.nrHochZaehlen("Kunde", textBox17);
                    }
                    textBox17.ReadOnly = true;
                    textBox17.BackColor = Color.FromArgb(224, 224, 224);
                }
                else
                {
                    if (Kunde > 0)
                    {
                        if (textBox17.Text == Convert.ToString(Kunde))
                        {
                            textBox17.ReadOnly = true;
                            textBox17.BackColor = Color.FromArgb(224, 224, 224);
                        }
                        else
                        {
                            MessageBox.Show("Sie können die Nummer nicht ändern, da sie einen Kunden Bearbeiten");
                            textBox17.Text = Convert.ToString(Kunde);
                            textBox17.ReadOnly = true;
                            textBox17.BackColor = Color.FromArgb(224, 224, 224);
                        }
                    }
                    else
                    {
                        adap = new OleDbDataAdapter("SELECT Kunde.Nr from Kunde where Kunde.Nr = " + textBox17.Text + "", con);

                        DataTable dt = new DataTable();
                        DataRow d = dt.NewRow();
                        adap.Fill(dt);

                        if (dt.Rows.Count < 1)
                        {
                            textBox17.ReadOnly = true;
                            textBox17.BackColor = Color.FromArgb(224, 224, 224);
                        }
                        else
                        {

                            MessageBox.Show("Diese Kundennummer ist bereits von vorhanden");
                            textBox17.Clear();
                            textBox17.Focus();

                        }
                    }
                }
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (lieferdaten.Visible == true)
            {
                if (checkBox2.Checked)
                {
                    checkBox3.Checked = true;
                }
                else
                {
                    checkBox3.Checked = false;
                }
            }
        }
        private void textBox17_KeyPress(object sender, KeyPressEventArgs e)
        {
            edit.nummer(sender, e, textBox17);
        }

        private void textBox18_KeyPress(object sender, KeyPressEventArgs e)
        {
            edit.nummer(sender, e, textBox18);
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            edit.nummer(sender, e, textBox5);
        }

        private void textBox12_KeyPress(object sender, KeyPressEventArgs e)
        {
            edit.nummer(sender, e, textBox12);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.TextLength > 0)
            {
                textBox1.BackColor = Color.White;
            }
        }


        private void textBox16_TextChanged(object sender, EventArgs e)
        {
            if (textBox16.TextLength > 0)
            {
                textBox16.BackColor = Color.White;
            }
        }

        private void checknr_CheckedChanged(object sender, EventArgs e)
        {
            if (checknr.Checked)
            {
                if (Kunde == 0)
                {
                    edit.colorChange(textBox17);
                }
            }
            else
            {
                if (Kunde == 0)
                {
                    if (textBox17.TextLength <= 0)
                    {
                        if (Kunde > 0)
                        {
                            textBox17.Text = Convert.ToString(Kunde);
                        }
                        else
                        {
                            edit.nrHochZaehlen("Kunde", textBox17);
                        }
                        textBox17.ReadOnly = true;
                        textBox17.BackColor = Color.FromArgb(224, 224, 224);
                    }
                }
            }
        }
    }
}