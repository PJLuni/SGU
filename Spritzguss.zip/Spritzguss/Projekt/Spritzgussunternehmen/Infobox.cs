﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FontAwesome.Sharp;


namespace Spritzgussunternehmen
{
    public partial class Infobox : Form
    {
        
        public Infobox(string Type, string Text)
        {
            InitializeComponent();
            switch (Type)
            {
                case "Info":
                    this.BackColor = Color.Blue;
                    headertxt.Text = "Information";
                    infoicon.IconChar = IconChar.InfoCircle;
                    break;
                case "Error":
                    this.BackColor = Color.Red;
                    headertxt.Text = "Aktion Fehlgeschlagen";
                    infoicon.IconChar = IconChar.ExclamationTriangle;
                    break;
                case "Warning":
                    this.BackColor = Color.Orange;
                    headertxt.Text = "Achtung";
                    infoicon.IconChar = IconChar.ExclamationTriangle;
                    break;
                case "Success":
                    this.BackColor = Color.Green;
                    headertxt.Text = "Aktion Erfolgreich";
                    infoicon.IconChar = IconChar.Check;
                    break;
            }

            infotxt.Text = Text;
        }

        private void ErrorForm_Load(object sender, EventArgs e)
        {
            this.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - (this.Width + 20), Screen.PrimaryScreen.WorkingArea.Height - (this.Height + 20));
            this.Width = 0;
        }

        private void ErrorForm_Shown(object sender, EventArgs e)
        {
            for (int i = 0; i < 396; i = i + 10)
            {
                int X = Screen.PrimaryScreen.WorkingArea.Width - (this.Width + 20);
                X = X - 10;

                this.Location = new Point(X, this.Location.Y);
                this.Width = this.Width + 10;
            }

            infoicon.Visible = true;
            closeicon.Visible = true;
            headertxt.Visible = true;
            infotxt.Visible = true;
        }

        private void closeicon_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}

