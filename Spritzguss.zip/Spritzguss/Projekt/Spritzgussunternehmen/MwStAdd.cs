﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class MwStAdd : Form
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        TabControl TC;
        long MwStNr;
        public MwStAdd(long MwStNr, TabControl TC)
        {
            this.TC = TC;
            this.MwStNr = MwStNr;
            InitializeComponent();
        }
        public void mwStBearbeitenLoad()
        {
            con.Open();
            OleDbCommand cmd = new OleDbCommand("Select * from MwSt where Nr = " + MwStNr + "", con);
            dr = cmd.ExecuteReader();
            dr.Read();
            textBox17.Text = Convert.ToString(dr.GetInt32(0));
            textBox4.Text = Convert.ToString(dr.GetInt32(1));
            checkBox2.Checked = dr.GetBoolean(2);
            con.Close();
        }
        private void MwStAdd_Load(object sender, EventArgs e)
        {
            if (MwStNr > 0)
            {
                label17.Text = "MwSt bearbeiten";
                mwStBearbeitenLoad();
            }
            else
            {
                label17.Text = "MwSt hinzufügen";
                edit.nrHochZaehlen("MwSt", textBox17);
            }
        }
        public void MwStHinzufuegen()
        {
            if (MwStNr == 0)
            {
                if (textBox17.TextLength > 0)
                {

                    con.Open();
                    cmd = new OleDbCommand("Insert into MwSt (Nr, Prozentsatz, IsActive) values ('" + textBox17.Text + "', '" + textBox4.Text + "', " + checkBox2.Checked + ")", con);

                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Neue MwSt wurde erstellt!");

                    TabPage selectedpage = TC.SelectedTab;

                    TC.TabPages.Remove(selectedpage);
                }
                else
                {
                    MessageBox.Show("Geben sie eine Nummer ein");
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox17.TextLength > 0)
            {
                if (textBox4.TextLength > 0)
                {
                    if (MwStNr > 0)
                    {
                        if (!checkBox2.Checked)
                        {

                            adap = new OleDbDataAdapter("SELECT DISTINCT Auftrag.MwSt FROM Auftrag, MwSt, Auftragsstatus WHERE MwSt.Nr = Auftrag.MwSt and Auftrag.MwSt = " + MwStNr + "" +
                                "and Auftrag.Status = Auftragsstatus.Nr and Auftrag.Status = 1 and MwSt.IsActive = true;", con);

                            con.Open();
                            DataTable dt = new DataTable();
                            DataRow d = dt.NewRow();
                            adap.Fill(dt);
                            con.Close();

                            if (dt.Rows.Count >= 1)
                            {
                                MessageBox.Show("Sie Können die MwSt nicht auf unaktiv setzen, da sie in einem Auftrag vorkommt der noch in Bearbeitung ist.");
                            }
                            else
                            {
                                DialogResult result = MessageBox.Show("Sind Sie sicher das Sie die ausgewählte MwSt auf unaktiv setzen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                if (result == DialogResult.Yes)
                                {
                                    con.Open();
                                    cmd = new OleDbCommand("Update MwSt set IsActive = false where Nr = " + MwStNr + "", con);
                                    dr = cmd.ExecuteReader();
                                    dr.Read();
                                    con.Close();

                                    con.Open();
                                    cmd = new OleDbCommand("update MwSt set Prozentsatz = '" + textBox4.Text.ToString() + "', IsActive = " + checkBox2.Checked + " where Nr = " + Convert.ToInt64(textBox17.Text) + "", con);

                                    cmd.ExecuteNonQuery();

                                    con.Close();

                                    MessageBox.Show("Update erfolgreich");

                                    TabPage selectedpage = TC.SelectedTab;

                                    TC.TabPages.Remove(selectedpage);
                                }
                            }
                        }
                        else
                        {
                            con.Open();
                            cmd = new OleDbCommand("SELECT MwSt.IsActive from MwSt where MwSt.Nr = " + MwStNr + "", con);

                            dr = cmd.ExecuteReader();
                            dr.Read();
                            bool testMwSt = dr.GetBoolean(0);

                            con.Close();
                            if (testMwSt == false)
                            {
                                con.Open();
                                cmd = new OleDbCommand("SELECT sum(MwSt.IsActive= true) from MwSt where not(MwSt.Nr = 1)", con);

                                dr = cmd.ExecuteReader();
                                dr.Read();
                                var countMwSt = dr.GetValue(0);

                                con.Close();

                                if (Convert.ToInt32(countMwSt) == 0)
                                {
                                    con.Open();
                                    cmd = new OleDbCommand("update MwSt set Prozentsatz = '" + textBox4.Text.ToString() + "', IsActive = " + checkBox2.Checked + " where Nr = " + Convert.ToInt64(textBox17.Text) + "", con);

                                    cmd.ExecuteNonQuery();

                                    con.Close();

                                    MessageBox.Show("Update erfolgreich");

                                    TabPage selectedpage = TC.SelectedTab;

                                    TC.TabPages.Remove(selectedpage);
                                }
                                else
                                {
                                    MessageBox.Show("Es kann nur eine Aktive MwSt geben");
                                }
                            }
                            else
                            {
                                con.Open();
                                cmd = new OleDbCommand("update MwSt set Prozentsatz = '" + textBox4.Text.ToString() + "', IsActive = " + checkBox2.Checked + " where Nr = " + Convert.ToInt64(textBox17.Text) + "", con);

                                cmd.ExecuteNonQuery();

                                con.Close();

                                MessageBox.Show("Update erfolgreich");

                                TabPage selectedpage = TC.SelectedTab;

                                TC.TabPages.Remove(selectedpage);
                            }
                        }
                    }
                    else
                    {
                        if (checkBox2.Checked)
                        {

                            con.Open();
                            cmd = new OleDbCommand("SELECT sum(MwSt.IsActive= true) from MwSt where not(MwSt.Nr = 1)", con);

                            dr = cmd.ExecuteReader();
                            dr.Read();
                            var countMwSt = dr.GetValue(0);

                            con.Close();

                            if (Convert.ToInt32(countMwSt) == 0)
                            {
                                MwStHinzufuegen();
                            }
                            else
                            {
                                MessageBox.Show("Es kann nur eine Aktive MwSt geben");
                            }
                        }
                        else
                        {
                            MwStHinzufuegen();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Geben sie ein Prozentsatz ein");
                    textBox4.Focus();
                }
            }
            else
            {
                MessageBox.Show("Geben sie eine Nummer ein!");
                textBox17.Focus();
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            edit.nummer(sender, e, textBox4);
        }
    }
}
