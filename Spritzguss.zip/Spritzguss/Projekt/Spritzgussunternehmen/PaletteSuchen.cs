﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class PaletteSuchen : Form
    {
        DataSet ds = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        TabControl TC;
        public PaletteSuchen(TabControl TC)
        {
            this.TC = TC;
            InitializeComponent();
        }

        private void Palette_Load(object sender, EventArgs e)
        {
            adap = new OleDbDataAdapter("Select * from Palette" , con);
            edit.DataGridFuellen("Nr",adap, dataGridView1);
            istAktiv_checkBox_CheckedChanged(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Update();
            dataGridView1.Refresh();
        }

       
        TabPage paletteHinzufuegen = new TabPage();
        private void iconButton1_Click(object sender, EventArgs e)
        {
            if (TC.TabPages.Contains(paletteHinzufuegen))
            {
                edit.pageswitch(paletteHinzufuegen, TC);
            }
            else
            {
                long pNr = 0;
                paletteHinzufuegen.Controls.Clear();
                paletteHinzufuegen.Text = "Palette hinzufügen";
                TC.TabPages.Add(paletteHinzufuegen);
                LoadForm.OpenPanel(new Paletteadd(pNr, TC), paletteHinzufuegen);
                TC.SelectedTab = paletteHinzufuegen;
            }
        }
        TabPage paletteBearbeiten = new TabPage();
        private void iconButton4_Click(object sender, EventArgs e)
        {
            if (TC.TabPages.Contains(paletteBearbeiten))
            {
                edit.pageswitch(paletteBearbeiten, TC);
            }
            else
            {
                string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();

                cmd = new OleDbCommand("select * from Palette where Nr = " + System.Convert.ToInt64(Ausgewähltezelle) + "", con);


                con.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                long pNr = dr.GetInt32(0);
                con.Close();


                paletteBearbeiten.Controls.Clear();
                paletteBearbeiten.Text = "Palette bearbeiten";
                TC.TabPages.Add(paletteBearbeiten);
                LoadForm.OpenPanel(new Paletteadd(pNr, TC), paletteBearbeiten);
                TC.SelectedTab = paletteBearbeiten;
            }
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            string Ausgewähltezelle = dataGridView1.CurrentRow.Cells["Nr"].Value.ToString();
            adap = new OleDbDataAdapter("SELECT DISTINCT AuftragLieferungPalette.Palette FROM AuftragLieferungPalette,Auftrag, Kunde, Auftragsstatus, AuftragLieferung, Palette" +
            " WHERE Palette.Nr = AuftragLieferungPalette.Palette and AuftragLieferungPalette.Palette = " + Ausgewähltezelle + " and AuftragLieferung.Nr = AuftragLieferungPalette.AuftragLieferung and " +
            "AuftragLieferung.Auftrag = Auftrag.Nr and Auftrag.Status = Auftragsstatus.Nr and Auftrag.Status = 1 and Palette.IsActive = true;", con);
            con.Open();
            DataTable dt = new DataTable();
            DataRow d = dt.NewRow();
            adap.Fill(dt);
            con.Close();

            if (dt.Rows.Count >= 1)
            {
                MessageBox.Show("Sie Können die Palette nicht löschen, da sie in einem Auftrag vorkommt der noch in Bearbeitung ist.");
            }
            else
            {
                DialogResult result = MessageBox.Show("Sind Sie sicher das Sie die ausgewählte Palette löschen möchten?", "Bestätigung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    con.Open();
                    cmd = new OleDbCommand("Update Palette set IsActive = false where Nr = " + Ausgewähltezelle + "", con);
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    con.Close();

                    MessageBox.Show("Gelöscht.");
                    Palette_Load(sender, e);
                }
            }
        }

        private void istAktiv_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (istAktiv_checkBox.Checked == true)
            {
                edit.IstAktiv(adap, dataGridView1, 7);
            }
            else
            {
                edit.DataGridFuellen("Nr", adap, dataGridView1);
            }
        }

        private void PaletteSuchen_Enter(object sender, EventArgs e)
        {
            Palette_Load(sender, e);
        }
    }
}
