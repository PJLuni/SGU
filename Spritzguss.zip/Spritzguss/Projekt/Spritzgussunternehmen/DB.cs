﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    class DB
    {
        private static OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        public static OleDbCommand cmd = null;
        public static OleDbDataReader dr = null;
        public static OleDbDataAdapter adap = null;
        public static OleDbConnection getCon()
        {
            return con;
        }
        public static OleDbCommand createCmd(string command)
        {
            cmd = new OleDbCommand(command, con);
            return cmd;
        }
    }
}
