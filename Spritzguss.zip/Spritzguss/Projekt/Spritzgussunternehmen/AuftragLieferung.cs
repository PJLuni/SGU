﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Spritzgussunternehmen
{
    public partial class AuftragLieferung : Form
    {
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OleDB.12.0; Data Source = Werkstoffpruefsystem.accdb");
        OleDbCommand cmd = null;
        OleDbDataAdapter adap = null;
        OleDbDataReader dr = null;
        public AuftragLieferung()
        {
            InitializeComponent();
        }
        public static int auftragLieferung = 0;
        
        private void iconButton3_Click(object sender, EventArgs e)
        {
            String[] row = { textBox18.Text, Convert.ToString(comboBox2.Text), Convert.ToString(comboBox3.Text), dateTimePicker3.Value.ToString(), textBox3.Text };
            AuftragAdd.rows =row ;
            
            
            auftragLieferung = 1;
        }

        private void AuftragLieferung_Load(object sender, EventArgs e)
        {

        }
    }
}
