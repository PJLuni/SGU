﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Spritzgussunternehmen
{
    public partial class ProduktAdd : Form
    {
        Produkt NeuesProdukt = new Produkt();
        TabControl NeededTabControl;
        public ProduktAdd(TabControl NeededTabControl)
        {
            InitializeComponent();
            this.NeededTabControl = NeededTabControl;
        }

        private void ProduktAdd_Load(object sender, EventArgs e)
        {
            NeuesProdukt.LoadArten(comboBox1);
            NeuesProdukt.LoadEinheiten(comboBox2);
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Möchten Sie die Produktionsschritte direkt im Anschluss anlegen?", "Produktionsschritte", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                NeuesProdukt.OpenProdSchritte(NeededTabControl);
            }
        }
    }
}
